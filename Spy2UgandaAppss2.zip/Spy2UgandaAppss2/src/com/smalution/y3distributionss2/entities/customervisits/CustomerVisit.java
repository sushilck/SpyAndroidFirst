package com.smalution.y3distributionss2.entities.customervisits;


import org.json.JSONObject;

import android.content.SharedPreferences;
import android.os.Parcel;
import android.os.Parcelable;

import com.androidquery.AQuery;
import com.smalution.y3distributionss2.AppManager;
import com.smalution.y3distributionss2.utils.AppConstant;

public class CustomerVisit implements Parcelable
{
	CustVisitCustomer Customer;
	CustVisitUser User;
	CustVisitLgArea LgArea;
	CustVisitDepot Depot;
	CustVisitCustomerVisit CustomerVisit;
	CustomerVisitState State;
	int sno;
	String offlineCustomerJSON;
	public CustomerVisit()
	{
		Customer=new CustVisitCustomer();
		User=new CustVisitUser();
		LgArea=new CustVisitLgArea();
		Depot=new CustVisitDepot();
		CustomerVisit=new CustVisitCustomerVisit();
		State=new CustomerVisitState();
	}
	public CustomerVisit(JSONObject jsonObject)
	{
		try
		{
			Customer=jsonObject.isNull("Customer")?null:new CustVisitCustomer(jsonObject.getJSONObject("Customer"));
			User=jsonObject.isNull("User")?null:new CustVisitUser(jsonObject.getJSONObject("User"));
			LgArea=jsonObject.isNull("LgArea")?null:new CustVisitLgArea(jsonObject.getJSONObject("LgArea"));			
			Depot=jsonObject.isNull("Depot")?null:new CustVisitDepot(jsonObject.getJSONObject("Depot"));
			State=jsonObject.isNull("State")?null:new CustomerVisitState(jsonObject.getJSONObject("State"));			
			CustomerVisit=jsonObject.isNull("CustomerVisit")?null:new CustVisitCustomerVisit(jsonObject.getJSONObject("CustomerVisit"));
			sno=jsonObject.isNull("sno")?0:jsonObject.getInt("sno");
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	
	public CustomerVisit(Parcel in)
 	{
		Customer=in.readParcelable(CustVisitCustomer.class.getClassLoader());
		User=in.readParcelable(CustVisitUser.class.getClassLoader());
		LgArea=in.readParcelable(CustVisitLgArea.class.getClassLoader());
		Depot=in.readParcelable(CustVisitDepot.class.getClassLoader());
		State=in.readParcelable(CustomerVisitState.class.getClassLoader());
		CustomerVisit=in.readParcelable(CustVisitCustomerVisit.class.getClassLoader());
		sno=in.readInt();
	}
 	@Override
 	public int describeContents() 
 	{
 		return 0;
 	}
 	@Override
 	public void writeToParcel(Parcel dest, int flags) 
 	{
 		dest.writeParcelable(Customer,flags);
 		dest.writeParcelable(User,flags);
 		dest.writeParcelable(LgArea,flags);
 		dest.writeParcelable(Depot,flags);
 		dest.writeParcelable(State,flags);
 		dest.writeParcelable(CustomerVisit,flags);
 		dest.writeInt(sno);
 	}
 	public static final Parcelable.Creator<CustomerVisit> CREATOR = new Parcelable.Creator<CustomerVisit>() 
 	{
 		public CustomerVisit createFromParcel(Parcel in) 
 		{
 			return new CustomerVisit(in);
 		}
 	
 		public CustomerVisit[] newArray (int size) 
 		{
 			return new CustomerVisit[size];
 		}
 	};
	
	public int getSno() {
		return sno;
	}
	public void setSno(int sno) {
		this.sno = sno;
	}
	public CustVisitCustomer getCustomer() {
		return Customer;
	}
	public void setCustomer(CustVisitCustomer customer) {
		Customer = customer;
	}
	public CustVisitUser getUser() {
		return User;
	}
	public void setUser(CustVisitUser user) {
		User = user;
	}
	public CustVisitLgArea getLgArea() {
		return LgArea;
	}
	public void setLgArea(CustVisitLgArea lgArea) {
		LgArea = lgArea;
	}
	public CustVisitDepot getDepot() {
		return Depot;
	}
	public void setDepot(CustVisitDepot depot) {
		Depot = depot;
	}
	public CustVisitCustomerVisit getCustomerVisit() {
		return CustomerVisit;
	}
	public void setCustomerVisit(CustVisitCustomerVisit customerVisit) {
		CustomerVisit = customerVisit;
	}
	public String getOfflineCustomerJSON() {
		return offlineCustomerJSON;
	}
	public void setOfflineCustomerJSON(String offlineCustomerJSON) {
		this.offlineCustomerJSON = offlineCustomerJSON;
	}
	public void setState(CustomerVisitState state) {
		State = state;
	}
	public  CustomerVisitState getState() {
		return State;
	}
	public String createJson(AQuery aq, boolean isForAddCustomerVisit, boolean isOnlineCustomerSelectionModeOn)
	{
		if(CustomerVisit==null)
			return null;
		SharedPreferences prefs = AppManager.getInstance().getPrefs(aq.getContext());
		String token = prefs.getString("token", null);
		String json="{" +
				"\"token\":\""+token+"\",";
				if(!isForAddCustomerVisit)
				{
					json=json+"\"visit_id\":\""+CustomerVisit.getId()+"\",";
				}
				else
				{
					json=json+"\"request_id\":\""+AppConstant.ANDROIDDEVICEID + AppConstant.getRequestId()+"\"," ;
				}
				json=json+"\"created\":\""+AppConstant.getCurrentDateAndTime()+"\"," +						
				"\"customer_id\":\""+CustomerVisit.getCustomer_id()+"\"," +
				"\"customer_name\":\""+getCustomer().getFirst_name()+"\"," +
				"\"state_id\":\""+CustomerVisit.getState_id()+"\"," +
				"\"lg_area_id\":\""+CustomerVisit.getLg_area_id()+"\"," +
				"\"depot_id\":\""+CustomerVisit.getDepot_id()+"\"," +
				"\"visiting_date\":\""+CustomerVisit.getVisiting_date()+"\"," +
				"\"comment\":\""+CustomerVisit.getComment()+"\"";
				
				if(!isOnlineCustomerSelectionModeOn)
				{
					json=json+",";
					json=json+"\"newCustomer\":" ;
					json=json+getOfflineCustomerJSON();		
					json=json+"}";
				}
				else
				{
					json=json+"}";
				}
		return json;
	}
}
