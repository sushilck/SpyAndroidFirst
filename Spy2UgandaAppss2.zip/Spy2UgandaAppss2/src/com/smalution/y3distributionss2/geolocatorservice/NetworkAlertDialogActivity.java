package com.smalution.y3distributionss2.geolocatorservice;

import com.smalution.y3distributionss2.AppManager;
import com.smalution.y3distributionss2.R;
import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;

import com.androidquery.AQuery;

public class NetworkAlertDialogActivity extends Activity 
{
	AQuery aq;
	@Override
	protected void onCreate(Bundle savedInstanceState) 
	{
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.network_alert_dialog);
		aq=new AQuery(this);
		aq.id(R.id.ButtonOk).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				finish();
	        }
		});
		isDialogShouldClose();
	}
	private void isDialogShouldClose()
	{
		if(AppManager.getInstance().isOnline(this))
		{
			finish();
		}
		new Handler().postDelayed(new Runnable() 
		{
			@Override
			public void run() 
			{
				isDialogShouldClose();
			}
		}, 5000);
	}
}
