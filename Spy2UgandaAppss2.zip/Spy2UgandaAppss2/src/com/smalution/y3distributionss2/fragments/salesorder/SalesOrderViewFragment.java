package com.smalution.y3distributionss2.fragments.salesorder;

import java.math.BigDecimal;

import org.json.JSONException;
import org.json.JSONObject;

import com.smalution.y3distributionss2.AppManager;
import com.smalution.y3distributionss2.entities.salesorder.FreeItemSales;
import com.smalution.y3distributionss2.entities.salesorder.Sales;
import com.smalution.y3distributionss2.entities.salesorder.SalesOrder;
import com.smalution.y3distributionss2.entities.salesorder.SalesOrderDetail;
import com.smalution.y3distributionss2.entities.settings.Brands;
import com.smalution.y3distributionss2.fragments.SuperFragment;
import com.smalution.y3distributionss2.R;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.androidquery.AQuery;


public class SalesOrderViewFragment extends SuperFragment 
{
	SalesOrder salesOrder;
	View rootView;
	AQuery aq; 
	ArrayAdapter<Sales> adapter;
	ArrayAdapter<FreeItemSales> freeItemAdapter;
	SalesOrderDetail salesOrderDetail;
	public static final int FLAG_SELECT_CUSTOMER=101;
	public static boolean isOnline=false;
	UIHandler uiHandler;
	public class UIHandler extends Handler 
	{ 
        public void handleMessage(Message msg) 
        { 
        	switch(msg.arg1)
        	{
        		case FLAG_SELECT_CUSTOMER:
        		{
        			String selectedValue=(String)msg.obj;
        			aq.id(R.id.buttonCustomer).text(selectedValue);
        			break;
        		}
        	}
        }
    };
	public void setUIArguments(final Bundle args) 
	{
	    getActivity().runOnUiThread(new Runnable() 
	    {
	        public void run() 
	        {
	        	salesOrder=args.getParcelable("SALESORDER");
	        	System.out.println(salesOrder.getCustOffline().getJsonData());
	        }
	    });
	}
	@Override
	public void onCreate(Bundle savedInstanceState) 
	{
		super.onCreate(savedInstanceState);
		salesOrder=getArguments().getParcelable("SALESORDER");
	}
	@Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
 
        rootView = inflater.inflate(R.layout.sales_order_view_fragment, container, false);
        uiHandler=new UIHandler();
        aq=new AQuery(rootView);
        
        if(AppManager.isOnline(getActivity())){
        isOnline=true;
        
        	new SalesOrderDetailAsyncTask(aq,salesOrder.getOrder().getId()).execute();
        
        }
        else{
        	isOnline=false;
        	try {
				initUI();
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        	
        }
        return rootView;
    }
	private void initUI() throws JSONException 
	{
		if(isOnline){
		ListView listView=aq.id(R.id.customerList).getListView();
		View header = LayoutInflater.from(getActivity()).inflate(R.layout.sales_order_view_list_header, null);
		listView.addHeaderView(header, null, false);
		View footer = LayoutInflater.from(getActivity()).inflate(R.layout.sales_order_view_list_footer, null);
		listView.addFooterView(footer, null, false);		
		AQuery aqHeader=new AQuery(header);		
			aqHeader.id(R.id.textViewCustomer).text(salesOrderDetail.getOrder().getCustomer().getFirst_name()+" "+salesOrderDetail.getOrder().getCustomer().getLast_name());
			aqHeader.id(R.id.textViewSalesDate).text(salesOrderDetail.getOrder().getOrder().getOrder_date());
			aqHeader.id(R.id.textViewCreatedDate).text(salesOrder.getOrder().getCreated());
			aqHeader.id(R.id.textViewSynchronizationData).text(salesOrder.getOrder().getModified());
		
		
		AQuery aqFooter=new AQuery(footer);
		
		BigDecimal grandTotal= new BigDecimal("0");
		for(Sales sale:salesOrderDetail.getSales())
		{
			BigDecimal val=new BigDecimal(sale.getSale().getAmount());
			grandTotal=grandTotal.add(val);
		}
		aqFooter.id(R.id.textViewGrandTotal).text(""+grandTotal);
		
		adapter = new ArrayAdapter<Sales>(this.getActivity(), R.layout.sales_order_view_list_item, salesOrderDetail.getSales())
		{
			public View getView(int position, View convertView, ViewGroup parent) 
	        {
	            if(convertView == null)
	            {
                     convertView = getActivity().getLayoutInflater().inflate(R.layout.sales_order_view_list_item, parent, false);
	            }
	            AQuery aql=new AQuery(convertView);
	          
	            Sales sales=(Sales)getItem(position);
	            aql.id(R.id.textViewSerialNo).text(""+(position+1));
	            aql.id(R.id.textViewBrand).text(sales.getBrand().getName());
	            aql.id(R.id.textViewUnit).text(sales.getSale().getUnit());
	            aql.id(R.id.textViewUnitPrice).text(sales.getSale().getUnit_price());
	            aql.id(R.id.textViewQuantity).text(sales.getSale().getQuantity());
	            aql.id(R.id.textViewTotal).text(sales.getSale().getAmount());
	           
	            	            
	            return convertView;
	        }
		};
		listView.setAdapter(adapter);		
		ListView freeItemsView=aq.id(R.id.freeItemsList).getListView();
		View freeItemsHeader = LayoutInflater.from(getActivity()).inflate(R.layout.sales_order_view_list_freeitems_header, null);
		freeItemsView.addHeaderView(freeItemsHeader, null, false);
		freeItemAdapter = new ArrayAdapter<FreeItemSales>(this.getActivity(), R.layout.sales_order_view_list_freeitems_item, salesOrderDetail.getFreeItems())
		{
			public View getView(int position, View convertView, ViewGroup parent) 
	        {
	            if(convertView == null)
	            {
                     convertView = getActivity().getLayoutInflater().inflate(R.layout.sales_order_view_list_freeitems_item, parent, false);
	            }
	            AQuery aql=new AQuery(convertView);
	            FreeItemSales freeItem=(FreeItemSales)getItem(position);
	            aql.id(R.id.textViewBrand).text(freeItem.getBrand().getName());
	            aql.id(R.id.textViewItem).text(freeItem.getFreeItem().getQuantity()+" "+freeItem.getFreeItem().getUnit());
	            return convertView;
	        }
		};
		freeItemsView.setAdapter(freeItemAdapter);
		}
	
	else{
		String jsonString=null;
		
		if("1".equals(salesOrder.getCustOffline().getIsOfflineAddedSales()))
		{
			String tempString=salesOrder.getCustOffline().getJsonData().substring(0, salesOrder.getCustOffline().getJsonData().length() - 1)+",";
			jsonString= tempString+salesOrder.getCustOffline().getOfflineJson();			
			
		}
		else{
			jsonString=salesOrder.getCustOffline().getJsonData();
		}
			
		JSONObject jsonObject = new JSONObject(jsonString);	
		salesOrderDetail = new SalesOrderDetail(jsonObject,1,salesOrder.getCustOffline().getJsonData());
		SalesOrder salesorder=new SalesOrder(jsonObject);
		ListView listView=aq.id(R.id.customerList).getListView();
		View header = LayoutInflater.from(getActivity()).inflate(R.layout.sales_order_view_list_header, null);
		listView.addHeaderView(header, null, false);
		View footer = LayoutInflater.from(getActivity()).inflate(R.layout.sales_order_view_list_footer, null);
		listView.addFooterView(footer, null, false);		
		AQuery aqHeader=new AQuery(header);		
		aqHeader.id(R.id.textViewCustomer).text(salesOrder.getCustomer().getFirst_name()+" "+salesOrder.getCustomer().getLast_name());
		aqHeader.id(R.id.textViewSalesDate).text(salesOrder.getOrder().getOrder_date());
		aqHeader.id(R.id.textViewCreatedDate).text(salesOrder.getOrder().getCreated());
		aqHeader.id(R.id.textViewSynchronizationData).text(salesOrder.getOrder().getModified());// modified date...
		
		
		
		AQuery aqFooter=new AQuery(footer);
		
		float grandTotal=0f;
		for(Sales sale:salesOrderDetail.getSales())
		{
			float val=Float.parseFloat(sale.getSale().getAmount());
			grandTotal=grandTotal+val;
		}
		aqFooter.id(R.id.textViewGrandTotal).text(""+grandTotal);
		
		adapter = new ArrayAdapter<Sales>(this.getActivity(), R.layout.sales_order_view_list_item, salesOrderDetail.getSales())
		{
			public View getView(int position, View convertView, ViewGroup parent) 
	        {
	            if(convertView == null)
	            {
                     convertView = getActivity().getLayoutInflater().inflate(R.layout.sales_order_view_list_item, parent, false);
	            }
	            AQuery aql=new AQuery(convertView);
	          
	            Sales sales=(Sales)getItem(position);
	            aql.id(R.id.textViewSerialNo).text(sales.getSale().getId());	  
	            Brands brands = AppManager.getInstance().getBrands(aq);				
	            aql.id(R.id.textViewBrand).text(brands.getBrandById(sales.getSale().getBrand_id()).getName());
	            aql.id(R.id.textViewUnit).text(sales.getSale().getUnit());
	            aql.id(R.id.textViewUnitPrice).text(sales.getSale().getUnit_price());
	            aql.id(R.id.textViewQuantity).text(sales.getSale().getQuantity());
	            aql.id(R.id.textViewTotal).text(sales.getSale().getAmount());
	           
	            	            
	            return convertView;
	        }
		};
		listView.setAdapter(adapter);		
		ListView freeItemsView=aq.id(R.id.freeItemsList).getListView();
		View freeItemsHeader = LayoutInflater.from(getActivity()).inflate(R.layout.sales_order_view_list_freeitems_header, null);
		freeItemsView.addHeaderView(freeItemsHeader, null, false);
		freeItemAdapter = new ArrayAdapter<FreeItemSales>(this.getActivity(), R.layout.sales_order_view_list_freeitems_item, salesOrderDetail.getFreeItems())
		{
			public View getView(int position, View convertView, ViewGroup parent) 
	        {
	            if(convertView == null)
	            {
                     convertView = getActivity().getLayoutInflater().inflate(R.layout.sales_order_view_list_freeitems_item, parent, false);
	            }
	            AQuery aql=new AQuery(convertView);
	            FreeItemSales freeItem=(FreeItemSales)getItem(position);
	            Brands brands = AppManager.getInstance().getBrands(aq);   
	         
	            aql.id(R.id.textViewBrand).text(brands.getBrandById(freeItem.getFreeItem().getBrand_id()).getName());
	            aql.id(R.id.textViewItem).text(freeItem.getFreeItem().getQuantity()+" "+freeItem.getFreeItem().getUnit());
	            return convertView;
	        }
		};
		freeItemsView.setAdapter(freeItemAdapter);	
	}
	}
	private class SalesOrderDetailAsyncTask extends AsyncTask<Void, Void, SalesOrderDetail>
	{
		AQuery aq;
		String orderId;
		ProgressDialog progressDialog;
		public SalesOrderDetailAsyncTask(AQuery aq, String orderId)
		{
			this.aq=aq;
			this.orderId=orderId;
		}
		@Override
		protected void onPreExecute() 
		{
			super.onPreExecute();
			progressDialog = new ProgressDialog(getActivity());
	        progressDialog.setMessage(getString(R.string.wait_progress));
	        progressDialog.setCancelable(false);
	        progressDialog.setIndeterminate(true);
	        progressDialog.show();
	        progressDialog.setOnKeyListener(new DialogInterface.OnKeyListener() 
	        {
	            @Override
	            public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) 
	            {
	                return false;
	            }
	        });
		}
		@Override
		protected SalesOrderDetail doInBackground(Void... params) 
		{
			try
			{
				return AppManager.getInstance().getSalesOrderDetail(aq,orderId);
			}
			catch(Exception ex)
			{
				return null;
			}
		}
		@Override
		protected void onPostExecute(SalesOrderDetail result) 
		{
			super.onPostExecute(result);
			if(result!=null)
			{
				salesOrderDetail=result;
				try {
					initUI();
				} catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				adapter.notifyDataSetChanged();
			}
			else
			{
				Toast.makeText(getActivity(), getString(R.string.no_sale_mess), Toast.LENGTH_SHORT).show();
			}
			progressDialog.dismiss();
		}
	}
	
}
