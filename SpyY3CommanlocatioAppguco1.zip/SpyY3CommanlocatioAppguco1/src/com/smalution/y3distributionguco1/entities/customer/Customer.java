package com.smalution.y3distributionguco1.entities.customer;


import java.util.ArrayList;
import java.util.Iterator;

import org.json.JSONObject;

import android.content.SharedPreferences;
import android.os.Parcel;
import android.os.Parcelable;

import com.androidquery.AQuery;
import com.smalution.y3distributionguco1.AppManager;
import com.smalution.y3distributionguco1.utils.AppConstant;

public class Customer implements Parcelable
{
	CustUser User;
	CustCustomer Customer;
	CustDepot Depot;
	CustLgArea LgArea;
	CustRegion Region;
	CustState State;
	CustFile File;
	CustOfflineData Custofflinedata;
	String toAssignOptionSelectedJSON;
	int sno;
	ArrayList<String> assignToList=new ArrayList<String>();
	public String getToAssignOptionSelectedJSON() {
		return toAssignOptionSelectedJSON;
	}
	public void setToAssignOptionSelectedJSON(String toAssignOptionSelectedJSON) {
		this.toAssignOptionSelectedJSON = toAssignOptionSelectedJSON;
	}
	public Customer()
	{
		User=new CustUser();
		Customer=new CustCustomer();
		Depot=new CustDepot();
		LgArea=new CustLgArea();
		Region=new CustRegion();
		State=new CustState();
		File=new CustFile();
		Custofflinedata=new CustOfflineData();
		assignToList=new ArrayList<String>();
	}
	public Customer(JSONObject jsonObject)
	{
		try
		{
			User=jsonObject.isNull("User")?null:new CustUser(jsonObject.getJSONObject("User"));
			Customer=jsonObject.isNull("Customer")?null:new CustCustomer(jsonObject.getJSONObject("Customer"));
			Depot=jsonObject.isNull("Depot")?null:new CustDepot(jsonObject.getJSONObject("Depot"));
			LgArea=jsonObject.isNull("LgArea")?null:new CustLgArea(jsonObject.getJSONObject("LgArea"));
			Region=jsonObject.isNull("Region")?null:new CustRegion(jsonObject.getJSONObject("Region"));
			State=jsonObject.isNull("State")?null:new CustState(jsonObject.getJSONObject("State"));
			File=jsonObject.isNull("File")?null:new CustFile(jsonObject.getJSONObject("File"));
			sno=jsonObject.isNull("sno")?0:jsonObject.getInt("sno");
			assignToList=jsonObject.isNull("assignTo")?new ArrayList<String>():getAssignList(jsonObject.getJSONObject("assignTo"));
			toAssignOptionSelectedJSON=jsonObject.isNull("assignTo")?"":createAssignToJson(jsonObject.getJSONObject("assignTo"));
			
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	public Customer(JSONObject jsonObject,int customerId)
	{
		try
		{
			User=jsonObject.isNull("User")?null:new CustUser(jsonObject.getJSONObject("User"));
			Customer=jsonObject.isNull("Customer")?null:new CustCustomer(jsonObject.getJSONObject("Customer"),1);
			Depot=jsonObject.isNull("Depot")?null:new CustDepot(jsonObject.getJSONObject("Depot"));
			LgArea=jsonObject.isNull("LgArea")?null:new CustLgArea(jsonObject.getJSONObject("LgArea"));
			Region=jsonObject.isNull("Region")?null:new CustRegion(jsonObject.getJSONObject("Region"));
			State=jsonObject.isNull("State")?null:new CustState(jsonObject.getJSONObject("State"));
			File=jsonObject.isNull("File")?null:new CustFile(jsonObject.getJSONObject("File"));
			sno=jsonObject.isNull("sno")?0:jsonObject.getInt("sno");
			Custofflinedata= new CustOfflineData(customerId);
			assignToList=jsonObject.isNull("assignTo")?new ArrayList<String>():getAssignList(jsonObject.getJSONObject("assignTo"));
			toAssignOptionSelectedJSON=jsonObject.isNull("assignTo")?"":createAssignToJson(jsonObject.getJSONObject("assignTo"));
			
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	private String createAssignToJson(JSONObject jsonObject) throws Exception
	{
		String json="";
		if(jsonObject!=null)
		{
			json = json+"{";
			Iterator<String> itr = jsonObject.keys();
			while(itr.hasNext())
			{
				String key = itr.next();
				String value = jsonObject.getString(key);
				json=json+"\""+key+"\":\""+value+"\"";
            	if(itr.hasNext())
				{
					json=json+",";
				}
			}
			json=json+"}";
		}
		return json;
	}
	private ArrayList<String> getAssignList(JSONObject jsonObject) throws Exception
	{
		ArrayList<String> list=new ArrayList<String>();
		if(jsonObject!=null)
		{
			Iterator<String> itr = jsonObject.keys();
			while(itr.hasNext())
			{
				String key = itr.next();
				list.add(jsonObject.getString(key));
			}
		}
		return list;
	}
	public Customer(Parcel in)
 	{
		User=in.readParcelable(CustUser.class.getClassLoader());
		Customer=in.readParcelable(CustCustomer.class.getClassLoader());
		Depot=in.readParcelable(CustDepot.class.getClassLoader());
		LgArea=in.readParcelable(CustLgArea.class.getClassLoader());
		Region=in.readParcelable(CustRegion.class.getClassLoader());
		State=in.readParcelable(CustState.class.getClassLoader());
		File=in.readParcelable(CustFile.class.getClassLoader());
		sno=in.readInt();
		assignToList=(ArrayList<String>)in.readSerializable();
	}
 	@Override
 	public int describeContents() 
 	{
 		return 0;
 	}
 	@Override
 	public void writeToParcel(Parcel dest, int flags) 
 	{
 		dest.writeParcelable(User,flags);
 		dest.writeParcelable(Customer,flags);
 		dest.writeParcelable(Depot,flags);
 		dest.writeParcelable(LgArea,flags);
 		dest.writeParcelable(Region,flags);
 		dest.writeParcelable(State,flags);
 		dest.writeParcelable(File,flags);
 		dest.writeInt(sno);
 		dest.writeSerializable(assignToList);
	}
 	public static final Parcelable.Creator<Customer> CREATOR = new Parcelable.Creator<Customer>() 
 	{
 		public Customer createFromParcel(Parcel in) 
 		{
 			return new Customer(in);
 		}
 	
 		public Customer[] newArray (int size) 
 		{
 			return new Customer[size];
 		}
 	};
	
	public ArrayList<String> getAssignToList() {
		return assignToList;
	}
	public void setAssignToList(ArrayList<String> assignToList) {
		this.assignToList = assignToList;
	}
	public int getSno() {
		return sno;
	}
	public void setSno(int sno) {
		this.sno = sno;
	}
	public CustUser getUser() {
		return User;
	}
	public void setUser(CustUser user) {
		User = user;
	}
	public CustCustomer getCustomer() {
		return Customer;
	}
	public void setCustomer(CustCustomer customer) {
		Customer = customer;
	}
	public CustDepot getDepot() {
		return Depot;
	}
	public void setDepot(CustDepot depot) {
		Depot = depot;
	}
	public CustLgArea getLgArea() {
		return LgArea;
	}
	public void setLgArea(CustLgArea lgArea) {
		LgArea = lgArea;
	}
	public CustRegion getRegion() {
		return Region;
	}
	public void setRegion(CustRegion region) {
		Region = region;
	}
	public CustState getState() {
		return State;
	}
	public void setState(CustState state) {
		State = state;
	}
	public CustFile getFile() {
		return File;
	}
	public void setFile(CustFile file) {
		File = file;
	}
	public CustOfflineData getCustOffline(){
		return Custofflinedata;
	}
	public void setCustOffline(CustOfflineData offline){
		Custofflinedata=offline;
	}
	
	
	public String createJson(AQuery aq, boolean isForAddCustomer)
	{
		SharedPreferences prefs = AppManager.getInstance().getPrefs(aq.getContext());
		String token = prefs.getString("token", null);
		String json="{" +
				"\"token\":\""+token+"\",";
		
		if(!isForAddCustomer)
		{
			json=json+"\"id\":\""+getCustomer().getId()+"\"," +
			"\"oldFile_id\":\""+getCustomer().getFile_id()+"\",";
		}
		else
		{
			json=json+"\"request_id\":\""+AppConstant.ANDROIDDEVICEID + AppConstant.getRequestId()+"\"," + 
						"\"created\":\""+AppConstant.getCurrentDateAndTime()+"\","  ;			
		}
		json=json+"\"first_name\":\""+getCustomer().getFirst_name()+"\"," +
				"\"last_name\":\""+getCustomer().getLast_name()+"\"," +
				"\"email\":\""+getCustomer().getEmail()+"\"," +
				"\"address\":\""+getCustomer().getAddress()+"\"," +
				"\"city\":\""+getCustomer().getCity()+"\"," +
				"\"state_id\":\""+getCustomer().getState_id()+"\"," +
				"\"latitude\":\""+getCustomer().getLatitude()+"\"," +
				"\"longitude\":\""+getCustomer().getLongitude()+"\"," +
				"\"zipcode\":\""+getCustomer().getZipcode()+"\"," +								
				"\"phone\":\""+getCustomer().getPhone()+"\"," +
				"\"region_id\":\""+getCustomer().getRegion_id()+"\"," +
				"\"depot_id\":\""+getCustomer().getDepot_id()+"\"," +
				"\"route_id\":\""+getCustomer().getRoute_id()+"\"," +
				"\"route_name\":\""+getState().getState()+"\"," +
				"\"lg_area_id\":\""+getCustomer().getLg_area_id()+"\"," +
				"\"description\":\""+getCustomer().getDescription()+"\"," +
				"\"view_details\":\""+getCustomer().getView_details()+"\"" ;
				if(getToAssignOptionSelectedJSON()!=null && getToAssignOptionSelectedJSON().length()>0)
				{
					json=json+",\"assignToOption\":"+getToAssignOptionSelectedJSON();
				}
		json=json+"}";
		return json;
	}
}
