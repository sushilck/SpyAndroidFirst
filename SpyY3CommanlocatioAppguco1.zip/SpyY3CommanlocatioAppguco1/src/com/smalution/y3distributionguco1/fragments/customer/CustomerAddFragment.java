package com.smalution.y3distributionguco1.fragments.customer;
import com.smalution.y3distributionguco1.AppManager;
import com.smalution.y3distributionguco1.R;
import com.smalution.y3distributionguco1.Utils;
import com.smalution.y3distributionguco1.database.Y3QueryDataSource;
import com.smalution.y3distributionguco1.entities.customer.Customer;
import com.smalution.y3distributionguco1.entities.settings.Depots;
import com.smalution.y3distributionguco1.entities.settings.Lgas;
import com.smalution.y3distributionguco1.entities.settings.Regions;
import com.smalution.y3distributionguco1.entities.settings.Routes;
import com.smalution.y3distributionguco1.entities.settings.States;
import com.smalution.y3distributionguco1.entities.settings.Users;
import com.smalution.y3distributionguco1.fragments.SuperFragment;
import com.smalution.y3distributionguco1.utils.AppConstant;
import com.smalution.y3distributionguco1.utils.PickImageByCameraOrGallery;

import java.io.File;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Hashtable;

import org.json.JSONException;
import org.json.JSONObject;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.location.Location;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Toast;

import com.androidquery.AQuery;
import com.androidquery.callback.AjaxStatus;
import com.androidquery.callback.LocationAjaxCallback;

public class CustomerAddFragment extends SuperFragment 
{
	boolean[] selectedAssignToOptions;
  private Customer customer;
	View rootView;
	AQuery aq; 
	PickImageByCameraOrGallery PickImageByCameraOrGalleryObj;
	public static final int FLAG_SELECT_STATE=101;
	public static final int FLAG_SELECT_LGA=102;
	public static final int FLAG_SELECT_REGION=103;
	public static final int FLAG_SELECT_DEPOT=104;
	public static final int FLAG_SELECT_ASSIGNTO=105;
	public static final int FLAG_SELECT_ROUTE = 106;
	public static  String jsonString;
	public static  String selectedImagePath;
	UIHandler uiHandler;
	public   String states_id;
	public   String lga_id="0";
	public  String region_id;
	public  String depot_id;
	public  String route_id="0";
	public String jsonAssignOption;
	public int userGrade;
	public boolean isDraft = false;
	public class UIHandler extends Handler 
	{ 
        public void handleMessage(Message msg) 
        { 
        	switch(msg.arg1)
        	{
        		case FLAG_SELECT_STATE:
        		{
        			String selectedValue=(String)msg.obj;
        			aq.id(R.id.buttonState).text(selectedValue);
        			States states = AppManager.getInstance().getStates(aq);
        			if(states!=null)
        			{
        				
        				states_id=states.getItem(msg.arg2).getId();
        				aq.id(R.id.buttonLGA).text(getString(R.string.select_lga));
        				//System.out.println("DEMO");
        			}
        			break;
				}
        		case FLAG_SELECT_LGA:
        		{
        			String selectedValue=(String)msg.obj;
        			aq.id(R.id.buttonLGA).text(selectedValue);
        			Lgas lgas = AppManager.getInstance().getLgas(aq,states_id);
        			if(lgas!=null)
        			{
        				
        				lga_id=lgas.getItem(msg.arg2).getId();
        			}
        			break;
        		}
        		case FLAG_SELECT_REGION:
        		{
        			String selectedValue=(String)msg.obj;
        			aq.id(R.id.buttonRegion).text(selectedValue);
        			Regions regions = AppManager.getInstance().getRegions(aq);
        			if(regions !=null)
        			{
        				
        				region_id=regions.getItem(msg.arg2).getId();
        				aq.id(R.id.buttonDepot).text(getString(R.string.select_depot));
        				aq.id(R.id.buttonRoute).text(getString(R.string.select_route));
        			}
        			break;
        		}
        		case FLAG_SELECT_DEPOT:
	    		{
	    			String selectedValue=(String)msg.obj;
	    			aq.id(R.id.buttonDepot).text(selectedValue);
	    			Depots depots=AppManager.getInstance().getDepots(aq,region_id);
	    			if(depots!=null)
	    			{
	    				depot_id=depots.getItem(msg.arg2).getId();	    				
	    			}
	    			aq.id(R.id.buttonRoute).text(getString(R.string.select_route));
	    			break;
	    		}
	    		
        		case FLAG_SELECT_ROUTE:
	    		{
	    			String selectedValue=(String)msg.obj;
	    			aq.id(R.id.buttonRoute).text(selectedValue);
	    			Routes routes=AppManager.getInstance().getRoutes(aq,region_id, depot_id);
	    			if(routes!=null)
	    			{
	    				
	    				route_id=routes.getItem(msg.arg2).getId();
	    			}
	    			break;
	    		}
	    		
        		case FLAG_SELECT_ASSIGNTO:
	    		{
	    			@SuppressWarnings("unchecked")
	    			Object[] data=(Object[])msg.obj;
	    			selectedAssignToOptions = (boolean[])data[0];
	    			ArrayList<String> selectedValues=(ArrayList<String>)data[1];
	    			Log.d("MTK", ""+selectedValues.size());
	    			String json = (String)data[2];
	    			jsonAssignOption=json;
	    			
	    			
        			//aq.id(R.id.buttonAssignTo).text(selectedValue);
	    			break;
	    		}
        	}
        }
    };
	public void setUIArguments(final Bundle args) 
	{
	    getActivity().runOnUiThread(new Runnable() 
	    {
	        public void run() 
	        {
	        	customer = args.getParcelable("CUSTOMER");
	        }
	    });
	}
	

	@Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,Bundle savedInstanceState) 
	{
        rootView = inflater.inflate(R.layout.customer_add_fragment, container, false);
        customer=new Customer();
        customer = getArguments().getParcelable("CUSTOMER");
        uiHandler=new UIHandler();
        aq=new AQuery(rootView);
        initUI();
        cfillfromDraft();
        return rootView;
    }
	
	public void onPause(){
		super.onPause();
		System.out.println("This is OnPause activity");
		caddDraft();
	}
	
	public void onStop(){
		super.onStop();
		System.out.println("This is onStop activity");
		caddDraft();
	}
	
	public void onDestroy(){
		super.onDestroy();
		System.out.println("This is onDestroy activity");
		caddDraft();
	}
	
	@Override
	public void onActivityResult(int requestCode, int resultCode, Intent data) 
	{
		super.onActivityResult(requestCode, resultCode, data);
		PickImageByCameraOrGalleryObj.onActivityResult(requestCode, resultCode, data, aq.id(R.id.imageViewPhoto).getImageView());
	}
	
	public void destroyItem(ViewGroup container, int position, Object object) {
        // TODO Auto-generated method stub 	
		System.out.println("This is close... and destroy view");       
    }
	
	private void initUI() 
	{
		addLatLong();
		Users users = AppManager.getInstance().getUsers(aq);
		if(users!=null)
		{
			String[]  AssignToOptions = users.getNamesArr();
			if(AssignToOptions!=null && AssignToOptions.length>0)
			{
				selectedAssignToOptions=new boolean[AssignToOptions.length]; 
			}
		}
		
		
		final SharedPreferences prefs = getActivity().getSharedPreferences("BGGeoCollector", getActivity().MODE_PRIVATE);
		userGrade = prefs.getInt("grade", 0);
		String userObject = prefs.getString("user_object", null);
		try {
			JSONObject user_object = new JSONObject(userObject);
			states_id = user_object.getString("state_id");
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//System.out.println(userObject);
		if (userGrade > 2){
			aq.id(R.id.tableRowRegion).gone();
			aq.id(R.id.tableRowState).gone();
			region_id = prefs.getString("region_id", null);
		}
		
		if (userGrade > 3){
			aq.id(R.id.tableRowDepot).gone();
			depot_id = prefs.getString("depot_id", null);
		}
		
		PickImageByCameraOrGalleryObj=new PickImageByCameraOrGallery(CustomerAddFragment.this);
		aq.id(R.id.buttonSelectPhoto).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				PickImageByCameraOrGalleryObj.pickImage();
			}
		});
		aq.id(R.id.buttonState).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				boolean flag=false;
				States states = AppManager.getInstance().getStates(aq);
				if(states!=null)
				{
					String[] arr=states.getStatesNameArr();
					if(arr.length>0)
					{
						AppManager.getInstance().showSelectionAlertDialog(getActivity(), uiHandler, FLAG_SELECT_STATE, arr);
						flag=true;
					}
				}
				if(!flag)
				{
					Toast.makeText(getActivity(), getString(R.string.state_req_mess), Toast.LENGTH_SHORT).show();
				}
			}
		});
		aq.id(R.id.buttonLGA).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				boolean flag=false;
				Lgas lgas = AppManager.getInstance().getLgas(aq,states_id);
				if(lgas!=null)
				{
					
					
					String[] arr=lgas.getLgaNamesArr();
					if(arr.length>0)
					{
						AppManager.getInstance().showSelectionAlertDialog(getActivity(), uiHandler, FLAG_SELECT_LGA, arr);
						flag=true;
					}
				}
				if(!flag)
				{
					Toast.makeText(getActivity(), getString(R.string.lga_req_mess), Toast.LENGTH_SHORT).show();
				}
			}
		});
		aq.id(R.id.buttonRegion).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				boolean flag=false;
				Regions regions = AppManager.getInstance().getRegions(aq);
				if(regions!=null)
				{
					String arr[]=regions.getRegionNames();
					if(arr.length>0)
					{
						AppManager.getInstance().showSelectionAlertDialog(getActivity(), uiHandler, FLAG_SELECT_REGION, arr);
						flag=true;
					}
				}
				if(!flag)
				{
					Toast.makeText(getActivity(), getString(R.string.region_req_mess), Toast.LENGTH_SHORT).show();
				}
			}
		});
		aq.id(R.id.buttonDepot).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				boolean flag=false;
				Depots depots=AppManager.getInstance().getDepots(aq,region_id);
				if(depots!=null)
				{
					String[] arr=depots.getTitleArr();
					if(arr.length>0)
					{
						AppManager.getInstance().showSelectionAlertDialog(getActivity(), uiHandler, FLAG_SELECT_DEPOT, arr);
						flag=true;
					}
				}
				if(!flag)
				{
					Toast.makeText(getActivity(), getString(R.string.depot_req_mess), Toast.LENGTH_SHORT).show();
				}
			}
		});
		aq.id(R.id.buttonRoute).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				boolean flag=false;
				Routes routes=AppManager.getInstance().getRoutes(aq,region_id,depot_id);
				if(routes!=null)
				{
					String[] arr=routes.getTitleArr();
					if(arr.length>0)
					{
						AppManager.getInstance().showSelectionAlertDialog(getActivity(), uiHandler, FLAG_SELECT_ROUTE, arr);
						flag=true;
					}
				}
				if(!flag)
				{
					Toast.makeText(getActivity(), getString(R.string.empty_route_mess), Toast.LENGTH_SHORT).show();
				}
			}
		});
		aq.id(R.id.buttonAssignTo).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				boolean flag=false; 
				Users users = AppManager.getInstance().getUsers(aq);
				if(users!=null)
				{
					String[]  AssignToOptions = users.getNamesArr();
					if(AssignToOptions!=null && AssignToOptions.length>0)
					{
						AppManager.getInstance().showMultiSelectionAlertDialog(getActivity(), uiHandler, FLAG_SELECT_ASSIGNTO, AssignToOptions, selectedAssignToOptions,users);
						flag=true;
					}
				}
				if(!flag)
				{
					Toast.makeText(getActivity(), getString(R.string.assign_req_mess), Toast.LENGTH_SHORT).show();	
				}
			}
		});
		
		aq.id(R.id.buttonSave).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				updateCustomer();
			}
		});
	}
	private boolean isValidated()
	{
		if(aq.id(R.id.editTextFirstName).getEditText().getText().toString().length()>0)
		{
			if(aq.id(R.id.editTextLastName).getEditText().getText().toString().length()>0)
			{
				if(aq.id(R.id.editTextEmail).getEditText().getText().toString().length()>0)
				{
					if(!AppManager.getInstance().isValidEmailId(aq.id(R.id.editTextEmail).getEditText().getText().toString()))
					{
						Toast.makeText(getActivity(), getString(R.string.please_enter_email_id), Toast.LENGTH_SHORT).show();
						return false;
					}
				}
				if(aq.id(R.id.editTextPhone).getEditText().getText().toString().length() == Integer.parseInt(getString(R.string.phonemaxlength))
						&& AppManager.getInstance().isValidNumber(aq.id(R.id.editTextPhone).getEditText().getText().toString()) && !aq.id(R.id.editTextPhone).getEditText().getText().toString().equals("0") )
				{
					if(aq.id(R.id.editTextAddress).getEditText().getText().toString().length()>0)
					{
						if(aq.id(R.id.editTextCity).getEditText().getText().toString().length()>0)
						{
							if(aq.id(R.id.editTextZipcode).getEditText().getText().toString().length()>0)
							{
								if(!AppManager.getInstance().isValidNumber(aq.id(R.id.editTextZipcode).getEditText().getText().toString()))
								{
									Toast.makeText(getActivity(), getString(R.string.valid_zipcode), Toast.LENGTH_SHORT).show();
									return false;
								}
							}
							if( (aq.id(R.id.buttonState).getButton().getText().toString().length()>0 &&
									!aq.id(R.id.buttonState).getButton().getText().toString().startsWith(getString(R.string.select)) ) || userGrade > 2 )
							{
//								if(aq.id(R.id.editTextLatitude).getEditText().getText().toString().length()>0
//										&& AppManager.getInstance().isValidNumber(aq.id(R.id.editTextLatitude).getEditText().getText().toString()))
//								{
//									if(aq.id(R.id.editTextLongitude).getEditText().getText().toString().length()>0
//											&& AppManager.getInstance().isValidNumber(aq.id(R.id.editTextLongitude).getEditText().getText().toString()))
//									{
										if(aq.id(R.id.buttonLGA).getButton().getText().toString().length()>0 &&
												!aq.id(R.id.buttonLGA).getButton().getText().toString().startsWith(getString(R.string.select)))
										{
											if( (aq.id(R.id.buttonRegion).getButton().getText().toString().length()>0 &&
													!aq.id(R.id.buttonRegion).getButton().getText().toString().startsWith(getString(R.string.select))) || userGrade > 2)
											{
												if((aq.id(R.id.buttonDepot).getButton().getText().toString().length()>0 &&
														!aq.id(R.id.buttonDepot).getButton().getText().toString().startsWith(getString(R.string.select))) || userGrade > 3)
												{
													if((aq.id(R.id.buttonRoute).getButton().getText().toString().length()>0 &&
															!aq.id(R.id.buttonRoute).getButton().getText().toString().startsWith(getString(R.string.select))) )
													{
														return true;
													}
													else
													{
														Toast.makeText(getActivity(), getString(R.string.pls_select_route), Toast.LENGTH_SHORT).show();
													}
													
												}
												else
												{
													Toast.makeText(getActivity(), getString(R.string.pls_select_depot), Toast.LENGTH_SHORT).show();
												}
											}
											else
											{
												Toast.makeText(getActivity(), getString(R.string.pls_select_region), Toast.LENGTH_SHORT).show();
											}
										}
										else
										{
											Toast.makeText(getActivity(), getString(R.string.select_lga), Toast.LENGTH_SHORT).show();
										}
									}
									else
									{
										Toast.makeText(getActivity(), getString(R.string.pls_select_state), Toast.LENGTH_SHORT).show();
									}
//								}
//								else
//								{
//									Toast.makeText(getActivity(), "Please enter valid latitude.", Toast.LENGTH_SHORT).show();
//								}
//							}
//							else
//							{
//								Toast.makeText(getActivity(), "Please select state.", Toast.LENGTH_SHORT).show();
//							}
							
						}
						else
						{
							Toast.makeText(getActivity(), getString(R.string.please_enter_city), Toast.LENGTH_SHORT).show();
						}
					}
					else
					{
						Toast.makeText(getActivity(), getString(R.string.please_enter_address), Toast.LENGTH_SHORT).show();
					}
				}
				else
				{
					Toast.makeText(getActivity(), getString(R.string.please_enter_phn_number), Toast.LENGTH_SHORT).show();
				}
				
			}
			else
			{
				Toast.makeText(getActivity(), getString(R.string.please_enter_lname), Toast.LENGTH_SHORT).show();
			}
		}
		else
		{
			Toast.makeText(getActivity(), getString(R.string.please_enter_fname), Toast.LENGTH_SHORT).show();
		}
		return false;
	}
	private void updateCustomer()
	{
		if(!isValidated())
			return;
		
		customer=new Customer();
		customer.getCustomer().setFirst_name(aq.id(R.id.editTextFirstName).getEditText().getText().toString());
		customer.getCustomer().setLast_name(aq.id(R.id.editTextLastName).getEditText().getText().toString());
		customer.getCustomer().setEmail(aq.id(R.id.editTextEmail).getEditText().getText().toString());
		customer.getCustomer().setPhone(aq.id(R.id.editTextPhone).getEditText().getText().toString());
		customer.getCustomer().setAddress(aq.id(R.id.editTextAddress).getEditText().getText().toString());
		customer.getCustomer().setCity(aq.id(R.id.editTextCity).getEditText().getText().toString());
		customer.getCustomer().setZipcode(aq.id(R.id.editTextZipcode).getEditText().getText().toString());		
		
		customer.getState().setId(states_id);
		customer.getCustomer().setState_id(states_id);
		
		customer.getState().setState(aq.id(R.id.buttonState).getButton().getText().toString());
		customer.getCustomer().setLatitude(aq.id(R.id.editTextLatitude).getEditText().getText().toString());
		customer.getCustomer().setLongitude(aq.id(R.id.editTextLongitude).getEditText().getText().toString());
		
		customer.setToAssignOptionSelectedJSON(jsonAssignOption);
		customer.getLgArea().setId(lga_id);
		customer.getCustomer().setLg_area_id(lga_id);
		customer.getCustomer().setRoute_id(route_id);
		customer.getLgArea().setName(aq.id(R.id.buttonLGA).getButton().getText().toString());
		customer.getRegion().setId(region_id);
		customer.getCustomer().setRegion_id(region_id);
		customer.getRegion().setTitle(aq.id(R.id.buttonRegion).getButton().getText().toString());
		customer.getDepot().setId(depot_id);
		customer.getCustomer().setDepot_id(depot_id);
		customer.getDepot().setTitle(aq.id(R.id.buttonDepot).getButton().getText().toString());
		customer.getCustomer().setDescription(aq.id(R.id.editTextDescription).getEditText().getText().toString());
		customer.getCustomer().setView_details(aq.id(R.id.checkBoxIsDisplayCustDetail).getCheckBox().isChecked());//2014-03-02 20:30:19
		
		jsonString = customer.createJson(aq,true);
		Log.d("MTK", "edit customer="+jsonString);
		 selectedImagePath=null;
		if(aq.id(R.id.imageViewPhoto).getImageView().getTag()!=null)
		{
			selectedImagePath = aq.id(R.id.imageViewPhoto).getImageView().getTag().toString();
			Log.d("MTK", "user selected image path:"+selectedImagePath);
		}
		
		if(AppManager.isOnline(getActivity())){			
			new AddCustomerAsync().execute();
		}else{
			Y3QueryDataSource datasource = new Y3QueryDataSource(getActivity());
		    datasource.open();
		    //customer.getCustomer().getId()
		    DateFormat dateFormat = new SimpleDateFormat("HHmmss");
			Date date = new Date();
			System.out.println(dateFormat.format(date));
		    
		 /* String  firstLetter = String.valueOf(dateFormat.format(date).toString().charAt(0));
		  if("0".equals(firstLetter)){
			  firstLetter.substring(1);
		  }*/
			String  firstLetter = dateFormat.format(date).toString().replaceFirst("^0+(?!$)", "");	
		  	customer.getCustomer().setId(firstLetter);
		    customer.getCustomer().setImage_path(selectedImagePath);
		    customer.getCustomer().setCreated(AppConstant.getCurrentDateAndTime());
		    customer.getCustomer().setModified(AppConstant.SYNC_NOT_DONE);
		    datasource.addCustomerData(customer, "1", "0");
		    showSaveDialog();
		    SharedPreferences cprefs = getActivity().getSharedPreferences("BGGeoCollector", getActivity().MODE_PRIVATE);
			Editor edt = cprefs.edit();
			edt.putString("cdraftJsonString", null);
			edt.commit();
			isDraft = true;
		    //datasource.close();
		   // Toast.makeText(getActivity(), "Customer added successfully.", Toast.LENGTH_SHORT).show();
	    	
			/*Y3QueryDataSource datasource = new Y3QueryDataSource(getActivity());
		    datasource.open();
		    long result = datasource.addY3Query(Y3QueryDataSource.ACTION_CUSTOMER_ADD, jsonString, selectedImagePath);
		    datasource.close();
		    if(result!=-1)
		    {
		    	Toast.makeText(getActivity(), "Customer added successfully.", Toast.LENGTH_SHORT).show();
		    	getActivity().getSupportFragmentManager().popBackStack();
		    }*/
			
		}
		
		
		
		
		
	/*	Y3QueryDataSource datasource = new Y3QueryDataSource(getActivity());
	    datasource.open();
	    long result = datasource.addY3Query(Y3QueryDataSource.ACTION_CUSTOMER_ADD, jsonString, selectedImagePath);
	    datasource.close();
	    if(result!=-1)
	    {
	    	Toast.makeText(getActivity(), "Customer added successfully.", Toast.LENGTH_SHORT).show();
	    	getActivity().getSupportFragmentManager().popBackStack();
	    }*/
	}
	
	private void addLatLong()
	{
		try
		{
			LocationAjaxCallback lac=new LocationAjaxCallback();
		
			
			lac.weakHandler(this, "locationCB");
			lac.async(getActivity());
		}
		catch(NumberFormatException ex)
		{
			ex.printStackTrace();
		}
	}
	public void locationCB(String url, Location loc, AjaxStatus status)
	{
		aq.id(R.id.editTextLatitude).text(""+loc.getLatitude());
		aq.id(R.id.editTextLongitude).text(""+loc.getLongitude());
	}
	
private class AddCustomerAsync extends AsyncTask<Void, Void, String> {


ProgressDialog progressDialog;

@Override
protected void onPreExecute() {
	super.onPreExecute();
	progressDialog = new ProgressDialog(getActivity());
	progressDialog.setMessage(getString(R.string.wait_progress));
	progressDialog.setCancelable(false);
	progressDialog.setIndeterminate(true);
	progressDialog.show();
	progressDialog
			.setOnKeyListener(new DialogInterface.OnKeyListener() {
				@Override
				public boolean onKey(DialogInterface dialog,
						int keyCode, KeyEvent event) {
					return false;
				}
			});
}


protected String doInBackground(Void... params) {
	String response=null;
	if (AppManager.getInstance().isOnline(aq.getContext())) {
		//return AppManager.getInstance().getCustomerList(aq, pageCount);
		Hashtable<String,String> params1=new Hashtable<String,String>();
		params1.put("jsonString", jsonString);
		Hashtable<String,File> fileParams=null;
		if(selectedImagePath!=null && selectedImagePath.length()>0)
		{
			fileParams=new Hashtable<String,File>();
    		fileParams.put("image", new File(selectedImagePath));
		}
		response = Utils.post(getActivity(), AppManager.getInstance().URL_UPDATE_CUSTOMER, params1, fileParams);
		if(response!=null){
			int errorCode;
			try {
				errorCode = new JSONObject(response).getInt("error");
				if(errorCode==0){
					AppManager.getInstance().getAppSettingData(aq);
				}
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}			
			
		
		}
	}
		return response;

}

protected void onPostExecute(String response) {
	//super.onPostExecute(result);
	
	/*if (result != null && adapter != null) {
		if (result.size() > 0) {
			customerArrayList.addAll(result);
			
			
			adapter.notifyDataSetChanged();
			aqf.id(R.id.buttonLoadMoreListItems).visible();
			if (result.size() < 20) {
				aqf.id(R.id.buttonLoadMoreListItems).invisible();
			}
		} else {
			if (pageCount == 1) {
				Toast.makeText(getActivity(), "Data not found.",
						Toast.LENGTH_SHORT).show();
			}
			adapter.notifyDataSetChanged();
			aqf.id(R.id.buttonLoadMoreListItems).invisible();
		}
	} else {
		Toast.makeText(aq.getContext(), "Network not available.",
				Toast.LENGTH_SHORT).show();
	}*/
	progressDialog.dismiss();
	
	try {
		if(response!=null){
		int errorCode=new JSONObject(response).getInt("error");
		
		if(errorCode==0){
			System.out.println("Added");
			// Toast.makeText(getActivity(), "Customer added successfully.", Toast.LENGTH_SHORT).show();
		    // getActivity().getSupportFragmentManager().popBackStack();
			showSaveDialog();
			SharedPreferences cprefs = getActivity().getSharedPreferences("BGGeoCollector", getActivity().MODE_PRIVATE);
			Editor edt = cprefs.edit();
			edt.putString("cdraftJsonString", null);
			edt.commit();
			isDraft = true;
		}
		else{
			System.out.println("something wrong");
			
		}
		}
	} catch (JSONException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}
}	
	
private void showSaveDialog(){	
	AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
			getActivity());
	alertDialogBuilder.setTitle(getString(R.string.confirm));
	alertDialogBuilder
			.setMessage(getString(R.string.customer_added))
			.setCancelable(false)
			.setPositiveButton(
					getString(R.string.OK),
					new DialogInterface.OnClickListener() {
						public void onClick(
								DialogInterface dialog,
								int id) {
							
							getActivity().getSupportFragmentManager().popBackStack();
							dialog.cancel();
						}
					});
		
	AlertDialog alertDialog = alertDialogBuilder
			.create();
	alertDialog.show();
}
	
	

	
public void caddDraft(){
	if(!isDraft){
		customer=new Customer();
		customer.getCustomer().setFirst_name(aq.id(R.id.editTextFirstName).getEditText().getText().toString());
		customer.getCustomer().setLast_name(aq.id(R.id.editTextLastName).getEditText().getText().toString());
		customer.getCustomer().setEmail(aq.id(R.id.editTextEmail).getEditText().getText().toString());
		customer.getCustomer().setPhone(aq.id(R.id.editTextPhone).getEditText().getText().toString());
		customer.getCustomer().setAddress(aq.id(R.id.editTextAddress).getEditText().getText().toString());
		customer.getCustomer().setCity(aq.id(R.id.editTextCity).getEditText().getText().toString());
		customer.getCustomer().setZipcode(aq.id(R.id.editTextZipcode).getEditText().getText().toString());		
		customer.getCustomer().setLatitude(aq.id(R.id.editTextLatitude).getEditText().getText().toString());
		customer.getCustomer().setLongitude(aq.id(R.id.editTextLongitude).getEditText().getText().toString());
		customer.getCustomer().setDescription(aq.id(R.id.editTextDescription).getEditText().getText().toString());
	
		
		customer.getState().setId(states_id);
		customer.getCustomer().setState_id(states_id);
		customer.getState().setState(aq.id(R.id.buttonState).getButton().getText().toString());
		
		customer.getLgArea().setId(lga_id);
		customer.getCustomer().setLg_area_id(lga_id);
		customer.getLgArea().setName(aq.id(R.id.buttonLGA).getButton().getText().toString());
	
		customer.getRegion().setId(region_id);
		customer.getCustomer().setRegion_id(region_id);
		customer.getRegion().setTitle(aq.id(R.id.buttonRegion).getButton().getText().toString());
		
		customer.getDepot().setId(depot_id);
		customer.getCustomer().setDepot_id(depot_id);
		customer.getDepot().setTitle(aq.id(R.id.buttonDepot).getButton().getText().toString());
		
		customer.getState().setId(route_id);
		customer.getCustomer().setRoute_id(route_id);
		customer.getState().setState(aq.id(R.id.buttonRoute).getButton().getText().toString());
		//System.out.println("ROUTEID"+aq.id(R.id.buttonRoute).getButton().getText().toString());
        

		String cdraftJsonString = customer.createJson(aq,true);		
		SharedPreferences cprefs = getActivity().getSharedPreferences("BGGeoCollector", getActivity().MODE_PRIVATE);
		Editor edt = cprefs.edit();
		edt.putString("cdraftJsonString", cdraftJsonString);
		edt.commit();
		isDraft = true;
	}
}



public void cfillfromDraft(){
	SharedPreferences cprefs = getActivity().getSharedPreferences("BGGeoCollector", getActivity().MODE_PRIVATE);
	String cdraftJsonString = cprefs.getString("cdraftJsonString", null);
	//System.out.println("CUstomerLIST:"+draftJsonString);
	if(cdraftJsonString != null){
		try {
			JSONObject custJson = new JSONObject(cdraftJsonString);
			String FirstName = custJson.isNull("first_name") ? ""	: custJson.getString("first_name");
			aq.id(R.id.editTextFirstName).text(FirstName);
			String LastName = custJson.isNull("last_name") ? ""	: custJson.getString("last_name");
			aq.id(R.id.editTextLastName).text(LastName);
			String Email = custJson.isNull("email") ? ""	: custJson.getString("email");
			aq.id(R.id.editTextEmail).text(Email);
			String PhoneNumber = custJson.isNull("phone") ? ""	: custJson.getString("phone");
			aq.id(R.id.editTextPhone).text(PhoneNumber);
			String Address = custJson.isNull("address") ? ""	: custJson.getString("address");
			aq.id(R.id.editTextAddress).text(Address);
			String City = custJson.isNull("city") ? ""	: custJson.getString("city");
			aq.id(R.id.editTextCity).text(City);
			String Zipcode = custJson.isNull("zipcode") ? ""	: custJson.getString("zipcode");
			aq.id(R.id.editTextZipcode).text(Zipcode);
			String Latitude = custJson.isNull("latitude") ? ""	: custJson.getString("latitude");
			aq.id(R.id.editTextLatitude).text(Latitude);
			String Longitude = custJson.isNull("longitude") ? ""	: custJson.getString("longitude");
			aq.id(R.id.editTextLongitude).text(Longitude);
			String Description = custJson.isNull("description") ? ""	: custJson.getString("description");
			aq.id(R.id.editTextDescription).text(Description);
			
			
			states_id = custJson.isNull("state_id") ? ""	: custJson.getString("state_id");
			States states = AppManager.getInstance().getStates(aq);
			String StateName = states.getDepotNameById(states_id);
			aq.id(R.id.buttonState).text(StateName); 
		
			lga_id = custJson.isNull("lg_area_id") ? ""	: custJson.getString("lg_area_id");
			Lgas lgs = AppManager.getInstance().getLgas(aq);
			String LgName = lgs.getDepotNameById(lga_id);
			aq.id(R.id.buttonLGA).text(LgName); 
			
			
			region_id = custJson.isNull("region_id") ? ""	: custJson.getString("region_id");
			Regions regions = AppManager.getInstance().getRegions(aq);
			String RegionName = regions.getDepotNameById(region_id);
			aq.id(R.id.buttonRegion).text(RegionName); 
			
			
			depot_id = custJson.isNull("depot_id") ? ""	: custJson.getString("depot_id");
			Depots depots = AppManager.getInstance().getDepots(aq);
			String DepotName = depots.getDepotNameById(depot_id);
			aq.id(R.id.buttonDepot).text(DepotName);
			
			route_id = custJson.isNull("route_id") ? ""	: custJson.getString("route_id");
			String RouteName = custJson.isNull("route_name") ? ""	: custJson.getString("route_name");
			aq.id(R.id.buttonRoute).text(RouteName);
		
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}

	
	
	
}
