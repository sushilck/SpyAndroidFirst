package com.smalution.y3distributiong1.fragments.payments;

import com.androidquery.AQuery;

import com.smalution.y3distributiong1.R;
import com.smalution.y3distributiong1.entities.Customer;
import com.smalution.y3distributiong1.entities.payments.Payments;
import com.smalution.y3distributiong1.fragments.SuperFragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

public class PaymentsViewFragment extends SuperFragment {
	
	Payments payment;
	View rootView;
	AQuery aq; 
	public void setUIArguments(final Bundle args) 
	{
	    getActivity().runOnUiThread(new Runnable() 
	    {
	        public void run() 
	        {
	        	payment = args.getParcelable("PAYMENT");
	        }
	    });
	}
	@Override
	public void onCreate(Bundle savedInstanceState) 
	{
		super.onCreate(savedInstanceState);
		payment = getArguments().getParcelable("PAYMENT");
	}
	@Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,Bundle savedInstanceState) 
	{
        rootView = inflater.inflate(R.layout.payments_view_fragment, container, false);
        aq=new AQuery(rootView);
        initUI();
        return rootView;
    }
	private void initUI() 
	{
		aq.id(R.id.textViewUser).text(payment.getUser().getFirst_name()+" "+payment.getUser().getLast_name());
		aq.id(R.id.textViewPaymentRef).text(payment.getPayment().getPayment_ref());
		aq.id(R.id.textViewPaymentMode).text(payment.getPayment().getPayment_mode());
		aq.id(R.id.textViewPaymentDate).text(payment.getPayment().getPayment_date());
		aq.id(R.id.textViewBank).text(payment.getBank().getName());
		aq.id(R.id.textViewAmount).text(payment.getPayment().getAmount());
		aq.id(R.id.textViewCreatedDate).text(payment.getPayment().getCreated());
		aq.id(R.id.textViewSynchronizationData).text(payment.getPayment().getModified());
	}
}
