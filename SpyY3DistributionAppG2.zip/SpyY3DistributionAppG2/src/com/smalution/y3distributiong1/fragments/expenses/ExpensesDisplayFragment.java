package com.smalution.y3distributiong1.fragments.expenses;

import com.smalution.y3distributiong1.AppManager;
import com.smalution.y3distributiong1.R;
import com.smalution.y3distributiong1.SendDataToServerAsyncTask;
import com.smalution.y3distributiong1.Utils;
import com.smalution.y3distributiong1.database.MySQLiteHelper;
import com.smalution.y3distributiong1.database.Y3Query;
import com.smalution.y3distributiong1.database.Y3QueryDataSource;
import com.smalution.y3distributiong1.entities.customer.Customer;
import com.smalution.y3distributiong1.entities.expense.Expense;
import com.smalution.y3distributiong1.fragments.SuperFragment;
import com.smalution.y3distributiong1.geolocatorservice.GPSTrackerService;
import com.smalution.y3distributiong1.quickaction.ActionItem;
import com.smalution.y3distributiong1.quickaction.QuickAction;
import com.smalution.y3distributiong1.utils.AppConstant;

import java.io.File;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;

import org.json.JSONException;
import org.json.JSONObject;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.DataSetObserver;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.androidquery.AQuery;

public class ExpensesDisplayFragment extends SuperFragment {
	
	ListView customerList;
	ArrayAdapter<Expense> adapter;
	ArrayList<Expense> expenseArrayList=new ArrayList<Expense>();
	View rootView;
	AQuery aq; 
	int pageCount=0;
	View foolterLoadMoreView;
	AQuery aqf;
	@Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,Bundle savedInstanceState) 
	{
        rootView = inflater.inflate(R.layout.expenses_display_fragment, container, false);
        aq=new AQuery(rootView);
        pageCount=0;
        expenseArrayList.clear();
        initUI(true);
        initApplication();
       
        return rootView;
    }
	private void initApplication() {
		
		AppConstant. JSONGSTRING=null;
		AppConstant.DELETE_ID=null;
		AppConstant. LOADFILLLISTVIEW=false;		
		AppConstant. OPTION_MODE=null;
		if(AppManager.isOnline(getActivity())){
			// new DeletePaymentfromServer().execute();
			expenseArrayList.clear();
			new ExpensesListAsyncTask(aq).execute();
			
		} else {
			expenseArrayList.clear();
		
			fillLIstView();

	}

		
	}
	
	private void fillLIstView() {
		Y3QueryDataSource datasource = new Y3QueryDataSource(getActivity());
		datasource.open();
		// pageCount = 1;
		expenseArrayList.clear();
		ArrayList<Expense> result = datasource.getAllExpenceQueries();

		if (result.size() > 0) {
			expenseArrayList.addAll(result);

		}
		initUI(false);
		
	}
	
	
	
	
	
	private void initUI(boolean addFooter) 
	{
		aq.id(R.id.buttonRefresh).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				if(AppManager.isOnline(getActivity())){
				pageCount=0;
		        expenseArrayList.clear();
		        initUI(false);
		        new ExpensesListAsyncTask(aq).execute();
				}
			}
		});
		aq.id(R.id.buttonAddNewExpense).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				FragmentManager fragmentManager=getActivity().getSupportFragmentManager();
				FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
				Fragment fragment = fragmentManager.findFragmentByTag("ExpensesAddFragment");
				Bundle bundle=new Bundle();
				if(fragment==null)
				{
					fragment=new ExpensesAddFragment();
					fragment.setArguments(bundle);
					fragmentTransaction.addToBackStack("ExpensesAddFragment");
				}
				else
				{
					((ExpensesAddFragment)fragment).setUIArguments(bundle);
				}
				fragmentTransaction.replace(R.id.frame_container, fragment, "ExpensesAddFragment");
				fragmentTransaction.commit();
			}
		});
		SharedPreferences prefs = AppManager.getInstance().getPrefs(aq.getContext());
		int grade = prefs.getInt("grade", -1);
		if(grade!=-1 && grade==2)
		{
			aq.id(R.id.buttonAddNewExpense).invisible();
		}
		adapter = new ArrayAdapter<Expense>(this.getActivity(), R.layout.expenses_display_listitem, expenseArrayList)
		{
			public View getView(int position, View convertView, ViewGroup parent) 
	        {
	            if(convertView == null)
	            {
                     convertView = getActivity().getLayoutInflater().inflate(R.layout.expenses_display_listitem, parent, false);
	            }
                final Expense expense = getItem(position);
                AQuery aql = new AQuery(convertView);
                position=position+1;
                aql.id(R.id.textViewSerialNo).text(""+position);
                aql.id(R.id.textViewUser).text(expense.getUser().getFirst_name()+" "+expense.getUser().getLast_name());
                aql.id(R.id.textViewAmount).text(expense.getExpense().getExp_amount());
                aql.id(R.id.textViewExpenseDate).text(expense.getExpense().getExp_date());
                final int pos=position;
                aql.id(R.id.quickActionParentLayou).clicked(new OnClickListener() 
                {
					@Override
					public void onClick(View v) 
					{
						showQuickActionPopup(v, expense,pos);
					}
				});
	            return convertView;
	        }
		};
		if(pageCount==0 && addFooter)
		{
			foolterLoadMoreView=LayoutInflater.from(getActivity()).inflate(R.layout.load_more_list_footer, null);
			aqf=new AQuery(foolterLoadMoreView);
			aqf.id(R.id.buttonLoadMoreListItems).clicked(new OnClickListener() 
			{
				@Override
				public void onClick(View v) 
				{
					if(AppManager.isOnline(getActivity()))
						
					{
					//expenseArrayList.clear();
					new ExpensesListAsyncTask(aq).execute();
					}
				}
			});
			aq.id(R.id.customerList).getListView().addFooterView(foolterLoadMoreView, null, true);
		}
		aq.id(R.id.customerList).getListView().setTranscriptMode(AbsListView.TRANSCRIPT_MODE_ALWAYS_SCROLL);
		aq.id(R.id.customerList).adapter(adapter);
		adapter.registerDataSetObserver(new DataSetObserver() 
		{
		    @Override
		    public void onChanged() 
		    {
		        super.onChanged();
		        if(pageCount==1)
		        {
		        	aq.id(R.id.customerList).getListView().setSelection(0);
		        }
		        else
		        {
		        	aq.id(R.id.customerList).getListView().setSelection(adapter.getCount() - 1);
		        }   
		    }
		});
	}
	private void showQuickActionPopup(View anchorView, final Expense expense,final int position)
	{
		final QuickAction mQuickAction = new QuickAction(getActivity());
		
		ActionItem viewAction = new ActionItem();
		viewAction.setTitle(getString(R.string.view));
		viewAction.setIcon(getResources().getDrawable(R.drawable.icon_view));
		mQuickAction.addActionItem(viewAction);
		
		SharedPreferences prefs = AppManager.getInstance().getPrefs(aq.getContext());
		int grade = prefs.getInt("grade", -1);
		if(grade!=-1 && grade!=2)
		{
			ActionItem editAction = new ActionItem();
			editAction.setTitle(getString(R.string.edit));
			editAction.setIcon(getResources().getDrawable(R.drawable.icon_edit));
			mQuickAction.addActionItem(editAction);
		}
			// Upload action item
			ActionItem deleteAction = new ActionItem();
			SharedPreferences prefss = AppManager.getInstance().getPrefs(aq.getContext());
			int grades = prefss.getInt("grade", -1);
			if(grades!=-1 && (grades==1 || grades==3))
			{
			deleteAction.setTitle(getString(R.string.delete));
			deleteAction.setIcon(getResources().getDrawable(R.drawable.icon_delete));
			}
			mQuickAction.addActionItem(deleteAction);
			
		
				
		mQuickAction.setOnActionItemClickListener(new QuickAction.OnActionItemClickListener() 
		{
			public void onItemClick(int pos) 
			{
				if (pos == 0) 
				{ 
					FragmentManager fragmentManager=getActivity().getSupportFragmentManager();
					FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
					Fragment fragment = fragmentManager.findFragmentByTag("ExpensesViewFragment");
					Bundle bundle=new Bundle();
					bundle.putParcelable("EXPENSE", expense);
					if(fragment==null)
					{
						fragment=new ExpensesViewFragment();
						fragment.setArguments(bundle);
						fragmentTransaction.addToBackStack("ExpensesViewFragment");
					}
					else
					{
						((ExpensesViewFragment)fragment).setUIArguments(bundle);
					}
					fragmentTransaction.replace(R.id.frame_container, fragment, "ExpensesViewFragment");
					fragmentTransaction.commit();
				} 
				else if (pos == 1) 
				{ 
					FragmentManager fragmentManager=getActivity().getSupportFragmentManager();
					FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
					Fragment fragment = fragmentManager.findFragmentByTag("ExpensesEditFragment");
					Bundle bundle=new Bundle();
					bundle.putParcelable("EXPENSE", expense);
					if(fragment==null)
					{
						fragment=new ExpensesEditFragment();
						fragment.setArguments(bundle);
						fragmentTransaction.addToBackStack("ExpensesEditFragment");
					}
					else
					{
						((ExpensesEditFragment)fragment).setUIArguments(bundle);
					}
					fragmentTransaction.replace(R.id.frame_container, fragment, "ExpensesEditFragment");
					fragmentTransaction.commit();
				} 
				else if (pos == 2) 
				{ 
					SharedPreferences prefs = AppManager.getInstance().getPrefs(aq.getContext());
					String token = prefs.getString("token", null);
				   final String jsonString="{\"token\":\""+token+"\",\"expense_id\":\""+expense.getExpense().getId()+"\"}";
				    
				    
				   // AppConstant.JSONGSTRING=jsonString;
				    AppConstant.DELETE_ID=expense.getExpense().getId();
				    AppConstant.OPTION_MODE="EXPENCE";
				    if (AppManager.isOnline(getActivity())) {
				    	
				    	 SendDataToServerAsyncTask<Expense> deletor = new SendDataToServerAsyncTask<Expense>(
						    		getActivity(), 
						    		jsonString,
						    		null, 
						    		AppManager.getInstance().URL_DELETE_EXPENSE,
						    		getString(R.string.exp_deleted),
						    		false,
						    		adapter,
						    		expenseArrayList,
						    		position,"");//.execute();
						    AppManager.getInstance().showDeleteConfDialog(getActivity(),deletor);
				    	
				    }else{
				    	
				    	AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
								getActivity());
						alertDialogBuilder.setTitle(getString(R.string.warning));
						alertDialogBuilder
								.setMessage(getString(R.string.confirm_delete))
								.setCancelable(false)
								.setPositiveButton(
										getString(R.string.yes),
										new DialogInterface.OnClickListener() {
											public void onClick(
													DialogInterface dialog,
													int id) {
												Y3QueryDataSource datasource = new Y3QueryDataSource(getActivity());
												datasource.open();												
												long result = datasource.addY3Query(Y3QueryDataSource.ACTION_EXPENCE_DELETE,jsonString,null);									 
												if (result != -1)
												{
													if (datasource.deleteExpenceSingleRecord(expense.getExpense().getId()))
													{
														AppConstant.LOADFILLLISTVIEW=true;
														Toast.makeText(getActivity(),getString(R.string.exp_deleted),Toast.LENGTH_SHORT).show();														
														expenseArrayList.clear();
														fillLIstView();
													}
												}					
												
												datasource.close();

											}
										})
								.setNegativeButton(
										getString(R.string.no),
										new DialogInterface.OnClickListener() {
											public void onClick(
													DialogInterface dialog,
													int id) {
												dialog.cancel();
											}
										});
						AlertDialog alertDialog = alertDialogBuilder
								.create();
						alertDialog.show();
				    }
				    
				   				    
				   
				} 
			}
		});
		mQuickAction.show(anchorView);
		mQuickAction.setAnimStyle(QuickAction.ANIM_GROW_FROM_CENTER);
	}
	private class ExpensesListAsyncTask extends AsyncTask<Void, Void, ArrayList<Expense>>
	{
		AQuery aq;
		ProgressDialog progressDialog;
		public ExpensesListAsyncTask(AQuery aq)
		{
			this.aq=aq;
			pageCount=pageCount+1;
		}
		@Override
		protected void onPreExecute() 
		{
			super.onPreExecute();
			if(getActivity()==null){
				progressDialog = new ProgressDialog(aq.getContext());
			}else{
				progressDialog = new ProgressDialog(getActivity());
			}
			
	        progressDialog.setMessage(getString(R.string.wait_progress));
	        progressDialog.setCancelable(false);
	        progressDialog.setIndeterminate(true);
	        progressDialog.show();
	        progressDialog.setOnKeyListener(new DialogInterface.OnKeyListener() 
	        {
	            @Override
	            public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) 
	            {
	                return false;
	            }
	        });
		}
		@Override
		protected ArrayList<Expense> doInBackground(Void... params) 
		{
			if(AppManager.getInstance().isOnline(aq.getContext()))
			{
				return AppManager.getInstance().getExpenseList(aq, pageCount);
			}
			return null;
		}
		@Override
		protected void onPostExecute(ArrayList<Expense> result) 
		{
			super.onPostExecute(result);
			if(result!=null && adapter!=null)
			{
				if(result.size()>0)
				{
					expenseArrayList.addAll(result);
					adapter.notifyDataSetChanged();
					aqf.id(R.id.buttonLoadMoreListItems).visible();
					if(result.size()<20)
					{
						aqf.id(R.id.buttonLoadMoreListItems).invisible();
					}
				}
				else
				{
					if(pageCount==1)
					{
						Toast.makeText(getActivity(), getString(R.string.no_data), Toast.LENGTH_SHORT).show();
					}
					adapter.notifyDataSetChanged();
					aqf.id(R.id.buttonLoadMoreListItems).invisible();
				}
			}
			else
			{
				Toast.makeText(aq.getContext(), getString(R.string.no_data), Toast.LENGTH_SHORT).show();
			}
			
			progressDialog.dismiss();
		}
	}
	
}
