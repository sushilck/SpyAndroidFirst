package com.smalution.y3distributiong1.entities.settings;

public class SelectionButtonItem implements Comparable<SelectionButtonItem>
{
	String id;
	String objectId;
	String title;
	public SelectionButtonItem(String id, String objectId, String title)
	{
		this.id=id;
		this.objectId=objectId;
		this.title=title;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getObjectId() {
		return objectId;
	}
	public void setObjectId(String objectId) {
		this.objectId = objectId;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	@Override
	public int compareTo(SelectionButtonItem otherItem) 
	{
		int res = String.CASE_INSENSITIVE_ORDER.compare(this.title, otherItem.title);
		return (res != 0) ? res : this.title.compareTo(otherItem.title);
	}
}
