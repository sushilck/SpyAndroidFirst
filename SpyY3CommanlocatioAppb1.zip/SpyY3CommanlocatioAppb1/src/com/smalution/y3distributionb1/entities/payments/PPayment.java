package com.smalution.y3distributionb1.entities.payments;


import org.json.JSONObject;

import com.smalution.y3distributionb1.entities.Expense;

import android.os.Parcel;
import android.os.Parcelable;

public class PPayment implements Parcelable
{
	private String payment_date;
    private String depot_id;
    private String distributor_id;
    private String brand_id;
    private String transaction_id;
    private String modified;
    private String amount;
    private String bank_id;
    private String id;
    private String payment_ref;
    private String title;
    private String created;
    private String payment_mode;
    private String user_id;
    private String notes;
    public PPayment(){}
	public PPayment(JSONObject jsonObect)
	{
		try
		{
			payment_date=jsonObect.isNull("payment_date")?"":jsonObect.getString("payment_date");
		    depot_id=jsonObect.isNull("depot_id")?"":jsonObect.getString("depot_id");
		    distributor_id=jsonObect.isNull("distributor_id")?"":jsonObect.getString("distributor_id");
		    brand_id=jsonObect.isNull("brand_id")?"":jsonObect.getString("brand_id");
		    transaction_id=jsonObect.isNull("transaction_id")?"":jsonObect.getString("transaction_id");
		    modified=jsonObect.isNull("modified")?"":jsonObect.getString("modified");
		    amount=jsonObect.isNull("amount")?"":jsonObect.getString("amount");
		    bank_id=jsonObect.isNull("bank_id")?"":jsonObect.getString("bank_id");
		    id=jsonObect.isNull("id")?"":jsonObect.getString("id");
		    payment_ref=jsonObect.isNull("payment_ref")?"":jsonObect.getString("payment_ref");
		    title=jsonObect.isNull("title")?"":jsonObect.getString("title");
		    created=jsonObect.isNull("created")?"":jsonObect.getString("created");
		    payment_mode=jsonObect.isNull("payment_mode")?"":jsonObect.getString("payment_mode");
		    user_id=jsonObect.isNull("user_id")?"":jsonObect.getString("user_id");
		    notes=jsonObect.isNull("notes")?"":jsonObect.getString("notes");
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	public PPayment(Parcel in)
 	{
		payment_date = in.readString();
	    depot_id = in.readString();
	    distributor_id = in.readString();
	    brand_id = in.readString();
	    transaction_id = in.readString();
	    modified = in.readString();
	    amount = in.readString();
	    bank_id = in.readString();
	    id = in.readString();
	    payment_ref = in.readString();
	    title = in.readString();
	    created = in.readString();
	    payment_mode = in.readString();
	    user_id = in.readString();
	    notes = in.readString();
	}
 	@Override
 	public int describeContents() 
 	{
 		return 0;
 	}
 	@Override
 	public void writeToParcel(Parcel dest, int flags) 
 	{
 		dest.writeString(payment_date);
 	    dest.writeString(depot_id);
 	    dest.writeString(distributor_id);
 	    dest.writeString(brand_id);
 	    dest.writeString(transaction_id);
 	    dest.writeString(modified);
 	    dest.writeString(amount);
 	    dest.writeString(bank_id);
 	    dest.writeString(id);
 	    dest.writeString(payment_ref);
 	    dest.writeString(title);
 	    dest.writeString(created);
 	    dest.writeString(payment_mode);
 	    dest.writeString(user_id);
 	    dest.writeString(notes);
 	}
 	public static final Parcelable.Creator<PPayment> CREATOR = new Parcelable.Creator<PPayment>() 
 	{
 		public PPayment createFromParcel(Parcel in) 
 		{
 			return new PPayment(in);
 		}
 	
 		public PPayment[] newArray (int size) 
 		{
 			return new PPayment[size];
 		}
 	};
	public String getPayment_date() {
		return payment_date;
	}
	public void setPayment_date(String payment_date) {
		this.payment_date = payment_date;
	}
	public String getDepot_id() {
		return depot_id;
	}
	public void setDepot_id(String depot_id) {
		this.depot_id = depot_id;
	}
	public String getDistributor_id() {
		return distributor_id;
	}
	public void setDistributor_id(String distributor_id) {
		this.distributor_id = distributor_id;
	}
	public String getBrand_id() {
		return brand_id;
	}
	public void setBrand_id(String brand_id) {
		this.brand_id = brand_id;
	}
	public String getTransaction_id() {
		return transaction_id;
	}
	public void setTransaction_id(String transaction_id) {
		this.transaction_id = transaction_id;
	}
	public String getModified() {
		return modified;
	}
	public void setModified(String modified) {
		this.modified = modified;
	}
	public String getAmount() {
		return amount;
	}
	public void setAmount(String amount) {
		this.amount = amount;
	}
	public String getBank_id() {
		return bank_id;
	}
	public void setBank_id(String bank_id) {
		this.bank_id = bank_id;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPayment_ref() {
		return payment_ref;
	}
	public void setPayment_ref(String payment_ref) {
		this.payment_ref = payment_ref;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getCreated() {
		return created;
	}
	public void setCreated(String created) {
		this.created = created;
	}
	public String getPayment_mode() {
		return payment_mode;
	}
	public void setPayment_mode(String payment_mode) {
		this.payment_mode = payment_mode;
	}
	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	public String getNotes() {
		return notes;
	}
	public void setNotes(String notes) {
		this.notes = notes;
	}
	
}
