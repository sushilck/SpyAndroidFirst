package com.smalution.y3distributioncmr1.entities.settings;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONObject;

public class Redistributors 
{
	ArrayList<SelectionButtonItem> redistributors;
	String[] name;
	public Redistributors(){}
	public Redistributors(JSONArray jsonArray)
	{
		try
		{
			redistributors=new ArrayList<SelectionButtonItem>();
			name=new String[jsonArray.length()];
			for(int i=0;i<jsonArray.length();i++)
			{
				JSONObject jsonObject = jsonArray.getJSONObject(i); 
				String id=jsonObject.isNull("id")?"":jsonObject.getString("id");
				String value=jsonObject.isNull("value")?"":jsonObject.getString("value");
				SelectionButtonItem itm=new SelectionButtonItem(id, "", value);
				
				redistributors.add(itm);
				name[i]=itm.getTitle();
			}
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	public String getDepotNameById(String id)
	{
		for(SelectionButtonItem itm:redistributors)
		{
			if(itm.getId().equals(id))
				return itm.getTitle();
		}
		return null;
	}
	public SelectionButtonItem getItem(int position)
	{
		return redistributors.get(position);
	}
	public String[] getName() {
		return name;
	}
	public void setName(String[] name) {
		this.name = name;
	}
}
