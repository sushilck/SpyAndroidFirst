package com.smalution.y3distributionlg1.fragments.expenses;

import com.smalution.y3distributionlg1.AppManager;
import com.smalution.y3distributionlg1.R;
import com.smalution.y3distributionlg1.Utils;
import com.smalution.y3distributionlg1.database.Y3QueryDataSource;
import com.smalution.y3distributionlg1.entities.User;
import com.smalution.y3distributionlg1.entities.expense.Expense;
import com.smalution.y3distributionlg1.entities.settings.Brands;
import com.smalution.y3distributionlg1.entities.settings.Depots;
import com.smalution.y3distributionlg1.entities.settings.ExpenseTypeList;
import com.smalution.y3distributionlg1.fragments.SuperFragment;
import com.smalution.y3distributionlg1.utils.AppConstant;
import com.smalution.y3distributionlg1.utils.DatePickerFragment;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Hashtable;

import org.json.JSONException;
import org.json.JSONObject;

import android.app.AlertDialog;
import android.app.DatePickerDialog.OnDateSetListener;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.DatePicker;
import android.widget.Toast;

import com.androidquery.AQuery;

public class ExpensesAddFragment extends SuperFragment {
	
	Expense expense;
	View rootView;
	AQuery aq; 
	public static final int FLAG_SELECT_EXPENSETYPE=101;
	public static final int FLAG_SELECT_DEPOT=102;
	public static final int FLAG_SELECT_BRAND=103;
//	public static final int FLAG_SELECT_PAYMENTMODE=104;
	UIHandler uiHandler;
	private String jsonStr; 
	private boolean flagIsAddMore;
	public int userGrade;
	public  String depot_id;
	public  String exp_type_id;
	public boolean isDraft = false;
	public class UIHandler extends Handler 
	{ 
        public void handleMessage(Message msg) 
        { 
        	switch(msg.arg1)
        	{
//	        	case FLAG_SELECT_PAYMENTMODE:
//	    		{
//	    			String selectedValue=(String)msg.obj;
//	    			aq.id(R.id.buttonPaymentMode).text(selectedValue);
//	    			expense.getExpense().setPayment_mode(selectedValue);
//	    			break;
//				}
        		case FLAG_SELECT_EXPENSETYPE:
        		{
        			String selectedValue=(String)msg.obj;
        			aq.id(R.id.buttonExpenseType).text(selectedValue);
        			ExpenseTypeList expenseTypeList=AppManager.getInstance().getExpenseType(aq);
        			if(expenseTypeList!=null)
        			{
        				exp_type_id = expenseTypeList.getItem(msg.arg2).getId();
        				expense.getExpense().setExp_type_id(expenseTypeList.getItem(msg.arg2).getId());
        			}
        			expense.getExpType().setName(selectedValue);
        			break;
				}
        		case FLAG_SELECT_DEPOT:
        		{
        			String selectedValue=(String)msg.obj;
        			aq.id(R.id.buttonDepot).text(selectedValue);
        			Depots depots=AppManager.getInstance().getDepots(aq);
        			if(depots!=null)
        			{
        				depot_id = depots.getItem(msg.arg2).getId();
        				expense.getExpense().setDepot_id(depots.getItem(msg.arg2).getId());
        			}
        			
        			break;
        		}
        		case FLAG_SELECT_BRAND:
        		{
        			String selectedValue=(String)msg.obj;
        			aq.id(R.id.buttonBrand).text(selectedValue);
        			Brands brands = AppManager.getInstance().getBrands(aq);
        			if(brands!=null)
        			{
        				expense.getExpense().setBrand_id(brands.getItem(msg.arg2).getId());	
        			}
        			break;
        		}
        	}
        }
    };
	public void setUIArguments(final Bundle args) 
	{
	    getActivity().runOnUiThread(new Runnable() 
	    {
	        public void run() 
	        {
	        	
	        }
	    });
	}
	@Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,Bundle savedInstanceState) 
	{
        rootView = inflater.inflate(R.layout.expenses_add_fragment, container, false);
        expense=new Expense();
        uiHandler=new UIHandler();
        aq=new AQuery(rootView);
        flagIsAddMore=false;
        initUI();
        efillfromDraft();
        return rootView;
    }
	
	public void onPause(){
		super.onPause();
		System.out.println("This is OnPause activity");
		eaddDraft();
	}
	
	public void onStop(){
		super.onStop();
		System.out.println("This is onStop activity");
		eaddDraft();
	}
	
	public void onDestroy(){
		super.onDestroy();
		System.out.println("This is onDestroy activity");
		eaddDraft();
	}
	
	private void initUI() 
	{
		final SharedPreferences prefs=getActivity().getSharedPreferences("BGGeoCollector", getActivity().MODE_PRIVATE);
		userGrade = prefs.getInt("grade", 0);
		if (userGrade > 3 ){
			aq.id(R.id.tableRowDepot).gone();
		}
		aq.id(R.id.buttonExpenseType).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				boolean flag=false;
				ExpenseTypeList expenseTypeList=AppManager.getInstance().getExpenseType(aq);
				if(expenseTypeList!=null)
				{
					String[] arr = expenseTypeList.getName();
					if(arr.length>0)
					{
						AppManager.getInstance().showSelectionAlertDialog(getActivity(), uiHandler, FLAG_SELECT_EXPENSETYPE, arr);
						flag=true;
					}
				}
				if(!flag)
				{
					Toast.makeText(getActivity(), getString(R.string.exptype_required_mess), Toast.LENGTH_SHORT).show();
				}
			}
		});
		aq.id(R.id.buttonDepot).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				boolean flag=false;
				Depots depots=AppManager.getInstance().getDepots(aq);
				if(depots!=null)
				{
					String[] arr=depots.getTitleArr();
					if(arr.length>0)
					{
						AppManager.getInstance().showSelectionAlertDialog(getActivity(), uiHandler, FLAG_SELECT_DEPOT, arr);
						flag=true;
					}
				}
				if(!flag)
				{
					Toast.makeText(getActivity(), getString(R.string.depot_req_mess), Toast.LENGTH_SHORT).show();
				}
			}
		});
		/*aq.id(R.id.buttonBrand).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				boolean flag=false;
				Brands brands = AppManager.getInstance().getBrands(aq);
				if(brands!=null)
				{
					String[] arr=brands.getBrandsNames();
					if(arr.length>0)
					{
						AppManager.getInstance().showSelectionAlertDialog(getActivity(), uiHandler, FLAG_SELECT_BRAND, arr);
						flag=true;
					}
				}
				if(!flag)
				{
					Toast.makeText(getActivity(), getString(R.string.brand_required_mess), Toast.LENGTH_SHORT).show();
				}
			}
		});*/
		/*aq.id(R.id.buttonPaymentMode).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				boolean flag=false;
				PaymentModes paymentModes=AppManager.getInstance().getPaymentModes(aq);
				if(paymentModes!=null)
				{
					String[] arr=paymentModes.getName();
					if(arr.length>0)
					{
						AppManager.getInstance().showSelectionAlertDialog(getActivity(), uiHandler, FLAG_SELECT_PAYMENTMODE, arr);
						flag=true;
					}
				}
				if(!flag)
				{
					Toast.makeText(getActivity(), "PaymentMode are required field, please contact administrator.", Toast.LENGTH_SHORT).show();
				}
			}
		});*/
		
		aq.id(R.id.editTextDate).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				showDatePicker();
			}
		});
		aq.id(R.id.buttonSave).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				if(validateInput())
				{
					
				    jsonStr = expense.createJson(aq, false);
					
					if(AppManager.isOnline(getActivity()))
					{
						flagIsAddMore=false;
						new AddExpenceAsync().execute();
						
					}else{
						
						
					    
					    
					    final SharedPreferences prefs=getActivity().getSharedPreferences("BGGeoCollector", getActivity().MODE_PRIVATE);
						String str = prefs.getString("user_object", "");
						final String token = prefs.getString("token", null);
						if(str!="")
						{
							try
							{
								JSONObject userJSONObject = new JSONObject(str);
								final User user=new User(userJSONObject);
								expense.getUser().setFirst_name(user.getFirst_name());
								expense.getUser().setLast_name(user.getLast_name());
								
								SharedPreferences eprefs = getActivity().getSharedPreferences("BGGeoCollector", getActivity().MODE_PRIVATE);
								Editor edt = eprefs.edit();
								edt.putString("edraftJsonString", null);
								edt.commit();
								isDraft = true;
							}
							catch(Exception e){
								
							}
						}
					
					    DateFormat dateFormat = new SimpleDateFormat("HHmmss");
						Date date = new Date();
						System.out.println(dateFormat.format(date));
						String  firstLetter = dateFormat.format(date).toString().replaceFirst("^0+(?!$)", "");						 
						expense.getExpense().setId(firstLetter);						
						expense.getExpense().setCreated(AppConstant.getCurrentDateAndTime());
						expense.getExpense().setModified(AppConstant.SYNC_NOT_DONE);
						Y3QueryDataSource datasource = new Y3QueryDataSource(getActivity());
					    datasource.open();
					    datasource.addExpenceData(expense,"1");	
					    showSaveDialog();
					    //Toast.makeText(getActivity(), "Expenses added successfully.", Toast.LENGTH_SHORT).show();
				    	//getActivity().getSupportFragmentManager().popBackStack();	    
						
						
					}
										
				/*	
					Y3QueryDataSource datasource = new Y3QueryDataSource(getActivity());
				    datasource.open();
				    long result = datasource.addY3Query(Y3QueryDataSource.ACTION_EXPENSE_ADD, jsonStr, null);
				    datasource.close();
				    if(result!=-1)
				    {
				    	Toast.makeText(getActivity(), "Expense added successfully.", Toast.LENGTH_SHORT).show();
				    	getActivity().getSupportFragmentManager().popBackStack();
				    }*/
				}
			}
		});
		aq.id(R.id.buttonSaveAddMore).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				if(validateInput())
				{
					
					jsonStr = expense.createJson(aq, false);
					
					if(AppManager.isOnline(getActivity()))
					{
						flagIsAddMore=true;
						new AddExpenceAsync().execute();
						
					}else{
						
				
					    final SharedPreferences prefs=getActivity().getSharedPreferences("BGGeoCollector", getActivity().MODE_PRIVATE);
						String str = prefs.getString("user_object", "");
						final String token = prefs.getString("token", null);
						if(str!="")
						{
							try
							{
								JSONObject userJSONObject = new JSONObject(str);
								final User user=new User(userJSONObject);
								expense.getUser().setFirst_name(user.getFirst_name());
								expense.getUser().setLast_name(user.getLast_name());
							}
							catch(Exception e){
								
							}
						}
					
					    DateFormat dateFormat = new SimpleDateFormat("HHmmss");
						Date date = new Date();
						System.out.println(dateFormat.format(date));
						String  firstLetter = String.valueOf(dateFormat.format(date).toString().charAt(0));
						  if("0".equals(firstLetter))
						  {
							  firstLetter.substring(1);
						  }
						expense.getExpense().setId(firstLetter);
						Y3QueryDataSource datasource = new Y3QueryDataSource(getActivity());
					    datasource.open();
					    datasource.addExpenceData(expense,"1");			
					    showSaveMoreDialog();
					   // Toast.makeText(getActivity(), "Expenses added successfully.", Toast.LENGTH_SHORT).show();
					    //initFeilds();
				}
			}
			}
		});
	}
	private void initFeilds() 
	{
		aq.id(R.id.editTextExpenseDetails).text("");
		aq.id(R.id.buttonExpenseType).text("");
		aq.id(R.id.buttonPaymentMode).text("");
		aq.id(R.id.buttonDepot).text("");
		aq.id(R.id.buttonBrand).text("");
		aq.id(R.id.editTextExpenseRef).text("");
		aq.id(R.id.editTextExpenseAmount).text("");
		aq.id(R.id.editTextDate).text("");
		expense=new Expense();
	}
	private void showDatePicker() 
	{
		  DatePickerFragment date = new DatePickerFragment();
		  Calendar calender = Calendar.getInstance();
		  Bundle args = new Bundle();
		  args.putInt("year", calender.get(Calendar.YEAR));
		  args.putInt("month", calender.get(Calendar.MONTH));
		  args.putInt("day", calender.get(Calendar.DAY_OF_MONTH));
		  date.setArguments(args);
		  date.setCallBack(ondate);
		  date.show(getActivity().getSupportFragmentManager(), "Date Picker");
	}
	OnDateSetListener ondate = new OnDateSetListener() 
	{
		@Override
		public void onDateSet(DatePicker view, int year, int monthOfYear,int dayOfMonth) 
		{
			String dateStr=String.valueOf(year) + "-" + String.valueOf(monthOfYear+1)+ "-" + String.valueOf(dayOfMonth);
			aq.id(R.id.editTextDate).text(dateStr);
			expense.getExpense().setExp_date(dateStr);
		}
	};
	private boolean validateInput() 
	{
			String expenseDetail =aq.id(R.id.editTextExpenseDetails).getText().toString();
			
				expense.getExpense().setDescription(expenseDetail);
				String expenseType = aq.id(R.id.buttonExpenseType).getText().toString();
				if(expenseType!=null && expenseType.length()>0)
				{
//					String paymentMode =aq.id(R.id.buttonPaymentMode).getText().toString();
//					if(paymentMode!=null && paymentMode.length()>0)
//					{
						String depot = aq.id(R.id.buttonDepot).getText().toString();
						if(depot!=null && depot.length()>0 || userGrade > 3)
						{
							//String brand =aq.id(R.id.buttonBrand).getText().toString();
							//if(brand!=null && brand.length()>0)
							//{
								String expenseRef =aq.id(R.id.editTextExpenseRef).getText().toString();
								
									expense.getExpense().setExpense_ref(expenseRef);
									String expenseAmount =aq.id(R.id.editTextExpenseAmount).getText().toString();
									if(expenseAmount!=null && expenseAmount.length()>0
											&& AppManager.getInstance().isValidNumber(expenseAmount))
									{
										try
										{
											Float.parseFloat(expenseAmount);
											expense.getExpense().setExp_amount(expenseAmount);
											String expenseDate =aq.id(R.id.editTextDate).getText().toString();
											if(expenseDate!=null && expenseDate.length()>0)
											{
												expense.getExpense().setExp_date(expenseDate);
												return true;
											}
											else
											{
												Toast.makeText(getActivity(), getString(R.string.pls_enter_expdate), Toast.LENGTH_SHORT).show();
											}
										}
										catch(Exception ex)
										{
											Toast.makeText(getActivity(), getString(R.string.pls_enter_amt), Toast.LENGTH_SHORT).show();
										}
										
									}
									else
									{
										Toast.makeText(getActivity(), getString(R.string.pls_enter_exp_amount), Toast.LENGTH_SHORT).show();
									}
								/*}
								else
								{
									Toast.makeText(getActivity(), "Please enter expense ref", Toast.LENGTH_SHORT).show();
								}*/
							//}
							//else
							//{
							//	Toast.makeText(getActivity(), getString(R.string.select_brand), Toast.LENGTH_SHORT).show();
							//}
						}
						else
						{
							Toast.makeText(getActivity(), getString(R.string.select_depot), Toast.LENGTH_SHORT).show();
						}
//					}
//					else
//					{
//						Toast.makeText(getActivity(), "Please select payment mode", Toast.LENGTH_SHORT).show();
//					}
				}
				else
				{
					Toast.makeText(getActivity(), getString(R.string.select_exp_type), Toast.LENGTH_SHORT).show();
				}
			
			/*else
			{
				Toast.makeText(getActivity(), "Please enter expense details", Toast.LENGTH_SHORT).show();
			}*/
		
		return false;
	}
	private class AddExpenceAsync extends AsyncTask<Void, Void, String> {


		ProgressDialog progressDialog;

		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			progressDialog = new ProgressDialog(getActivity());
			progressDialog.setMessage(getString(R.string.wait_progress));
			progressDialog.setCancelable(false);
			progressDialog.setIndeterminate(true);
			progressDialog.show();
			progressDialog
					.setOnKeyListener(new DialogInterface.OnKeyListener() {
						@Override
						public boolean onKey(DialogInterface dialog,
								int keyCode, KeyEvent event) {
							return false;
						}
					});
		}


		protected String doInBackground(Void... params1) {
			if (AppManager.getInstance().isOnline(aq.getContext()))
			{
				Hashtable<String,String> params=new Hashtable<String,String>();
	    		params.put("jsonString", jsonStr);
	    		String response = Utils.post(getActivity(), AppManager.getInstance().URL_UPDATE_EXPENSE, params, null);
	    		return response;
			}
			return null;
		}

		protected void onPostExecute(String response) {
			
			progressDialog.dismiss();
			
			try {
				if(response!=null){
				int errorCode=new JSONObject(response).getInt("error");
				
				if(errorCode==0){
					System.out.println("Added");
					if(flagIsAddMore){
						//Toast.makeText(getActivity(), "Expenses added successfully.", Toast.LENGTH_SHORT).show();
						showSaveMoreDialog();
						
						//initFeilds();
					}else{
						 //Toast.makeText(getActivity(), "Expenses added successfully.", Toast.LENGTH_SHORT).show();
						 //getActivity().getSupportFragmentManager().popBackStack();
						showSaveDialog();
						SharedPreferences eprefs = getActivity().getSharedPreferences("BGGeoCollector", getActivity().MODE_PRIVATE);
						Editor edt = eprefs.edit();
						edt.putString("edraftJsonString", null);
						edt.commit();
						isDraft = true;
					}
					
					 
				}
				else{
					
					Toast.makeText(getActivity(), getString(R.string.something_wrong), Toast.LENGTH_SHORT).show();
					System.out.println("something wrong");
					
					}
				}
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		}	
	
	
	
	private void showSaveDialog(){	
		AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
				getActivity());
		alertDialogBuilder.setTitle(getString(R.string.confirm));
		alertDialogBuilder
				.setMessage(getString(R.string.exp_added))
				.setCancelable(false)
				.setPositiveButton(
						getString(R.string.OK),
						new DialogInterface.OnClickListener() {
							public void onClick(
									DialogInterface dialog,
									int id) {
								
								getActivity().getSupportFragmentManager().popBackStack();
								dialog.cancel();
							}
						});
			
		AlertDialog alertDialog = alertDialogBuilder
				.create();
		alertDialog.show();
	}
	
	private void showSaveMoreDialog(){	
		AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
				getActivity());
		alertDialogBuilder.setTitle(getString(R.string.confirm));
		alertDialogBuilder
				.setMessage(getString(R.string.exp_added))
				.setCancelable(false)
				.setPositiveButton(
						getString(R.string.OK),
						new DialogInterface.OnClickListener() {
							public void onClick(
									DialogInterface dialog,
									int id) {
								
								//getActivity().getSupportFragmentManager().popBackStack();
								initFeilds();
								dialog.cancel();
							}
						});
			
		AlertDialog alertDialog = alertDialogBuilder
				.create();
		alertDialog.show();
	}
	
	
	public void eaddDraft(){
		if(!isDraft){		
			//expense=new Expense();
			expense.getExpense().setDescription	(aq.id(R.id.editTextExpenseDetails).getEditText().getText().toString());
			expense.getExpense().setExpense_ref(aq.id(R.id.editTextExpenseRef).getEditText().getText().toString());
			expense.getExpense().setExp_amount(aq.id(R.id.editTextExpenseAmount).getEditText().getText().toString());
			expense.getExpense().setExp_date(aq.id(R.id.editTextDate).getEditText().getText().toString());
			
			
		
			expense.getExpense().setId(depot_id);
			expense.getExpense().setDepot_id(depot_id);
			expense.getExpense().setTitle(aq.id(R.id.buttonDepot).getButton().getText().toString());
			
	
			expense.getExpType().setId(exp_type_id);
			expense.getExpense().setExp_type_id(exp_type_id);
			expense.getExpType().setName(aq.id(R.id.buttonExpenseType).getButton().getText().toString());
			//System.out.println("EXPENSETYPENAME:"+aq.id(R.id.buttonExpenseType).getButton().getText().toString());
			
			
			String edraftJsonString = expense.createJson(aq,true);
			SharedPreferences eprefs = getActivity().getSharedPreferences("BGGeoCollector", getActivity().MODE_PRIVATE);
			Editor edt = eprefs.edit();
			edt.putString("edraftJsonString", edraftJsonString);
			edt.commit();
			isDraft = true;
		}
	}
	
	
	
	public void efillfromDraft(){
		SharedPreferences eprefs = getActivity().getSharedPreferences("BGGeoCollector", getActivity().MODE_PRIVATE);
		String edraftJsonString = eprefs.getString("edraftJsonString", null);
		//System.out.println("LISTEXPENSE:"+edraftJsonString);
		if(edraftJsonString != null){
			try {
				JSONObject ExpenseJson = new JSONObject(edraftJsonString);
				String ExpenseDetails = ExpenseJson.isNull("description") ? ""	: ExpenseJson.getString("description");
				aq.id(R.id.editTextExpenseDetails).text(ExpenseDetails);
				String ExpenseRef = ExpenseJson.isNull("expense_ref") ? ""	: ExpenseJson.getString("expense_ref");
				aq.id(R.id.editTextExpenseRef).text(ExpenseRef);
				String ExpenseAmount = ExpenseJson.isNull("exp_amount") ? ""	: ExpenseJson.getString("exp_amount");
				aq.id(R.id.editTextExpenseAmount).text(ExpenseAmount);
				String Date = ExpenseJson.isNull("exp_date") ? ""	: ExpenseJson.getString("exp_date");
				aq.id(R.id.editTextDate).text(Date);
			
				exp_type_id = ExpenseJson.isNull("exp_type_id") ? ""	: ExpenseJson.getString("exp_type_id");
				//String EpenseTypeName = ExpenseJson.isNull("expense_name") ? ""	: ExpenseJson.getString("expense_name");
				ExpenseTypeList expense_type_list = AppManager.getInstance().getExpenseType(aq);
				String EpenseTypeName = expense_type_list.getExpenseTypeNameById(exp_type_id);
				aq.id(R.id.buttonExpenseType).text(EpenseTypeName); 
				
				depot_id = ExpenseJson.isNull("depot_id") ? ""	: ExpenseJson.getString("depot_id");
				Depots depots = AppManager.getInstance().getDepots(aq);
				String DepotName = depots.getDepotNameById(depot_id);
				aq.id(R.id.buttonDepot).text(DepotName); 
				
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}
	
}
