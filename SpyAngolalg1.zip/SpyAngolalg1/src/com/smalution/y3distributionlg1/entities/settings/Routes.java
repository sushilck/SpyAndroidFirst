package com.smalution.y3distributionlg1.entities.settings;

import java.util.ArrayList;
import org.json.JSONArray;
import org.json.JSONObject;

public class Routes 
{
	private ArrayList<SelectionButtonItem> routes;
	String titleArr[];
	public Routes(){}
	public Routes(JSONArray jsonArray)
	{
		try
		{
			routes=new ArrayList<SelectionButtonItem>();
			titleArr=new String[jsonArray.length()]; 
			
			for(int i=0;i<jsonArray.length();i++)
			{
				JSONObject jsonObject = jsonArray.getJSONObject(i); 
				String id=jsonObject.isNull("id")?"":jsonObject.getString("id");
				String title=jsonObject.isNull("title")?"":jsonObject.getString("title");
				String region_id=jsonObject.isNull("region_id")?"":jsonObject.getString("region_id");
				//String depot_id=jsonObject.isNull("depot_id")?"":jsonObject.getString("depot_id");
				SelectionButtonItem itm=new SelectionButtonItem(id, region_id, title);
				
				routes.add(itm);
				titleArr[i]=itm.getTitle();
			}
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	public String getRouteNameById(String id)
	{
		for(SelectionButtonItem itm:routes)
		{
			if(itm.getId().equals(id))
				return itm.getTitle();
		}
		return null;
	}
	public SelectionButtonItem getItem(int position)
	{
		return routes.get(position);
	}
	public String[] getTitleArr() {
		return titleArr;
	}
	public void setTitleArr(String[] titleArr) {
		this.titleArr = titleArr;
	}
	public ArrayList<SelectionButtonItem> getRoutes() {
		return routes;
	}
	public void setRoutes(ArrayList<SelectionButtonItem> routes) {
		this.routes = routes;
	}
	
}
