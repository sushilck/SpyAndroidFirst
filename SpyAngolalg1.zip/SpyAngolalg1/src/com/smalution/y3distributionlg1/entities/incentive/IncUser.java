package com.smalution.y3distributionlg1.entities.incentive;

import org.json.JSONObject;

import android.os.Parcel;
import android.os.Parcelable;

public class IncUser implements Parcelable
{
	private String first_name;
    private String last_name;
    
    public IncUser(){}
	public IncUser(JSONObject jsonObect)
	{
		try
		{
			first_name=jsonObect.isNull("first_name")?"":jsonObect.getString("first_name");
			last_name=jsonObect.isNull("last_name")?"":jsonObect.getString("last_name");
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	public IncUser(Parcel in)
 	{
		first_name = in.readString();
		last_name = in.readString();
	}
 	@Override
 	public int describeContents() 
 	{
 		return 0;
 	}
 	@Override
 	public void writeToParcel(Parcel dest, int flags) 
 	{
 		dest.writeString(first_name);
 	    dest.writeString(last_name);
 	}
 	public static final Parcelable.Creator<IncUser> CREATOR = new Parcelable.Creator<IncUser>() 
 	{
 		public IncUser createFromParcel(Parcel in) 
 		{
 			return new IncUser(in);
 		}
 	
 		public IncUser[] newArray (int size) 
 		{
 			return new IncUser[size];
 		}
 	};

	public String getFirst_name() {
		return first_name;
	}
	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}
	public String getLast_name() {
		return last_name;
	}
	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}

}
