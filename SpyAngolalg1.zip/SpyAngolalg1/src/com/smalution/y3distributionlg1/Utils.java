package com.smalution.y3distributionlg1;

import java.io.File;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

import org.json.JSONObject;

import com.androidquery.AQuery;
import com.androidquery.callback.AjaxCallback;
import com.androidquery.callback.AjaxStatus;

import android.content.Context;
import android.util.Log;

public class Utils 
{
	public static void log(String msg)
	{
		Log.d("MTK", msg);
	}
	public static String post(Context context, String url, Hashtable<String, String> stringParams ,Hashtable<String, File> filesParams )
	{
		try 
		{
			Utils.log("post url:"+url);
			Map<String, Object> params = new HashMap<String, Object>();
	        if(stringParams!=null)
			{
				Set<Entry<String, String>> set = stringParams.entrySet();
				Iterator<Entry<String, String>> itr = set.iterator();
				Utils.log("post params:");
				while(itr.hasNext())
				{
					Entry<String, String> entry = itr.next();
					params.put(entry.getKey(), entry.getValue());
					Utils.log(entry.getKey()+"="+entry.getValue());
				}
			}
	        
	        if(filesParams!=null)
			{
				Set<Entry<String, File>> set2 = filesParams.entrySet();
				Iterator<Entry<String, File>> itr2 = set2.iterator();
				while(itr2.hasNext())
				{
					Entry<String, File> entry = itr2.next();
					File f = entry.getValue();
					params.put(entry.getKey(), f);
					Utils.log(entry.getKey()+"="+entry.getValue()+" = "+entry.getValue().length()+"=="+f.exists());
				}
			}
	        AQuery aq = new AQuery(context.getApplicationContext());
	        AjaxCallback<JSONObject> cb = new AjaxCallback<JSONObject>();
	        cb.url(url).params(params).type(JSONObject.class);
	        aq.sync(cb);
	        JSONObject jo = cb.getResult();
	        AjaxStatus status = cb.getStatus();
	        if(jo!=null)
	        	Utils.log("Post Result :"+jo.toString());
			return jo.toString();
	    } 
		catch (Exception ex) 
		{
			
			
			ex.printStackTrace();
		}
		return null;
	}
}
