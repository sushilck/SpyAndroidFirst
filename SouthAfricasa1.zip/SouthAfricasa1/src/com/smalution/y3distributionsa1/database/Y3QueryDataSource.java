package com.smalution.y3distributionsa1.database;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import com.smalution.y3distributionsa1.database.MySQLiteHelper;
import com.smalution.y3distributionsa1.entities.customer.Customer;
import com.smalution.y3distributionsa1.entities.customervisits.CustomerVisit;
import com.smalution.y3distributionsa1.entities.distributor.Distributor;
import com.smalution.y3distributionsa1.entities.expense.Expense;
import com.smalution.y3distributionsa1.entities.incentive.IncentiveItem;
import com.smalution.y3distributionsa1.entities.payments.Payments;
import com.smalution.y3distributionsa1.entities.salesorder.SalesOrder;
import com.smalution.y3distributionsa1.entities.settings.Customers;
import com.smalution.y3distributionsa1.utils.AppConstant;
import com.smalution.y3distributionsa1.utils.StuffData;

public class Y3QueryDataSource {
	public final static String ACTION_CUSTOMER_ADD = "ACTION_CUSTOMER_ADD";
	public final static String ACTION_CUSTOMERVISIT_ADD = "ACTION_CUSTOMERVISIT_ADD";
	public final static String ACTION_SALESORDER_ADD = "ACTION_SALESORDER_ADD";
	public final static String ACTION_OFFLINE_SALESORDER_ADD = "ACTION_OFFLINE_SALESORDER_ADD";
	public final static String ACTION_DISTRIBUTOR_SALESORDER_ADD = "ACTION_DISTRIBUTOR_SALESORDER_ADD";
	public final static String ACTION_PAYMENT_ADD = "ACTION_PAYMENT_ADD";
	public final static String ACTION_EXPENSE_ADD = "ACTION_EXPENSE_ADD";
	public final static String ACTION_INCENTIVE_ADD = "ACTION_INCENTIVE_ADD";
	
	
	// THIS IS FOR DELETE OPREATION....
	public final static String ACTION_CUSTOMER_DELETE = "ACTION_CUSTOMER_DELETE";
	public final static String ACTION_CUSTOMER_VISITING_DELETE = "ACTION_CUSTOMER_VISITING_DELETE";
	public final static String ACTION_SALES_DELETE="ACTION_SALES_DELETE";
	public final static String ACTION_DISTRIBUTOR_SALES_DELETE="ACTION_DISTRIBUTOR_SALES_DELETE";	
	public final static String ACTION_PAYMENT_DELETE="ACTION_PAYMENT_DELETE";
	public final static String ACTION_EXPENCE_DELETE="ACTION_EXPENCE_DELETE";
	public final static String ACTION_INCENTIVE_DELETE="ACTION_INCENTIVE_DELETE";
	// Database fields
	private SQLiteDatabase database;
	private MySQLiteHelper dbHelper;
	private String[] allColumns = { MySQLiteHelper.COLUMN_ID,
			MySQLiteHelper.COLUMN_ACTION, MySQLiteHelper.COLUMN_JSON,
			MySQLiteHelper.COLUMN_IMAGE };

	public Y3QueryDataSource(Context ct)
	{
		
		dbHelper = new MySQLiteHelper(ct);
		
	}


	public void open() throws SQLException {
		
		database = dbHelper.getWritableDatabase();
		//System.out.println("open data test");
	}

	public void close() {
		
		dbHelper.close();
	}

	public long addY3Query(String action, String json, String image) {
		ContentValues values = new ContentValues();
		values.put(MySQLiteHelper.COLUMN_ACTION, action);
		values.put(MySQLiteHelper.COLUMN_JSON, json);
		values.put(MySQLiteHelper.COLUMN_STATUS, "PENDING");
		values.put(MySQLiteHelper.COLUMN_SERVERLOG, "OFFLINE");
		values.put(MySQLiteHelper.COLUMN_SERVERLOGDETAIL,"Waiting for internet");
		if (image != null)
			values.put(MySQLiteHelper.COLUMN_IMAGE, image);

		long insertId = database.insert(MySQLiteHelper.TABLE_QUERIES, null,
				values);
		return insertId;
	}
	
	
	public void deleteAllQueries() {
		try {
			database.delete(MySQLiteHelper.TABLE_QUERIES, null, null);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void insertServerLog(long id, String status, String server_log,
			String server_log_detail) {
		ContentValues values = new ContentValues();
		values.put(MySQLiteHelper.COLUMN_STATUS, status);
		values.put(MySQLiteHelper.COLUMN_SERVERLOG, server_log);
		values.put(MySQLiteHelper.COLUMN_SERVERLOGDETAIL, server_log_detail);
		int insertId = database.update(MySQLiteHelper.TABLE_QUERIES, values,
				MySQLiteHelper.COLUMN_ID + "=" + id, null);
		Log.d("MTK", "ServerInsert Result:" + insertId);
	}

	public ArrayList<ServerLog> getServerLogs() {

		ArrayList<ServerLog> logs = new ArrayList<ServerLog>();
		String[] allServerLogColumns = { MySQLiteHelper.COLUMN_ID,
				MySQLiteHelper.COLUMN_ACTION, MySQLiteHelper.COLUMN_JSON,
				MySQLiteHelper.COLUMN_IMAGE, MySQLiteHelper.COLUMN_STATUS,
				MySQLiteHelper.COLUMN_SERVERLOG,
				MySQLiteHelper.COLUMN_SERVERLOGDETAIL };

		Cursor cursor = database.query(MySQLiteHelper.TABLE_QUERIES,
				allServerLogColumns, null, null, null, null, null);

		cursor.moveToFirst();
		while (!cursor.isAfterLast()) {
			ServerLog log = cursorToServerLog(cursor);
			logs.add(log);
			cursor.moveToNext();
		}
		// make sure to close the cursor
		cursor.close();
		return logs;
	}

	//private String[] allCustomerColumn = {MySQLiteHelper.ID, MySQLiteHelper.CUSTOMERJSON };

	public boolean deleteY3Query(long id) {
		int affectedRow = database.delete(MySQLiteHelper.TABLE_QUERIES,
				MySQLiteHelper.COLUMN_ID + " = " + id, null);
		return affectedRow != 0;
	}

	public List<Y3Query> getAllY3Queries() {
		List<Y3Query> y3Queries = new ArrayList<Y3Query>();

		Cursor cursor = database.query(MySQLiteHelper.TABLE_QUERIES,
				allColumns, null, null, null, null, null);

		cursor.moveToFirst();
		while (!cursor.isAfterLast()) {
			Y3Query y3query = cursorToY3Query(cursor);
			y3Queries.add(y3query);
			cursor.moveToNext();
		}
		// make sure to close the cursor
		cursor.close();
		return y3Queries;
	}

	private Y3Query cursorToY3Query(Cursor cursor) {
		Y3Query y3query = new Y3Query();
		y3query.set_id(cursor.getLong(0));
		y3query.setAction(cursor.getString(1));
		y3query.setJson(cursor.getString(2));
		y3query.setImage(cursor.getString(3));
		return y3query;
	}

	private ServerLog cursorToServerLog(Cursor cursor) {
		ServerLog log = new ServerLog();
		log.set_id(cursor.getLong(0));
		log.setAction(cursor.getString(1));
		log.setJson(cursor.getString(2));
		log.setImage(cursor.getString(3));
		log.setStatus(cursor.getString(4));
		log.setServerlog(cursor.getString(5));
		log.setServerlogdetail(cursor.getString(6));
		return log;
	}

	public Hashtable<String, String> getOfflineCustomers() {
		Hashtable<String, String> offlineCustomers = new Hashtable<String, String>();
		try {
			String[] allServerLogColumns = { MySQLiteHelper.COLUMN_JSON };
			Cursor cursor = database.query(MySQLiteHelper.TABLE_QUERIES,
					allServerLogColumns, MySQLiteHelper.COLUMN_ACTION + "=?",
					new String[] { Y3QueryDataSource.ACTION_CUSTOMER_ADD },
					null, null, null);
			cursor.moveToFirst();
			while (!cursor.isAfterLast()) {
				String jsonStr = cursor.getString(0);
				JSONObject jsonObject = new JSONObject(jsonStr);
				String name = jsonObject.getString("first_name") + " "
						+ jsonObject.getString("last_name");
				offlineCustomers.put(name, jsonStr);
				cursor.moveToNext();
			}
			cursor.close();
		} catch (Exception ex) 
		{
			ex.printStackTrace();
		}
		return offlineCustomers;
	}

	public void addCustomerData(String jsonString) {
		ContentValues values = new ContentValues();
		values.put(MySQLiteHelper.CUSTOMERJSON, jsonString);

		try {

			long success = database.insert(MySQLiteHelper.TABLE_NAME, null,	values);
			
		} catch (SQLException e) {
			System.out.println("Exception in Add data in Customers data");
			e.printStackTrace();
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("Exception in Add data in Customers data");
			e.printStackTrace();
		}

	}
	
	//Add Customer List
	
	public void updateCustomerList(String customerData, boolean deleteAll){
		
		try {
			JSONArray CustomerJsonArray = new JSONArray(customerData);
			int totalCustomer = CustomerJsonArray.length();
			//System.out.println("Total Customer to be Add: "+ totalCustomer  );
			//Delete all
			if (true == deleteAll){
				database.delete(MySQLiteHelper.CUSTOMER_LIST_TABLE_NAME, null, null);
			}
			for (int i = 0; i < totalCustomer; i++){
				JSONObject jsonCustObject = CustomerJsonArray.getJSONObject(i); 
				String id = jsonCustObject.isNull("id")?"":jsonCustObject.getString("id");
				String value = jsonCustObject.isNull("value")?"":jsonCustObject.getString("value");
				
				String depotId = jsonCustObject.isNull("depot_id")?"":jsonCustObject.getString("depot_id");
				String regionId = jsonCustObject.isNull("region_id")?"":jsonCustObject.getString("region_id");

				String category = jsonCustObject.isNull("category_id") ? "":jsonCustObject.getString("category_id");
				String subcategory = jsonCustObject.isNull("sub_category_id") ? "":jsonCustObject.getString("sub_category_id");
				String payment_term = jsonCustObject.isNull("payment_term") ? "":jsonCustObject.getString("payment_term");
				
				ContentValues values = new ContentValues();
				values.put(MySQLiteHelper.ID, id);
				values.put(MySQLiteHelper.CUSTOMER_DEPOTID, depotId);
				values.put(MySQLiteHelper.CUSTOMER_REGIONID, regionId);
				values.put(MySQLiteHelper.CUSTOMER_NAME, value);
				
				values.put(MySQLiteHelper.CATEGORY, category);
				values.put(MySQLiteHelper.SUB_CATEGORY, subcategory);
				values.put(MySQLiteHelper.PAYMENT_TERM, payment_term);
				database.insert(MySQLiteHelper.CUSTOMER_LIST_TABLE_NAME, null, values);
				//System.out.println("Customer Added with ID: "+id+"Name: "+value);
				
			}
			
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	

	public Customers searchCustomer(String q){
		
		String query="SELECT * FROM "+MySQLiteHelper.CUSTOMER_LIST_TABLE_NAME+" WHERE "+MySQLiteHelper.CUSTOMER_NAME+" LIKE '"+q+"%' ORDER BY "+
				MySQLiteHelper.CUSTOMER_NAME+" ASC LIMIT 20"; 
	    Cursor cursor = database.rawQuery(query, null);	
	  //  System.out.println(cursor.getCount());
		cursor.moveToFirst();
		 JSONObject custObj = null;
	     JSONArray custJsonArray = new JSONArray();
		try {
			//int i =0;
			
			while (!cursor.isAfterLast()) 
			{				
				String cusotomerID = cursor.getString(cursor.getColumnIndex(MySQLiteHelper.ID));
				String cusotomerName = cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CUSTOMER_NAME));
				String depotId = cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CUSTOMER_DEPOTID));
				String regionId = cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CUSTOMER_REGIONID));
				
				String category = cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CATEGORY));
				String subcategory = cursor.getString(cursor.getColumnIndex(MySQLiteHelper.SUB_CATEGORY));
				String paymentterm = cursor.getString(cursor.getColumnIndex(MySQLiteHelper.PAYMENT_TERM));
				
				custObj = new JSONObject();
				
				custObj.put("id", cusotomerID);
				custObj.put("value", cusotomerName);
				custObj.put("depot_id", depotId);
				custObj.put("region_id", regionId);

				custObj.put("category", category);
				custObj.put("subcategory", subcategory);
				custObj.put("paymentterm", paymentterm);
				
				custJsonArray.put(custObj);
				cursor.moveToNext();
			}
			cursor.close();
		}
		catch (Exception e) {
			//System.out.println("ERROR@@@@@@ In "+MySQLiteHelper.CUSTOMER_LIST_TABLE_NAME);
			e.printStackTrace();
		}
		return new Customers(custJsonArray);
	}
	
	public int totalCustomer(){
		String countQuery = "SELECT * FROM " + MySQLiteHelper.CUSTOMER_LIST_TABLE_NAME;
		Cursor cursor = database.rawQuery(countQuery, null);
	    int cnt = cursor.getCount();
		return cnt;
	}
	public Object minMaxCutomerId(){
		
		long maxCustomerId = 0;
		long minCustomerId = 0;
		JSONObject cids = new JSONObject();
	    Cursor c = database.query(MySQLiteHelper.CUSTOMER_LIST_TABLE_NAME, new String[] {"MAX("+ MySQLiteHelper.ID + ")"}, null, null, null, null, null, null); 
	    try {
	        c.moveToFirst();
	        maxCustomerId = c.getInt(0);
	        try {
				cids.put("maxCustomerId", maxCustomerId);
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    } finally {
	        c.close();
	    }
	    
	    Cursor c2 = database.query(MySQLiteHelper.CUSTOMER_LIST_TABLE_NAME, new String[] {"MIN("+ MySQLiteHelper.ID + ")"}, null, null, null, null, null, null); 
	    try {
	        c2.moveToFirst();
	        minCustomerId = c2.getInt(0);
	        try {
				cids.put("minCustomerId", minCustomerId);
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    } finally {
	        c.close();
	    }
	    return cids;    
	}
	/*public boolean deleteCustomerData(int id) {

		int affectedRow = database.delete(MySQLiteHelper.TABLE_NAME,
				MySQLiteHelper.ID + " = " + id, null);
		return affectedRow != 0;
	}
*/
	/*public ArrayList<Customer> getAllCustomerQueries() {
		ArrayList<Customer> list = new ArrayList<Customer>();
		list.clear();
		try {
			Cursor cursor = database.query(MySQLiteHelper.TABLE_NAME,
					allCustomerColumn, null, null, null, null, null);
			System.out.println(cursor.getCount());
			cursor.moveToFirst();
			try {
				while (!cursor.isAfterLast()) {
					JSONObject jObj = new JSONObject(cursor.getString(1));
					System.out.println(cursor.getString(0));
					list.add(new Customer(jObj,cursor.getInt(0)));
					
					cursor.moveToNext();
					}
				cursor.close();
				}
			catch (Exception e) {
				System.out.println("ERROR@@@@@@");
				e.printStackTrace();
			}

		} catch (Exception e) {

			e.printStackTrace();
		}
		return list;

	}*/
	
	

	public void deleteAllRecordFromDB() {
		try {
			database.delete(MySQLiteHelper.TABLE_NAME, null, null);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	/// this is for sales
	//----------------------------------------------------------------------------
	//SALES SECTION
	private String[] allSalesColumn = {MySQLiteHelper.ID, MySQLiteHelper.SALES_ISOFFLINEADDED,MySQLiteHelper.SALES_OFFLINE_ADDEDJON,MySQLiteHelper.SALESJSON };
	
	public void addSalesData(String jsonString,String offlineJson,String isofflineadded) {
		ContentValues values = new ContentValues();
		values.put(MySQLiteHelper.SALES_ISOFFLINEADDED, isofflineadded);// this is  1 or 0
		values.put(MySQLiteHelper.SALESJSON, jsonString);// this is online json added....
		values.put(MySQLiteHelper.SALES_OFFLINE_ADDEDJON, offlineJson);

		try {

			long success = database.insert(MySQLiteHelper.SALES_TABLE_NAME, null,	values);
			
		} catch (SQLException e) {
			System.out.println("Exception in Add data in SALES_TABLE_NAME");
			e.printStackTrace();
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("Exception in Add data in SALES_TABLE_NAME");
			e.printStackTrace();
		}

	}
	
	public ArrayList<SalesOrder> getAllSalesQueries() {
		ArrayList<SalesOrder> list = new ArrayList<SalesOrder>();
		list.clear();
		try {
			Cursor cursor = database.query(MySQLiteHelper.SALES_TABLE_NAME,allSalesColumn, null, null, null, null, null);
			//System.out.println(cursor.getCount());
			cursor.moveToFirst();
			try {
				while (!cursor.isAfterLast()) 
				 {				
					
					JSONObject jObj = new JSONObject(cursor.getString(cursor.getColumnIndex(MySQLiteHelper.SALESJSON)));	
					String deleteId=cursor.getString(cursor.getColumnIndex(MySQLiteHelper.ID));
					list.add(new SalesOrder(jObj,Integer.parseInt(deleteId),cursor.getString(cursor.getColumnIndex(MySQLiteHelper.SALESJSON)),cursor.getString(cursor.getColumnIndex(MySQLiteHelper.SALES_ISOFFLINEADDED)),cursor.getString(cursor.getColumnIndex(MySQLiteHelper.SALES_OFFLINE_ADDEDJON))));					
					cursor.moveToNext();
					}
				cursor.close();
				}
			catch (Exception e) {
				System.out.println("ERROR@@@@@@ In SaleData");
				e.printStackTrace();
			}

		} catch (Exception e) {

			e.printStackTrace();
		}
		return list;

	}
	public void deleteAllSalesRecordFromDB() {
		try {
			database.delete(MySQLiteHelper.SALES_TABLE_NAME, null, null);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}	
	
	public boolean deleteSalesrData(int id) {

		int affectedRow = database.delete(MySQLiteHelper.SALES_TABLE_NAME,
				MySQLiteHelper.ID + " = " + id, null);
		return affectedRow != 0;
	}
	public Cursor getSalesData(){
		Cursor cursor = database.query(MySQLiteHelper.SALES_TABLE_NAME,allSalesColumn, null, null, null, null, null);
		return cursor;
		
	}
	
	public void salesUpdateAdd(String salesId){
		ContentValues values = new ContentValues();
		values.put(MySQLiteHelper.SALES_ISOFFLINEADDED, "0");
		
		try{
			long result= database.update(MySQLiteHelper.SALES_TABLE_NAME, values, MySQLiteHelper.ID + "=" + salesId, null);
			System.out.println("This is update result"+result);
		}
			catch(Exception e)
			{
				e.printStackTrace();
			}
	}
	
//---------------------------------------------------------------------------------------------------------
	// this is for redistributor table..
	
private String[] allredistributorsalesDetailsColumn = {
		MySQLiteHelper.ID, 
		MySQLiteHelper.REDISTRIBUTORJSON,
		MySQLiteHelper.REDISTRIBUTORJSON_ISOFFLINEADDED,
		MySQLiteHelper.REDISTRIBUTORJSON_OFFLINE_ASSEDJSON
		};
	
	public void addRedistributorSaleData(String jsonString,String isofflineAdded,String isofflineAdded_json) {
		ContentValues values = new ContentValues();
		values.put(MySQLiteHelper.REDISTRIBUTORJSON, jsonString);
		values.put(MySQLiteHelper.REDISTRIBUTORJSON_ISOFFLINEADDED, isofflineAdded);
		values.put(MySQLiteHelper.REDISTRIBUTORJSON_OFFLINE_ASSEDJSON, isofflineAdded_json);

		try {

			long success = database.insert(MySQLiteHelper.REDISTRIBUTOR_SALES_TABLE_NAME, null,	values);
			
		} catch (SQLException e) {
			System.out.println("Exception in Add data in ReDis sales");
			e.printStackTrace();
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("Exception in Add data in ReDis sales");
			e.printStackTrace();
		}

	}
	
	public ArrayList<Distributor> getAllRedistributorQueries() {
		ArrayList<Distributor> list = new ArrayList<Distributor>();
		list.clear();
		try {
			Cursor cursor = database.query(MySQLiteHelper.REDISTRIBUTOR_SALES_TABLE_NAME,
					allredistributorsalesDetailsColumn, null, null, null, null, null);
			System.out.println(cursor.getCount());
			cursor.moveToFirst();
			try {
				while (!cursor.isAfterLast()) {
					JSONObject jObj = new JSONObject(cursor.getString(1));	
					//list.add(new SalesOrder(jObj,Integer.parseInt(deleteId),cursor.getString(cursor.getColumnIndex(MySQLiteHelper.SALESJSON)),cursor.getString(cursor.getColumnIndex(MySQLiteHelper.SALES_ISOFFLINEADDED)),cursor.getString(cursor.getColumnIndex(MySQLiteHelper.SALES_OFFLINE_ADDEDJON))));					
					list.add(new Distributor(jObj,cursor.getInt(0),cursor.getString(cursor.getColumnIndex(MySQLiteHelper.REDISTRIBUTORJSON)),cursor.getString(cursor.getColumnIndex(MySQLiteHelper.REDISTRIBUTORJSON_ISOFFLINEADDED)),cursor.getString(cursor.getColumnIndex(MySQLiteHelper.REDISTRIBUTORJSON_OFFLINE_ASSEDJSON))));					
					cursor.moveToNext();
					}
				cursor.close();
				}
			catch (Exception e) {
				System.out.println("ERROR@@@@@@ In REDISTRIBUTOR_SALES_TABLE_NAME");
				e.printStackTrace();
			}

		} catch (Exception e) {

			e.printStackTrace();
		}
		return list;

	}
	public void deleteAllRedistributorsRecordFromDB() {
		try {
			database.delete(MySQLiteHelper.REDISTRIBUTOR_SALES_TABLE_NAME, null, null);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}	
	
	public boolean deleteRedistibutorSalesData(int id) {

		int affectedRow = database.delete(MySQLiteHelper.REDISTRIBUTOR_SALES_TABLE_NAME,
				MySQLiteHelper.ID + " = " + id, null);
		return affectedRow != 0;
	}	
	
	
	public Cursor getRedistibutorSalesdata(){
		Cursor cursor = database.query(MySQLiteHelper.REDISTRIBUTOR_SALES_TABLE_NAME,allredistributorsalesDetailsColumn, null, null, null, null, null);
		return cursor;
		
	}
	public void distributorUpdateAdd(String distributorId){
		ContentValues values = new ContentValues();
		values.put(MySQLiteHelper.REDISTRIBUTORJSON_ISOFFLINEADDED, "0");
		
		try{
			long result= database.update(MySQLiteHelper.REDISTRIBUTOR_SALES_TABLE_NAME, values, MySQLiteHelper.ID + "=" + distributorId, null);
			System.out.println("This is update result"+result);
		}
			catch(Exception e)
			{
				e.printStackTrace();
			}
	}
	
//-------------------------------------------------------------------------------------------------------------
	public void addCustomerData(
	com.smalution.y3distributionsa1.entities.customer.Customer customer,String isOffLineAdd,String isoffLineEdit) {
		ContentValues values = new ContentValues();
		values.put(MySQLiteHelper.CUSTOMER_ID, customer.getCustomer().getId());
		values.put(MySQLiteHelper.FIRST_NAME, customer.getCustomer().getFirst_name());
		values.put(MySQLiteHelper.LAST_NAME, customer.getCustomer().getLast_name());
		values.put(MySQLiteHelper.EMAIL_ID, customer.getCustomer().getEmail());
		
		values.put(MySQLiteHelper.CATEGORYID, customer.getCustomer().getCategory_id());
		values.put(MySQLiteHelper.SUBCATEGORYID, customer.getCustomer().getSub_category_id());
		values.put(MySQLiteHelper.PAYMENTTERM, customer.getCustomer().getPayment_term());
		values.put(MySQLiteHelper.ROUTE_ID, customer.getCustomer().getRoute_id());
		
		values.put(MySQLiteHelper.ADDRESS, customer.getCustomer().getAddress());
		values.put(MySQLiteHelper.CITY, customer.getCustomer().getCity());
		values.put(MySQLiteHelper.LATITUDE, customer.getCustomer().getLatitude());
		values.put(MySQLiteHelper.LONGITUDE, customer.getCustomer().getLongitude());
		values.put(MySQLiteHelper.ZIPCODE, customer.getCustomer().getZipcode());
		values.put(MySQLiteHelper.PHONE, customer.getCustomer().getPhone());
		values.put(MySQLiteHelper.DESCRIPTION, customer.getCustomer().getDescription());
		values.put(MySQLiteHelper.AMOUNT, customer.getCustomer().getAmount());
		values.put(MySQLiteHelper.VIEW_DETAILS, customer.getCustomer().getView_details());
		values.put(MySQLiteHelper.STATUS, customer.getCustomer().getStatus());
		values.put(MySQLiteHelper.IMAGE_PATH, customer.getCustomer().getImage_path());
		values.put(MySQLiteHelper.SNO, customer.getSno());
		values.put(MySQLiteHelper.ASSIGNTO, customer.getToAssignOptionSelectedJSON());
		values.put(MySQLiteHelper.USER_ID, customer.getCustomer().getUser_id());
		
		values.put(MySQLiteHelper.DEPOT_ID, customer.getDepot().getId());
		values.put(MySQLiteHelper.DEPOT, customer.getDepot().getTitle());
		
		values.put(MySQLiteHelper.STATE_ID, customer.getState().getId());
		values.put(MySQLiteHelper.STATE, customer.getState().getState());
		
		values.put(MySQLiteHelper.REGION_ID, customer.getRegion().getId());
		values.put(MySQLiteHelper.REGION, customer.getRegion().getTitle());
		
		values.put(MySQLiteHelper.LGAREA_ID, customer.getLgArea().getId());
		values.put(MySQLiteHelper.LGAREA, customer.getLgArea().getName());
		values.put(MySQLiteHelper.SYNCHRONIZATION, customer.getCustomer().getModified());
		values.put(MySQLiteHelper.CREATED_DATE, customer.getCustomer().getCreated());		
		values.put(MySQLiteHelper.REQUEST_ID, AppConstant.ANDROIDDEVICEID+AppConstant.getRequestId());		
		values.put(MySQLiteHelper.ISOFFLINEADDED, isOffLineAdd);
		values.put(MySQLiteHelper.ISOFFLINEEDITED, isoffLineEdit);

		try {

			long l=database.insert(MySQLiteHelper.CUSTOMERS_TABLE_NAME, null, values);
			//System.out.println("INSERTVALUE"+l);
		} catch (Exception e) {
			//System.out.println("Exception in Add data in Customers data");
			e.printStackTrace();
		}

	}	
	

	
	private String[] allCustomerRow = { MySQLiteHelper.CUSTOMER_ID,
			MySQLiteHelper.FIRST_NAME, MySQLiteHelper.LAST_NAME,
			MySQLiteHelper.EMAIL_ID, MySQLiteHelper.CATEGORYID, MySQLiteHelper.SUBCATEGORYID, MySQLiteHelper.PAYMENTTERM,
			MySQLiteHelper.ADDRESS, MySQLiteHelper.ROUTE_ID,
			MySQLiteHelper.CITY, MySQLiteHelper.USER_ID,
			MySQLiteHelper.LATITUDE, MySQLiteHelper.LONGITUDE,
			MySQLiteHelper.ZIPCODE, MySQLiteHelper.PHONE,
			MySQLiteHelper.DESCRIPTION, MySQLiteHelper.AMOUNT,
			MySQLiteHelper.VIEW_DETAILS, MySQLiteHelper.STATUS,
			MySQLiteHelper.IMAGE_PATH,MySQLiteHelper.SNO,MySQLiteHelper.ASSIGNTO,
			MySQLiteHelper.ISOFFLINEADDED,MySQLiteHelper.ISOFFLINEEDITED,
			MySQLiteHelper.CREATED_DATE, MySQLiteHelper.REQUEST_ID,
			// this is for ddepot..
			MySQLiteHelper.DEPOT_ID, MySQLiteHelper.DEPOT,
			MySQLiteHelper.SYNCHRONIZATION,

			// this is for state;
			MySQLiteHelper.STATE_ID, MySQLiteHelper.STATE,
			// user LgArea
			MySQLiteHelper.LGAREA_ID, MySQLiteHelper.LGAREA,
			// user Region
			MySQLiteHelper.REGION_ID, MySQLiteHelper.REGION };
	
	public ArrayList<Customer> getAllCustomerQueries() {
		ArrayList<Customer> list = new ArrayList<Customer>();
		list.clear();
		try {
			Cursor cursor = database.query(MySQLiteHelper.CUSTOMERS_TABLE_NAME,
					allCustomerRow, null, null, null, null, null);
			cursor.moveToFirst();
			while (!cursor.isAfterLast()) {

				
				try{
					
				StuffData stuffData = new StuffData();
				String customeJson=stuffData.getCustomerJson(cursor,"Customer");
				JSONObject jsonObject = new JSONObject(customeJson);
				JSONArray jsonArray = jsonObject.getJSONArray("data");
				for (int i = 0; i < jsonArray.length(); i++) 
				{
					list.add(new Customer(jsonArray.getJSONObject(i) ,1));
				}
				}catch(JSONException e)
				{
					e.printStackTrace();
				}
				
				

				cursor.moveToNext();
			}
			cursor.close();
			

		} catch (Exception e) {

			e.printStackTrace();
		}
		return list;

	}
	
	public Hashtable<String, String> getOfflineCustomeData(String token) {
		Hashtable<String, String> offlineCustomers = new Hashtable<String, String>();
		try {
			//String[] allServerLogColumns = { MySQLiteHelper.COLUMN_JSON };
			Cursor cursor = database.query(MySQLiteHelper.CUSTOMERS_TABLE_NAME,
					allCustomerRow, MySQLiteHelper.ISOFFLINEADDED + "=?",
					new String[] { "1"},
					null, null, null);
			cursor.moveToFirst();
			
			while (!cursor.isAfterLast()) {
				
				String view_details;
				if("1".equals(cursor.getString(cursor.getColumnIndex(MySQLiteHelper.VIEW_DETAILS)))){
					view_details="true";
				}else{
					view_details="false";
				}
				
				String json="{" +
						"\"token\":\""+token+"\","+
						"\"first_name\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.FIRST_NAME))+"\"," +
						"\"last_name\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.LAST_NAME))+"\"," +
						"\"email\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.EMAIL_ID))+"\"," +
						"\"route_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.ROUTE_ID))+"\"," +
						"\"category_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CATEGORYID))+"\"," +
						"\"sub_category_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.SUBCATEGORYID))+"\"," +
						"\"payment_term\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.PAYMENTTERM))+"\"," +
						
						"\"address\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.ADDRESS))+"\"," +
						"\"city\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CITY))+"\"," +
						"\"state_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.STATE_ID))+"\"," +
						"\"latitude\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.LATITUDE))+"\"," +
						"\"longitude\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.LONGITUDE))+"\"," +
						"\"zipcode\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.ZIPCODE))+"\"," +
						"\"phone\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.PHONE))+"\"," +
						"\"region_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.REGION_ID))+"\"," +
						"\"depot_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.DEPOT_ID))+"\"," +
						"\"lg_area_id\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.LGAREA_ID))+"\"," +
						"\"description\":\""+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.DESCRIPTION))+"\"," +						
						"\"view_details\":\""+view_details+"\"" +"}";
						
				
				//String jsonStr = cursor.getString(0);
				JSONObject jsonObject = new JSONObject(json);				
				String name = jsonObject.getString("first_name") + " "
						+ jsonObject.getString("last_name");
				offlineCustomers.put(name, json);
				cursor.moveToNext();
			}
			cursor.close();
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return offlineCustomers;
	}
	
	public void updateISAdded(String customerId){
		ContentValues values = new ContentValues();
		values.put(MySQLiteHelper.ISOFFLINEADDED, "0");
		
		try{
			long result= database.update(MySQLiteHelper.CUSTOMERS_TABLE_NAME, values, MySQLiteHelper.CUSTOMER_ID + "=" + customerId, null);
			//System.out.println("This is update result"+result);
		}
			catch(Exception e)
			{
				e.printStackTrace();
			}
	}
	
	public void updateISUpdated(String customerId){
		ContentValues values = new ContentValues();
		values.put(MySQLiteHelper.ISOFFLINEEDITED, "0");
		
		try{
			long result= database.update(MySQLiteHelper.CUSTOMERS_TABLE_NAME, values, MySQLiteHelper.CUSTOMER_ID + "=" + customerId, null);
			System.out.println("This is update result"+result);
		}
			catch(Exception e)
			{
				e.printStackTrace();
			}
	}
	
	
	public Cursor getCustomerData(){
		Cursor cursor = database.query(MySQLiteHelper.CUSTOMERS_TABLE_NAME,
				allCustomerRow, null, null, null, null, null);
		return cursor;
		
	}
	
	public void updateCustomerData(Customer customer,String customerId)
	{
		
		ContentValues values = new ContentValues();		
		values.put(MySQLiteHelper.FIRST_NAME, customer.getCustomer().getFirst_name());
		values.put(MySQLiteHelper.LAST_NAME, customer.getCustomer().getLast_name());
		values.put(MySQLiteHelper.EMAIL_ID, customer.getCustomer().getEmail());
		
		values.put(MySQLiteHelper.ROUTE_ID, customer.getCustomer().getRoute_id());
		values.put(MySQLiteHelper.CATEGORYID, customer.getCustomer().getCategory_id());
		values.put(MySQLiteHelper.SUBCATEGORYID, customer.getCustomer().getSub_category_id());
		values.put(MySQLiteHelper.PAYMENTTERM, customer.getCustomer().getPayment_term());
		
		values.put(MySQLiteHelper.PHONE, customer.getCustomer().getPhone());
		values.put(MySQLiteHelper.ADDRESS, customer.getCustomer().getAddress());
		values.put(MySQLiteHelper.CITY, customer.getCustomer().getCity());
		values.put(MySQLiteHelper.ZIPCODE, customer.getCustomer().getZipcode());		
		values.put(MySQLiteHelper.STATE_ID, customer.getCustomer().getState_id());
		values.put(MySQLiteHelper.STATE, customer.getState().getState());
		values.put(MySQLiteHelper.LATITUDE, customer.getCustomer().getLatitude());
		values.put(MySQLiteHelper.LONGITUDE, customer.getCustomer().getLongitude());
		values.put(MySQLiteHelper.LGAREA_ID, customer.getLgArea().getId());		
		values.put(MySQLiteHelper.LGAREA, customer.getLgArea().getName());
		values.put(MySQLiteHelper.REGION_ID, customer.getRegion().getId());
		values.put(MySQLiteHelper.VIEW_DETAILS, customer.getCustomer().getView_details());
		values.put(MySQLiteHelper.REGION, customer.getRegion().getTitle());
		values.put(MySQLiteHelper.DEPOT_ID,customer.getCustomer().getDepot_id());
		values.put(MySQLiteHelper.DEPOT, customer.getDepot().getTitle());		
		values.put(MySQLiteHelper.DESCRIPTION, customer.getCustomer().getDescription());	
		values.put(MySQLiteHelper.IMAGE_PATH, customer.getCustomer().getImage_path());	
		values.put(MySQLiteHelper.ASSIGNTO, customer.getToAssignOptionSelectedJSON());		
		Cursor cursor = database.rawQuery("SELECT * FROM  customers WHERE customer_id = '" + customerId + "'" , null);
		if(cursor != null && cursor.moveToFirst()){
			if("1".equals(cursor.getString(cursor.getColumnIndex(MySQLiteHelper.ISOFFLINEADDED)))){
				values.put(MySQLiteHelper.ISOFFLINEADDED, "1");
				values.put(MySQLiteHelper.ISOFFLINEEDITED, "0");
			}
			
		else{
			values.put(MySQLiteHelper.ISOFFLINEADDED, "0");
			values.put(MySQLiteHelper.ISOFFLINEEDITED, "1");
		}
		}
		
		try{
		 database.update(MySQLiteHelper.CUSTOMERS_TABLE_NAME, values, MySQLiteHelper.CUSTOMER_ID + "=" + customerId, null);
		 }
		catch(Exception e){
			e.printStackTrace();
		}
		
		
	}
public Cursor getCustomerDataUsingId(String customer_id){	
	
	Cursor cursor = database.rawQuery("SELECT * FROM  customers WHERE customer_id = '" + customer_id + "'" , null);	
	return cursor;	
}
	
	
	
	
	
	
	
	
	
	public void deleteAllCustomerRecordFromDB(){
		try{
		database.delete(MySQLiteHelper.CUSTOMERS_TABLE_NAME, null, null);
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}
	public boolean deleteCustomerData(String id){
		int affectedRow=0;
		try{		
			affectedRow = database.delete(MySQLiteHelper.CUSTOMERS_TABLE_NAME,MySQLiteHelper.CUSTOMER_ID + " = " + id, null);
		
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return affectedRow != 0;
	}
//-----------------------------------------------------------------------------------------------------------------
	
	private String[] allCustomerVisitingRow =
		{   
			MySQLiteHelper.CUSTOMER_VISIT_ID,
			MySQLiteHelper.CUSTOMER_VISIT_USERID, MySQLiteHelper.CUSTOMER_VISIT_CUSTOMERID,
			MySQLiteHelper.CUSTOMER_VISIT_VISITING_DATE, MySQLiteHelper.CUSTOMER_VISIT_COMMENT,
			MySQLiteHelper.CUSTOMER_VISIT_DEPOTID, MySQLiteHelper.CUSTOMER_VISIT_LGAREAIF,
			MySQLiteHelper.CUSTOMER_VISIT_CVLATITUDE, MySQLiteHelper.CUSTOMER_VISIT_CVLONGITUDE,
			MySQLiteHelper.CUSTOMER_VISIT_USERFIRSTNAME, MySQLiteHelper.CUSTOMER_VISIT_USERLASTNAME,
			MySQLiteHelper.CUSTOMER_VISIT_CUSTOMERFIRSTNAME, MySQLiteHelper.CUSTOMER_VISIT_CUSTOMERLASTNAME,
			MySQLiteHelper.CUSTOMER_VISIT_DEPOTTITLE, MySQLiteHelper.CUSTOMER_VISIT_LGAREANAME,MySQLiteHelper.CUSTOMER_VISIT_LGAREAID,
			MySQLiteHelper.CUSTOMER_VISIT_STATEID, MySQLiteHelper.CUSTOMER_VISIT_SNO,
			MySQLiteHelper.CREATED_DATE, MySQLiteHelper.REQUEST_ID,
			MySQLiteHelper.CUSTOMER_VISIT_STATE_STATE_ID,
			MySQLiteHelper.CUSTOMER_VISIT_STATE_STATE_NAME,
			MySQLiteHelper.SYNCHRONIZATION,
			MySQLiteHelper.CUSTOMER_VISIT_ISOFFLINEADDED, MySQLiteHelper.CUSTOMER_VISIT_ISOFFLINEEDITED,MySQLiteHelper.CUSTOMER_VISIT_CUSTOMER_JSON,
			MySQLiteHelper.CUSTOMER_VISIT_CREATED,MySQLiteHelper.CUSTOMER_VISIT_MODIFIED,MySQLiteHelper.CUSTOMER_VISIT_CUSVISITING_REGION_ID
			
			
			//public static String CUSTOMER_VISIT_CUSTOMER_JSON
			
			
			};
	
	public void addCustomerVisitingData(
		CustomerVisit customerVisit,String isOffLineAdd,String customer_json) {
	ContentValues values = new ContentValues();
	values.put(MySQLiteHelper.CUSTOMER_VISIT_ID, customerVisit.getCustomerVisit().getId());//090456//090456
	values.put(MySQLiteHelper.CUSTOMER_VISIT_USERID, customerVisit.getCustomerVisit().getUser_id());
	values.put(MySQLiteHelper.CUSTOMER_VISIT_CUSTOMERID, customerVisit.getCustomerVisit().getCustomer_id());
	values.put(MySQLiteHelper.CUSTOMER_VISIT_CREATED, customerVisit.getCustomerVisit().getCreated());
	values.put(MySQLiteHelper.CUSTOMER_VISIT_MODIFIED, customerVisit.getCustomerVisit().getModified());
	values.put(MySQLiteHelper.CUSTOMER_VISIT_VISITING_DATE, customerVisit.getCustomerVisit().getVisiting_date());
	values.put(MySQLiteHelper.CUSTOMER_VISIT_COMMENT, customerVisit.getCustomerVisit().getComment());
	values.put(MySQLiteHelper.CUSTOMER_VISIT_DEPOTID, customerVisit.getCustomerVisit().getDepot_id());
	values.put(MySQLiteHelper.CUSTOMER_VISIT_LGAREAIF, customerVisit.getCustomerVisit().getLg_area_id());//CustomerVisit.getLg_area_id();
	values.put(MySQLiteHelper.CUSTOMER_VISIT_CVLATITUDE,customerVisit.getCustomerVisit().getLongitude());
	values.put(MySQLiteHelper.CUSTOMER_VISIT_CVLONGITUDE, customerVisit.getCustomerVisit().getLatitude());		
	values.put(MySQLiteHelper.CUSTOMER_VISIT_USERFIRSTNAME, customerVisit.getUser().getFirst_name());	
	values.put(MySQLiteHelper.CUSTOMER_VISIT_USERLASTNAME, customerVisit.getUser().getLast_name());	
	values.put(MySQLiteHelper.CUSTOMER_VISIT_LGAREAID,customerVisit.getCustomerVisit().getLg_area_id());
	values.put(MySQLiteHelper.CUSTOMER_VISIT_CUSTOMERFIRSTNAME, customerVisit.getCustomer().getFirst_name());
	values.put(MySQLiteHelper.CUSTOMER_VISIT_CUSTOMERLASTNAME, customerVisit.getCustomer().getLast_name());
	values.put(MySQLiteHelper.CUSTOMER_VISIT_CUSVISITING_REGION_ID, customerVisit.getDepot().getRegion_id());
	values.put(MySQLiteHelper.CUSTOMER_VISIT_DEPOTTITLE, customerVisit.getDepot().getTitle());	
	values.put(MySQLiteHelper.CUSTOMER_VISIT_LGAREANAME, customerVisit.getLgArea().getName());
	values.put(MySQLiteHelper.CUSTOMER_VISIT_STATEID, customerVisit.getLgArea().getState_id());
	values.put(MySQLiteHelper.CUSTOMER_VISIT_SNO, customerVisit.getSno());	
	values.put(MySQLiteHelper.CUSTOMER_VISIT_ISOFFLINEADDED, isOffLineAdd);
	
	values.put(MySQLiteHelper.CUSTOMER_VISIT_ISOFFLINEEDITED, "0");
	values.put(MySQLiteHelper.CUSTOMER_VISIT_CUSTOMER_JSON, customer_json);	
	
	values.put(MySQLiteHelper.SYNCHRONIZATION,customerVisit.getCustomerVisit().getModified());
	
	values.put(MySQLiteHelper.CUSTOMER_VISIT_STATE_STATE_ID, customerVisit.getState().getId());
	values.put(MySQLiteHelper.CUSTOMER_VISIT_STATE_STATE_NAME, customerVisit.getState().getState());
	values.put(MySQLiteHelper.CREATED_DATE, customerVisit.getCustomerVisit().getCreated());		
	values.put(MySQLiteHelper.REQUEST_ID, AppConstant.ANDROIDDEVICEID+AppConstant.getRequestId());
	

	try {

		long l=database.insert(MySQLiteHelper.CUSTOMERSVISIT_TABLE_NAME, null, values);
		//System.out.println("INSERTVALUE customer Visit "+l);
	} catch (Exception e) {
		//System.out.println("Exception in Add data in Customers data");
		e.printStackTrace();
	}
}

	
	
	
public void updateCustomerVisit(CustomerVisit customerVisit,String customer_visit_id,String customer_json){
	ContentValues values = new ContentValues();
	values.put(MySQLiteHelper.CUSTOMER_VISIT_ID, customerVisit.getCustomerVisit().getId());
	values.put(MySQLiteHelper.CUSTOMER_VISIT_USERID, customerVisit.getCustomerVisit().getUser_id());
	values.put(MySQLiteHelper.CUSTOMER_VISIT_CUSTOMERID, customerVisit.getCustomerVisit().getCustomer_id());
	values.put(MySQLiteHelper.CUSTOMER_VISIT_CREATED, customerVisit.getCustomerVisit().getCreated());
	values.put(MySQLiteHelper.CUSTOMER_VISIT_MODIFIED, customerVisit.getCustomerVisit().getModified());
	values.put(MySQLiteHelper.CUSTOMER_VISIT_VISITING_DATE, customerVisit.getCustomerVisit().getVisiting_date());
	values.put(MySQLiteHelper.CUSTOMER_VISIT_COMMENT, customerVisit.getCustomerVisit().getComment());	
	values.put(MySQLiteHelper.CUSTOMER_VISIT_LGAREAID,customerVisit.getLgArea().getId());	
	values.put(MySQLiteHelper.CUSTOMER_VISIT_DEPOTID, customerVisit.getCustomerVisit().getDepot_id());
	values.put(MySQLiteHelper.CUSTOMER_VISIT_LGAREAIF, customerVisit.getCustomerVisit().getLg_area_id());
	values.put(MySQLiteHelper.CUSTOMER_VISIT_CVLATITUDE,customerVisit.getCustomerVisit().getLongitude());
	values.put(MySQLiteHelper.CUSTOMER_VISIT_CVLONGITUDE, customerVisit.getCustomerVisit().getLatitude());		
	values.put(MySQLiteHelper.CUSTOMER_VISIT_USERFIRSTNAME, customerVisit.getUser().getFirst_name());	
	values.put(MySQLiteHelper.CUSTOMER_VISIT_USERLASTNAME, customerVisit.getUser().getLast_name());	
	values.put(MySQLiteHelper.CUSTOMER_VISIT_CUSTOMERFIRSTNAME, customerVisit.getCustomer().getFirst_name());
	values.put(MySQLiteHelper.CUSTOMER_VISIT_CUSTOMERLASTNAME, customerVisit.getCustomer().getLast_name());
	values.put(MySQLiteHelper.CUSTOMER_VISIT_CUSVISITING_REGION_ID, customerVisit.getDepot().getRegion_id());
	values.put(MySQLiteHelper.CUSTOMER_VISIT_DEPOTTITLE, customerVisit.getDepot().getTitle());	
	values.put(MySQLiteHelper.CUSTOMER_VISIT_LGAREANAME, customerVisit.getLgArea().getName());
	values.put(MySQLiteHelper.CUSTOMER_VISIT_STATEID, customerVisit.getLgArea().getState_id());
	values.put(MySQLiteHelper.CUSTOMER_VISIT_SNO, customerVisit.getSno());
	values.put(MySQLiteHelper.CUSTOMER_VISIT_CUSTOMER_JSON, customer_json);
	
	values.put(MySQLiteHelper.CUSTOMER_VISIT_STATE_STATE_ID, customerVisit.getState().getId());
	values.put(MySQLiteHelper.CUSTOMER_VISIT_STATE_STATE_NAME, customerVisit.getState().getState());
	
	//values.put(MySQLiteHelper.CUSTOMER_VISIT_ISOFFLINEADDED, "0");
	//values.put(MySQLiteHelper.CUSTOMER_VISIT_ISOFFLINEEDITED, "1");
	
	 Cursor cursor = database.rawQuery("SELECT * FROM  customersVisit WHERE custometvisit_id = '" + customer_visit_id + "'" , null);
		if(cursor != null && cursor.moveToFirst()){
			if("1".equals(cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CUSTOMER_VISIT_ISOFFLINEADDED)))){
				values.put(MySQLiteHelper.CUSTOMER_VISIT_ISOFFLINEADDED, "1");
				values.put(MySQLiteHelper.CUSTOMER_VISIT_ISOFFLINEEDITED, "0");
				
			}
			else{
				values.put(MySQLiteHelper.CUSTOMER_VISIT_ISOFFLINEADDED, "0");
				values.put(MySQLiteHelper.CUSTOMER_VISIT_ISOFFLINEEDITED, "1");
			}
		}
		
	try{
		 database.update(MySQLiteHelper.CUSTOMERSVISIT_TABLE_NAME, values, MySQLiteHelper.CUSTOMER_VISIT_ID + "=" + customer_visit_id, null);
		 }
		catch(Exception e){
			e.printStackTrace();
		}
}
	
	
public Cursor getCustomerVisitData(){
	Cursor cursor = database.query(MySQLiteHelper.CUSTOMERSVISIT_TABLE_NAME,
			allCustomerVisitingRow, null, null, null, null, null);
	return cursor;
	
}

public void customerVisitupdateISAdded(String paymentId){
	ContentValues values = new ContentValues();	
	values.put(MySQLiteHelper.CUSTOMER_VISIT_ISOFFLINEADDED, "0");
	
	try{
		long result= database.update(MySQLiteHelper.CUSTOMERSVISIT_TABLE_NAME, values, MySQLiteHelper.CUSTOMER_VISIT_ID + "=" + paymentId, null);
		System.out.println("This is update result in update"+result);
	}
		catch(Exception e)
		{
			e.printStackTrace();
		}
}
public void customerVisitupdateISEdit(String paymentId){
	ContentValues values = new ContentValues();	
	values.put(MySQLiteHelper.CUSTOMER_VISIT_ISOFFLINEEDITED, "0");
	
	try{
		long result= database.update(MySQLiteHelper.CUSTOMERSVISIT_TABLE_NAME, values, MySQLiteHelper.CUSTOMER_VISIT_ID + "=" + paymentId, null);
		System.out.println("This is update result in update"+result);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
}
//values.put(MySQLiteHelper.CUSTOMER_VISIT_ISOFFLINEADDED, "1");
//values.put(MySQLiteHelper.CUSTOMER_VISIT_ISOFFLINEEDITED, "0");

public ArrayList<CustomerVisit> getAllCustomerVisitingQueries() {
	ArrayList<CustomerVisit> list = new ArrayList<CustomerVisit>();
	list.clear();
	try {
		Cursor cursor = database.query(MySQLiteHelper.CUSTOMERSVISIT_TABLE_NAME,
				allCustomerVisitingRow, null, null, null, null, null);
		cursor.moveToFirst();
		while (!cursor.isAfterLast()) {

			
			try{
				
			StuffData stuffData = new StuffData();
			String customeJson=stuffData.getCustomerJson(cursor,"CustomerVisiting");
			JSONObject jsonObject = new JSONObject(customeJson);
			JSONArray jsonArray = jsonObject.getJSONArray("data");
			for (int i = 0; i < jsonArray.length(); i++) 
			{
				list.add(new CustomerVisit(jsonArray.getJSONObject(i)));
			}
			}catch(JSONException e)
			{
				e.printStackTrace();
			}
			
			

			cursor.moveToNext();
		}
		cursor.close();
		

	} catch (Exception e) {

		e.printStackTrace();
	}
	return list;

}
public void deleteAllCustomerVisitingRecordFromDB(){
	try{
	database.delete(MySQLiteHelper.CUSTOMERSVISIT_TABLE_NAME, null, null);
	}
	catch(Exception e){
		e.printStackTrace();
	}
}

public boolean deleteCustomerVisitingData(String delete_id) {
	int affectedRow=0;
	try{
	
		affectedRow = database.delete(MySQLiteHelper.CUSTOMERSVISIT_TABLE_NAME,
			MySQLiteHelper.CUSTOMER_VISIT_ID + " = " + delete_id, null);
	
	}
	catch(Exception e){
		e.printStackTrace();
	}
	return affectedRow != 0;

}


// this is incentive........
//-----------------------------------------------------------------------------------------------------------------

public String[] allIncentiveRow={
 MySQLiteHelper.INCENTIVE_ID
,MySQLiteHelper.INCENTIVE_BRAND_ID
,MySQLiteHelper.INCENTIVE_USER_ID
,MySQLiteHelper.INCENTIVE_CUSTOMER_ID
,MySQLiteHelper.INCENTIVE_DEPOT_ID
,MySQLiteHelper.INCENTIVE_INCENTIVE_DATE
,MySQLiteHelper.INCENTIVE_INCENTIVE_TYPE
,MySQLiteHelper.INCENTIVE_UNIT
,MySQLiteHelper.INCENTIVE_CAL_QNT
,MySQLiteHelper.INCENTIVE_QUANTITY
,MySQLiteHelper.INCENTIVE_CREATED
,MySQLiteHelper.INCENTIVE_MODIFIED
,MySQLiteHelper.INCENTIVE_FIRST_NAME
,MySQLiteHelper.INCENTIVE_LAST_NAME
,MySQLiteHelper.INCENTIVE_BRAND_BRAND_ID
,MySQLiteHelper.INCENTIVE_BRAND_NAME
,MySQLiteHelper.INCENTIVE_BRAND_DESCRIPTION
,MySQLiteHelper.INCENTIVE_BRAND_USER_ID
,MySQLiteHelper.INCENTIVE_CASE_PRICE
,MySQLiteHelper.INCENTIVE_ROLL_PRICE
,MySQLiteHelper.INCENTIVE_PACK_PRICE
,MySQLiteHelper.INCENTIVE_2PACK_PRICE
,MySQLiteHelper.INCENTIVE_CASE_ROLL
,MySQLiteHelper.INCENTIVE_ROLL_PACK
,MySQLiteHelper.INCENTIVE_PACK_STICKS
,MySQLiteHelper.INCENTIVE_2ND_PACK_PACK
,MySQLiteHelper.INCENTIVE_STATUS
,MySQLiteHelper.INCENTIVE_RD_CASE_PRICE
,MySQLiteHelper.INCENTIVE_RD_ROLL_PRICE
,MySQLiteHelper.INCENTIVE_RD_PACK_PRICE
,MySQLiteHelper.INCENTIVE_RD_2ND_PACK_PRICE
,MySQLiteHelper.INCENTIVE_BRAND_CREATED
,MySQLiteHelper.INCENTIVE_BRAND_MODIFIED
,MySQLiteHelper.INCENTIVE_DEPOTID
,MySQLiteHelper.INCENTIVE_DEPOT_NAME
,MySQLiteHelper.INCENTIVE_DEPOT_REGION_ID
,MySQLiteHelper.INCENTIVECUSTOMER_ID
,MySQLiteHelper.INCENTIVE_CUSTOMER_FIRST_NAME
,MySQLiteHelper.INCENTIVE_CUSTOMER_LAST_NAME
,MySQLiteHelper.INCENTIVE_SNO
,MySQLiteHelper.INCENTIVE_ISOFFLINEADDED
,MySQLiteHelper.INCENTIVE_CUSTOMER_JSON
,MySQLiteHelper.CREATED_DATE
,MySQLiteHelper.REQUEST_ID
,MySQLiteHelper.INCENTIVE_ISOFFLINEEDITED};


	public void addIncentiveData(IncentiveItem incentiveItem,String isofflineAdded,String customer_json){
		ContentValues values=new ContentValues();	
		values.put(MySQLiteHelper.INCENTIVE_ID,incentiveItem.getIncentive().getId());
	    values.put(MySQLiteHelper.INCENTIVE_BRAND_ID,incentiveItem.getIncentive().getBrand_id());
        values.put(MySQLiteHelper.INCENTIVE_USER_ID,incentiveItem.getIncentive().getUser_id());
		values.put(MySQLiteHelper.INCENTIVE_CUSTOMER_ID,incentiveItem.getIncentive().getCustomer_id());
        values.put(MySQLiteHelper.INCENTIVE_DEPOT_ID,incentiveItem.getIncentive().getDepot_id());
        values.put(MySQLiteHelper.INCENTIVE_INCENTIVE_DATE,incentiveItem.getIncentive().getIncentive_date());
        values.put(MySQLiteHelper.INCENTIVE_INCENTIVE_TYPE,incentiveItem.getIncentive().getIncentive_type());
        values.put(MySQLiteHelper.INCENTIVE_UNIT ,incentiveItem.getIncentive().getSku());
        values.put(MySQLiteHelper.INCENTIVE_CAL_QNT ,incentiveItem.getIncentive().getCal_qty());
        values.put(MySQLiteHelper.INCENTIVE_QUANTITY,incentiveItem.getIncentive().getQuantity());
        values.put(MySQLiteHelper.INCENTIVE_CREATED,incentiveItem.getIncentive().getCreated());
        values.put(MySQLiteHelper.INCENTIVE_MODIFIED,incentiveItem.getIncentive().getModified());
        values.put(MySQLiteHelper.INCENTIVE_FIRST_NAME,incentiveItem.getUser().getFirst_name());
        values.put(MySQLiteHelper.INCENTIVE_LAST_NAME,incentiveItem.getUser().getLast_name());
        values.put(MySQLiteHelper.INCENTIVE_BRAND_BRAND_ID ,incentiveItem.getBrand().getId());
        values.put(MySQLiteHelper.INCENTIVE_BRAND_NAME,incentiveItem.getBrand().getName());
        values.put(MySQLiteHelper.INCENTIVE_BRAND_DESCRIPTION,incentiveItem.getBrand().getDescription());       
        values.put(MySQLiteHelper.INCENTIVE_BRAND_USER_ID,incentiveItem.getBrand().getUser_id());
        values.put(MySQLiteHelper.INCENTIVE_CASE_PRICE	  ,incentiveItem.getBrand().getCase_price());       
        values.put(MySQLiteHelper.INCENTIVE_ROLL_PRICE ,incentiveItem.getBrand().getRoll_price());
        values.put(MySQLiteHelper.INCENTIVE_PACK_PRICE,incentiveItem.getBrand().getPack_price());
        values.put(MySQLiteHelper.INCENTIVE_2PACK_PRICE,incentiveItem.getBrand().getPack2_price());
        values.put(MySQLiteHelper.INCENTIVE_CASE_ROLL,incentiveItem.getBrand().getCase_roll());
        values.put(MySQLiteHelper.INCENTIVE_ROLL_PACK,incentiveItem.getBrand().getRoll_pack());
        values.put(MySQLiteHelper.INCENTIVE_PACK_STICKS, incentiveItem.getBrand().getPack_sticks());
        values.put(MySQLiteHelper.INCENTIVE_2ND_PACK_PACK,incentiveItem.getBrand().getPack2_pack());
        values.put(MySQLiteHelper.INCENTIVE_STATUS, incentiveItem.getBrand().getStatus());
        values.put(MySQLiteHelper.INCENTIVE_RD_CASE_PRICE,incentiveItem.getBrand().getRd_case_price());
        values.put(MySQLiteHelper.INCENTIVE_RD_ROLL_PRICE,incentiveItem.getBrand().getRd_roll_price());
        values.put(MySQLiteHelper.INCENTIVE_RD_PACK_PRICE,incentiveItem.getBrand().getRd_pack_price());
        values.put(MySQLiteHelper.INCENTIVE_RD_2ND_PACK_PRICE,incentiveItem.getBrand().getRd_2pack_price());
        values.put(MySQLiteHelper.INCENTIVE_BRAND_CREATED,incentiveItem.getBrand().getCreated());
        values.put(MySQLiteHelper.INCENTIVE_BRAND_MODIFIED,incentiveItem.getBrand().getModified());
        values.put(MySQLiteHelper.INCENTIVE_DEPOTID,incentiveItem.getDepot().getId());
        values.put(MySQLiteHelper.INCENTIVE_DEPOT_NAME,incentiveItem.getDepot().getTitle());
        values.put(MySQLiteHelper.INCENTIVE_DEPOT_REGION_ID, incentiveItem.getDepot().getRegion_id());
        values.put(MySQLiteHelper.INCENTIVECUSTOMER_ID,incentiveItem.getCustomer().getId());
        values.put(MySQLiteHelper.INCENTIVE_CUSTOMER_FIRST_NAME,incentiveItem.getCustomer().getFname());
        values.put(MySQLiteHelper.INCENTIVE_CUSTOMER_LAST_NAME,incentiveItem.getCustomer().getLname());
        values.put(MySQLiteHelper.INCENTIVE_SNO, incentiveItem.getSno());
        values.put(MySQLiteHelper.INCENTIVE_CUSTOMER_JSON, customer_json);
        values.put(MySQLiteHelper.INCENTIVE_ISOFFLINEADDED, isofflineAdded);
        values.put(MySQLiteHelper. INCENTIVE_ISOFFLINEEDITED ,"0");
        values.put(MySQLiteHelper. CREATED_DATE, AppConstant.getCurrentDateAndTime());		
    	values.put(MySQLiteHelper.REQUEST_ID, AppConstant.ANDROIDDEVICEID+AppConstant.getRequestId());
        
        
        try {

    		long l=database.insert(MySQLiteHelper.INCENTIVE_TABLE_NAME, null, values);
    		//System.out.println("INSERTVALUE"+l);
    	} catch (Exception e) {
    		//System.out.println("Exception in Incentive");
    		e.printStackTrace();
    	}
	
}
	
	public Cursor getIncentiveData(){
		Cursor cursor = database.query(MySQLiteHelper.INCENTIVE_TABLE_NAME,
				allIncentiveRow, null, null, null, null, null);
		return cursor;
		
	}
	
public void updateIncentive(IncentiveItem incentiveItem, String incentiveId,String Customer_json)
{

	
	
	 ContentValues values=new ContentValues();
	 values.put(MySQLiteHelper.INCENTIVE_INCENTIVE_DATE,incentiveItem.getIncentive().getIncentive_date());
	 values.put(MySQLiteHelper.INCENTIVE_BRAND_ID, incentiveItem.getIncentive().getBrand_id());	 
	 values.put(MySQLiteHelper.INCENTIVE_DEPOT_ID, incentiveItem.getIncentive().getDepot_id());
	 values.put(MySQLiteHelper.INCENTIVE_INCENTIVE_TYPE, incentiveItem.getIncentive().getIncentive_type());
	 values.put(MySQLiteHelper.INCENTIVE_UNIT, incentiveItem.getIncentive().getSku());
	 values.put(MySQLiteHelper.INCENTIVE_QUANTITY, incentiveItem.getIncentive().getQuantity());
	 values.put(MySQLiteHelper.INCENTIVE_CUSTOMER_JSON, Customer_json);
	 values.put(MySQLiteHelper.INCENTIVE_CUSTOMER_FIRST_NAME, incentiveItem.getCustomer().getFname());
	 values.put(MySQLiteHelper.INCENTIVE_CUSTOMER_LAST_NAME, incentiveItem.getCustomer().getLname());
	 
	 Cursor cursor = database.rawQuery("SELECT * FROM  incentive WHERE incentive_id = '" + incentiveId + "'" , null);
		if(cursor != null && cursor.moveToFirst()){
			if("1".equals(cursor.getString(cursor.getColumnIndex(MySQLiteHelper.INCENTIVE_ISOFFLINEADDED)))){
				values.put(MySQLiteHelper.INCENTIVE_ISOFFLINEADDED, "1");
				values.put(MySQLiteHelper.INCENTIVE_ISOFFLINEEDITED, "0");
				
			}
			else{
				values.put(MySQLiteHelper.INCENTIVE_ISOFFLINEADDED, "0");
				values.put(MySQLiteHelper.INCENTIVE_ISOFFLINEEDITED, "1");
			}
		}
		
	 
	 
	 try{
		 database.update(MySQLiteHelper.INCENTIVE_TABLE_NAME, values, MySQLiteHelper.INCENTIVE_ID + "=" + incentiveId, null);
		 }
		catch(Exception e){
			e.printStackTrace();
		}
	 
}
	
	public ArrayList<IncentiveItem> getAllIncentivegQueries() {
		ArrayList<IncentiveItem> list = new ArrayList<IncentiveItem>();
		list.clear();
		try {
			Cursor cursor = database.query(MySQLiteHelper.INCENTIVE_TABLE_NAME,allIncentiveRow, null, null, null, null, null);
			cursor.moveToFirst();
			while (!cursor.isAfterLast()) {

				
				try{
					
				StuffData stuffData = new StuffData();
				String incentiveJson=stuffData.getCustomerJson(cursor,"Incentive");
				JSONObject jsonObject = new JSONObject(incentiveJson);
				JSONArray jsonArray = jsonObject.getJSONArray("data");
				for (int i = 0; i < jsonArray.length(); i++) 
				{
					list.add(new IncentiveItem(jsonArray.getJSONObject(i)));
				}
				}catch(JSONException e)
				{
					e.printStackTrace();
				}
				
				

				cursor.moveToNext();
			}
			cursor.close();
			

		} catch (Exception e) {

			e.printStackTrace();
		}
		return list;

	}	
	

public boolean deleteIncentiveSingleRow(String delete_id) {
	int affectedRow=0;
	try{
	
		affectedRow = database.delete(MySQLiteHelper.INCENTIVE_TABLE_NAME,MySQLiteHelper.INCENTIVE_ID + " = " + delete_id, null);
	
	}
	catch(Exception e){
		e.printStackTrace();
	}
	return affectedRow != 0;

}	
	
	
public void deleteAllIncentiveRecordFromDB(){
	try{
	database.delete(MySQLiteHelper.INCENTIVE_TABLE_NAME, null, null);
	}
	catch(Exception e){
		e.printStackTrace();
	}
}

public void incentiveupdateISAdded(String incentiveId){
	ContentValues values = new ContentValues();
	values.put(MySQLiteHelper.INCENTIVE_ISOFFLINEADDED, "0");
	
	try{
		long result= database.update(MySQLiteHelper.INCENTIVE_TABLE_NAME, values, MySQLiteHelper.INCENTIVE_ID + "=" + incentiveId, null);
		System.out.println("This is update result"+result);
	}
		catch(Exception e)
		{
			e.printStackTrace();
		}
}

public void incentiveupdateISUpdated(String incentiveId){
	ContentValues values = new ContentValues();
	values.put(MySQLiteHelper.INCENTIVE_ISOFFLINEEDITED, "0");
	
	try{
		long result= database.update(MySQLiteHelper.INCENTIVE_TABLE_NAME, values, MySQLiteHelper.INCENTIVE_ID + "=" + incentiveId, null);
		System.out.println("This is update result"+result);
	}
		catch(Exception e)
		{
			e.printStackTrace();
		}
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////

public String[] allPaymentRow=
{		 MySQLiteHelper. PAYMENT_ID
		,MySQLiteHelper. PAYMENT_TITLE
		,MySQLiteHelper. PAYMENT_USER_ID
		,MySQLiteHelper. PAYMENT_PAYMENT_MODE
		,MySQLiteHelper. PAYMENT_BANK_ID
		,MySQLiteHelper. PAYMENT_DEPOT_ID
		,MySQLiteHelper. PAYMENT_BRAND_ID
		,MySQLiteHelper. PAYMENT_DISTRIBUTOR_ID
		,MySQLiteHelper. PAYMENT_AMOUNT
		,MySQLiteHelper. PAYMENT_PAYMENT_REF
		,MySQLiteHelper. PAYMENT_TRANSACTION_ID
		,MySQLiteHelper. PAYMENT_PAYMENT_DATE
		,MySQLiteHelper. PAYMENT_NOTES
		,MySQLiteHelper. PAYMENT_CREATED
		,MySQLiteHelper. PAYMENT_MODIFIED
		,MySQLiteHelper. PAYMENT_USER_FIRST_NAME
		,MySQLiteHelper. PAYMENT_USER_LAST_NAME
		,MySQLiteHelper. PAYMENT_BANK_BANK_ID
		,MySQLiteHelper. PAYMENT_BANK_NAME
		,MySQLiteHelper. PAYMENT_SNO
		,MySQLiteHelper.CREATED_DATE
		,MySQLiteHelper.REQUEST_ID
		,MySQLiteHelper.PAYMENT_ISOFFLINEADDED
		,MySQLiteHelper. PAYMENT_ISOFFLINEEDITED};

public long addPaymentData(Payments payments,String isOfflineAdd){
	long l = -1;
	     ContentValues values=new ContentValues();
	
	 		values.put(MySQLiteHelper.PAYMENT_ID,payments.getPayment().getId());
			 values.put(MySQLiteHelper.PAYMENT_TITLE,payments.getPayment().getTitle());
	         values.put(MySQLiteHelper.PAYMENT_USER_ID,payments.getPayment().getUser_id());
			 values.put(MySQLiteHelper.PAYMENT_PAYMENT_MODE,payments.getPayment().getPayment_mode());
	         values.put(MySQLiteHelper.PAYMENT_BANK_ID,payments.getPayment().getBank_id());
	         values.put(MySQLiteHelper.PAYMENT_DEPOT_ID,payments.getPayment().getDepot_id());
	         values.put(MySQLiteHelper.PAYMENT_BRAND_ID,payments.getPayment().getBrand_id());
	         values.put(MySQLiteHelper.PAYMENT_DISTRIBUTOR_ID,payments.getPayment().getDistributor_id());
	         values.put(MySQLiteHelper.PAYMENT_AMOUNT,payments.getPayment().getAmount());
	         values.put(MySQLiteHelper.PAYMENT_PAYMENT_REF,payments.getPayment().getPayment_ref());
	         values.put(MySQLiteHelper.PAYMENT_TRANSACTION_ID,payments.getPayment().getTransaction_id());
	         values.put(MySQLiteHelper.PAYMENT_PAYMENT_DATE,payments.getPayment().getPayment_date());
	         values.put(MySQLiteHelper.PAYMENT_NOTES,payments.getPayment().getNotes());
	         values.put(MySQLiteHelper.PAYMENT_CREATED,payments.getPayment().getCreated());
	         values.put(MySQLiteHelper.PAYMENT_MODIFIED ,payments.getPayment().getModified());	        		 
	         values.put(MySQLiteHelper.PAYMENT_USER_FIRST_NAME,payments.getUser().getFirst_name());
	         values.put(MySQLiteHelper.PAYMENT_USER_LAST_NAME,payments.getUser().getLast_name());
	         values.put(MySQLiteHelper.PAYMENT_BANK_BANK_ID,payments.getBank().getId());
	         values.put(MySQLiteHelper.PAYMENT_BANK_NAME,payments.getBank().getName());
	         values.put(MySQLiteHelper.PAYMENT_SNO,payments.getSno());
	         values.put(MySQLiteHelper.PAYMENT_ISOFFLINEEDITED,"0");
	         values.put(MySQLiteHelper.PAYMENT_ISOFFLINEADDED, isOfflineAdd);
	         //values.put(MySQLiteHelper.CREATED_DATE, AppConstant.getCurrentDateAndTime());		
	     	 values.put(MySQLiteHelper.REQUEST_ID, AppConstant.ANDROIDDEVICEID+AppConstant.getRequestId());
	         try {

	     		 l=database.insert(MySQLiteHelper.PAYMENT_TABLE_NAME, null, values);
	     		//System.out.println("INSERTVALUE"+l);
	     	} catch (Exception e) {
	     		//System.out.println("Exception in Payment");
	     		e.printStackTrace();
	     	}
	         return l;
}

public void updatePaymentData(Payments payments,String paymentId){	
ContentValues values=new ContentValues();
values.put(MySQLiteHelper.PAYMENT_PAYMENT_MODE, payments.getPayment().getPayment_mode());
values.put(MySQLiteHelper.PAYMENT_BANK_ID, payments.getPayment().getBank_id());
values.put(MySQLiteHelper.PAYMENT_BRAND_ID, payments.getPayment().getBrand_id());
values.put(MySQLiteHelper.PAYMENT_DISTRIBUTOR_ID, payments.getPayment().getDistributor_id());
values.put(MySQLiteHelper.PAYMENT_AMOUNT, payments.getPayment().getAmount());
values.put(MySQLiteHelper.PAYMENT_PAYMENT_REF, payments.getPayment().getPayment_ref());
values.put(MySQLiteHelper.PAYMENT_TRANSACTION_ID, payments.getPayment().getTransaction_id());
values.put(MySQLiteHelper.PAYMENT_PAYMENT_DATE, payments.getPayment().getPayment_date());
values.put(MySQLiteHelper.PAYMENT_NOTES, payments.getPayment().getNotes());
values.put(MySQLiteHelper.PAYMENT_ISOFFLINEADDED, "0");
values.put(MySQLiteHelper.PAYMENT_ISOFFLINEEDITED, "1");
	
	try{
		
	 database.update(MySQLiteHelper.PAYMENT_TABLE_NAME, values, MySQLiteHelper.PAYMENT_ID + "=" + paymentId, null);
	 
	 }
	catch(Exception e)
	{
		e.printStackTrace();
	}	
	
}
public Cursor getPaymentData(){
	Cursor cursor = database.query(MySQLiteHelper.PAYMENT_TABLE_NAME,
			allPaymentRow, null, null, null, null, null);
	return cursor;
	
}


public ArrayList<Payments> getAllPayemtQueries() {
	ArrayList<Payments> list = new ArrayList<Payments>();
	list.clear();
	try {
		Cursor cursor = database.query(MySQLiteHelper.PAYMENT_TABLE_NAME,
				allPaymentRow, null, null, null, null, null);
		cursor.moveToFirst();
		while (!cursor.isAfterLast()) {

			
			try{
				
			StuffData stuffData = new StuffData();
			String paymentJson=stuffData.getCustomerJson(cursor,"Payment");
			JSONObject jsonObject = new JSONObject(paymentJson);
			JSONArray jsonArray = jsonObject.getJSONArray("data");
			for (int i = 0; i < jsonArray.length(); i++) 
			{
				list.add(new Payments(jsonArray.getJSONObject(i)));
			}
			}catch(JSONException e)
			{
				e.printStackTrace();
			}
			
			

			cursor.moveToNext();
		}
		cursor.close();
		

	} catch (Exception e) {

		e.printStackTrace();
	}
	return list;

}	


public boolean deletePaymentSingleRow(String delete_id) {
	int affectedRow=0;
	try{
	
		affectedRow = database.delete(MySQLiteHelper.PAYMENT_TABLE_NAME,
			MySQLiteHelper.PAYMENT_ID + " = " + delete_id, null);
	
	}
	catch(Exception e){
		e.printStackTrace();
	}
	return affectedRow != 0;

}

public void paymentupdateISAdded(String paymentId){
	ContentValues values = new ContentValues();	
	values.put(MySQLiteHelper.PAYMENT_ISOFFLINEADDED, "0");
	
	try{
		long result= database.update(MySQLiteHelper.PAYMENT_TABLE_NAME, values, MySQLiteHelper.PAYMENT_ID + "=" + paymentId, null);
		System.out.println("This is update result in update"+result);
	}
		catch(Exception e)
		{
			e.printStackTrace();
		}
}
public void paymentupdateISEdit(String paymentId){
	ContentValues values = new ContentValues();	
	values.put(MySQLiteHelper.PAYMENT_ISOFFLINEEDITED, "0");
	
	try{
		long result= database.update(MySQLiteHelper.PAYMENT_TABLE_NAME, values, MySQLiteHelper.PAYMENT_ID + "=" + paymentId, null);
		System.out.println("This is update result in update"+result);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
}

public void deleteAllPaymentRecordFromDB(){
	try{
	database.delete(MySQLiteHelper.PAYMENT_TABLE_NAME, null, null);
	}
	catch(Exception e){
		e.printStackTrace();
	}
}



//----------------------------------------------------------------------------------------------------



public String[] allExpenceRow={
		MySQLiteHelper. EXPENSE_ID
		,MySQLiteHelper. EXPENSE_TITLE
		,MySQLiteHelper. EXPENSE_DEPOT_ID
		,MySQLiteHelper. EXPENSE_BRAND_ID
		,MySQLiteHelper. EXPENSE_USER_ID
		,MySQLiteHelper. EXPENSE_EXP_AMOUNT
		,MySQLiteHelper. EXPENSE_EXP_DATA
		,MySQLiteHelper. EXPENSE_PAYMENT_MODE
		,MySQLiteHelper. EXPENSE_REF
		,MySQLiteHelper. EXPENSE_DESCRIPTION
		,MySQLiteHelper. EXPENSE_TYPE_ID
		,MySQLiteHelper. EXPENSE_CREATE
		,MySQLiteHelper. EXPENSE_MODIFIED
		,MySQLiteHelper. EXPENSE_USER_FIRST_NAME
		,MySQLiteHelper. EXPENSE_USER_LAST_NAME
		,MySQLiteHelper. EXPENSE_EXPTYPE_ID
		,MySQLiteHelper. EXPENSE_NAME
		,MySQLiteHelper. EXPENSE_CATEGORY_ID
		,MySQLiteHelper.EXPENCE_OFFLINE_ADD
		,MySQLiteHelper.EXPENCE_OFFLINE_EDIT
		,MySQLiteHelper.CREATED_DATE
		,MySQLiteHelper.REQUEST_ID
		,MySQLiteHelper. EXPENSE_SNO};


public void addExpenceData(Expense expence,String isOfflineAdd){
	
			  ContentValues values=new ContentValues();	
    		  values.put(MySQLiteHelper.EXPENSE_ID,expence.getExpense().getId());//expense.getExpense().setId
			  values.put(MySQLiteHelper.EXPENSE_TITLE,expence.getExpense().getTitle());
			  values.put(MySQLiteHelper.EXPENSE_DEPOT_ID, expence.getExpense().getDepot_id());
	          values.put(MySQLiteHelper.EXPENSE_USER_ID,expence.getExpense().getUser_id());
	          values.put(MySQLiteHelper.EXPENSE_BRAND_ID, expence.getExpense().getBrand_id());
			  values.put(MySQLiteHelper.EXPENSE_EXP_AMOUNT,expence.getExpense().getExp_amount());
	          values.put(MySQLiteHelper.EXPENSE_EXP_DATA,expence.getExpense().getExp_date());
	          values.put(MySQLiteHelper.EXPENSE_PAYMENT_MODE,expence.getExpense().getPayment_mode());
	          values.put(MySQLiteHelper.EXPENSE_REF,expence.getExpense().getExpense_ref());
	          values.put(MySQLiteHelper.EXPENSE_DESCRIPTION,expence.getExpense().getDescription());	  
	          
	          values.put(MySQLiteHelper.EXPENSE_TYPE_ID,expence.getExpense().getExp_type_id());
	          
	          values.put(MySQLiteHelper.EXPENSE_CREATE,expence.getExpense().getCreated());	          
	          values.put(MySQLiteHelper.EXPENSE_MODIFIED,expence.getExpense().getModified());
	          values.put(MySQLiteHelper.EXPENSE_USER_FIRST_NAME,expence.getUser().getFirst_name());	          
	          values.put(MySQLiteHelper.EXPENSE_USER_LAST_NAME,expence.getUser().getLast_name());
	          values.put(MySQLiteHelper.EXPENSE_EXPTYPE_ID,expence.getExpType().getId());
	          values.put(MySQLiteHelper.EXPENSE_NAME,expence.getExpType().getName());
	          values.put(MySQLiteHelper.EXPENSE_CATEGORY_ID,expence.getExpType().getCategory_id());          	          
	          values.put(MySQLiteHelper.EXPENSE_SNO ,expence.getSno());
	          values.put(MySQLiteHelper.EXPENCE_OFFLINE_ADD, isOfflineAdd);
	          values.put(MySQLiteHelper.EXPENCE_OFFLINE_EDIT, "0");
	          values.put(MySQLiteHelper.CREATED_DATE, AppConstant.getCurrentDateAndTime());		
	      	  values.put(MySQLiteHelper.REQUEST_ID, AppConstant.ANDROIDDEVICEID+AppConstant.getRequestId());
	          
	          try {

		     		long l=database.insert(MySQLiteHelper.EXPENSE_TABLE_NAME, null, values);
		     		System.out.println("EXPENCE"+l);
		     	} catch (Exception e) {
		     		System.out.println("Exception in Expence");
		     		e.printStackTrace();
		     	}
}

public void updateExpenseData(Expense expense,String expenceId){
//getExpType()
	//expense.getExpense().setDepot_id
	
	ContentValues values=new ContentValues();
	values.put(MySQLiteHelper.EXPENSE_DEPOT_ID, expense.getExpense().getDepot_id());
	values.put(MySQLiteHelper.EXPENSE_BRAND_ID, expense.getExpense().getBrand_id());
	values.put(MySQLiteHelper.EXPENSE_EXP_AMOUNT, expense.getExpense().getExp_amount());
	values.put(MySQLiteHelper.EXPENSE_TYPE_ID, expense.getExpense().getExp_type_id());
	values.put(MySQLiteHelper.EXPENSE_EXP_DATA, expense.getExpense().getExp_date());
	values.put(MySQLiteHelper.EXPENSE_PAYMENT_MODE, expense.getExpense().getPayment_mode());
	values.put(MySQLiteHelper.EXPENSE_REF, expense.getExpense().getExpense_ref());
	values.put(MySQLiteHelper.EXPENSE_DESCRIPTION, expense.getExpense().getDescription());
	values.put(MySQLiteHelper.EXPENSE_EXPTYPE_ID, expense.getExpense().getExp_type_id());
	values.put(MySQLiteHelper.EXPENSE_NAME, expense.getExpType().getName());
	
	Cursor cursor = database.rawQuery("SELECT * FROM  expense WHERE expense_ID = '" + expenceId + "'" , null);
	if(cursor != null && cursor.moveToFirst()){
		if("1".equals(cursor.getString(cursor.getColumnIndex(MySQLiteHelper.EXPENCE_OFFLINE_ADD)))){
			
			values.put(MySQLiteHelper.EXPENCE_OFFLINE_ADD, "1");
			values.put(MySQLiteHelper.EXPENCE_OFFLINE_EDIT, "0");
		}
	
	else{
		values.put(MySQLiteHelper.EXPENCE_OFFLINE_ADD, "0");
		values.put(MySQLiteHelper.EXPENCE_OFFLINE_EDIT, "1");
	}
	}
	
	try{
		
		 database.update(MySQLiteHelper.EXPENSE_TABLE_NAME, values, MySQLiteHelper.EXPENSE_ID + "=" + expenceId, null);
		 
		 }
		catch(Exception e)
		{
			e.printStackTrace();
		}	
	
	
	
}

public void expenseupdateISAdded(String customerId){
	ContentValues values = new ContentValues();	
	values.put(MySQLiteHelper.EXPENCE_OFFLINE_ADD, "0");//EXPENCE_OFFLINE_ADD
	
	try{
		long result= database.update(MySQLiteHelper.EXPENSE_TABLE_NAME, values, MySQLiteHelper.EXPENSE_ID + "=" + customerId, null);
		System.out.println("This is update result in expense"+result);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
}
public void expenseupdateIsEdited(String customerId){
	ContentValues values = new ContentValues();
	values.put(MySQLiteHelper.EXPENCE_OFFLINE_EDIT, "0");
	
	try{
		long result= database.update(MySQLiteHelper.EXPENSE_TABLE_NAME, values, MySQLiteHelper.EXPENSE_ID + "=" + customerId, null);
		System.out.println("This is update result expense"+result);
	}
		catch(Exception e)
		{
			e.printStackTrace();
		}
}






public ArrayList<Expense> getAllExpenceQueries() {
	ArrayList<Expense> list = new ArrayList<Expense>();
	list.clear();
	try {
		Cursor cursor = database.query(MySQLiteHelper.EXPENSE_TABLE_NAME,
				allExpenceRow, null, null, null, null, null);
		cursor.moveToFirst();
		while (!cursor.isAfterLast()) {			
			try{				
			StuffData stuffData = new StuffData();
			String expenceJson=stuffData.getCustomerJson(cursor,"Expence");
			JSONObject jsonObject = new JSONObject(expenceJson);
			JSONArray jsonArray = jsonObject.getJSONArray("data");
			for (int i = 0; i < jsonArray.length(); i++) 
			{
				list.add(new Expense(jsonArray.getJSONObject(i)));
			}
			}catch(JSONException e)
			{
				e.printStackTrace();
			}		

			cursor.moveToNext();
		}
		cursor.close();	

	} catch (Exception e) {
		e.printStackTrace();
	}
	return list;

}	
public void deleteAllExpenceRecordFromDB(){
	try{
	database.delete(MySQLiteHelper.EXPENSE_TABLE_NAME, null, null);
	}
	catch(Exception e){
		e.printStackTrace();
	}
}

public boolean deleteExpenceSingleRecord(String delete_id) {
	int affectedRow=0;
	try{
	
		affectedRow = database.delete(MySQLiteHelper.EXPENSE_TABLE_NAME,MySQLiteHelper.EXPENSE_ID + " = " + delete_id, null);
	
	}
	catch(Exception e){
		e.printStackTrace();
	}
	return affectedRow != 0;

}
public Cursor getExpenceData(){
	Cursor cursor = database.query(MySQLiteHelper.EXPENSE_TABLE_NAME,allExpenceRow, null, null, null, null, null);
	return cursor;
	
}
	
	public long addNotification(String massage, String notTime) {
		ContentValues values = new ContentValues();
		values.put(MySQLiteHelper.NOTIFY_MESSAGE, massage);
		values.put(MySQLiteHelper.NOTIFY_TIME, notTime);
	
		long insertId = database.insert(MySQLiteHelper.NOTIFICATION_TABLE_NAME, null, values);
		return insertId;
	}
	
	public Cursor getNotificationData(){
		String query="SELECT * FROM "+MySQLiteHelper.NOTIFICATION_TABLE_NAME+" ORDER BY "+
				MySQLiteHelper.NOTIFY_TIME+" DESC LIMIT 50"; 
	    Cursor cursor = database.rawQuery(query, null);		  
		return cursor;		
	}
	
	///Tracking handling
	public void insertTracking(String lat, String longitude, String tracking_time){
		ContentValues values=new ContentValues();	
		values.put(MySQLiteHelper.LATITUDE, lat);
		values.put(MySQLiteHelper.LONGITUDE, longitude);
		values.put(MySQLiteHelper.TRACKING_TIME, tracking_time);
		
		try {		
		 	long l = database.insert(MySQLiteHelper.USER_TRACKING_TABLE, null, values);
		 	System.out.println("Inserted tracking data"+l);
		} catch (Exception e) {
			System.out.println("Exception in Tracking data");
			e.printStackTrace();
		}

	}
	//Tracking Function	
	public boolean deleteTrakingData(String delete_ids) {
		int affectedRow=0;
		try{		
			//System.out.println(delete_ids);
			affectedRow = database.delete(MySQLiteHelper.USER_TRACKING_TABLE, MySQLiteHelper.ID + " IN ( " + delete_ids+")", null);		
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return affectedRow != 0;

	}
	public Cursor getTrakingData(){
		String[] allTrackingColumn={
				MySQLiteHelper.ID
				,MySQLiteHelper.LATITUDE
				,MySQLiteHelper.LONGITUDE
				,MySQLiteHelper.TRACKING_TIME};

		Cursor cursor = database.query(MySQLiteHelper.USER_TRACKING_TABLE,allTrackingColumn, null, null, null, null, null, "0,30");
		return cursor;
		
	}
}	
