package com.smalution.y3distributionsa1.utils;

import android.app.Application;
import android.content.Context;

public class Y3Distributor extends Application {
	//*************** this is for application context use to application***************
	// ********using rfid instance*********************
	private static Y3Distributor instance;
	

	public Y3Distributor() {

		instance = this;
	}

	public static Context getContext() {
		
		return instance;
	}
}