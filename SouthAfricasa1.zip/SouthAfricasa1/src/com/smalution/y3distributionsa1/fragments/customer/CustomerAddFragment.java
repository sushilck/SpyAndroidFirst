package com.smalution.y3distributionsa1.fragments.customer;
import com.smalution.y3distributionsa1.AppManager;
import com.smalution.y3distributionsa1.R;
import com.smalution.y3distributionsa1.Utils;
import com.smalution.y3distributionsa1.database.Y3QueryDataSource;
import com.smalution.y3distributionsa1.entities.customer.Customer;
import com.smalution.y3distributionsa1.entities.settings.Depots;
import com.smalution.y3distributionsa1.entities.settings.Lgas;
import com.smalution.y3distributionsa1.entities.settings.ParseListItems;
import com.smalution.y3distributionsa1.entities.settings.Regions;
import com.smalution.y3distributionsa1.entities.settings.Routes;
import com.smalution.y3distributionsa1.entities.settings.States;
import com.smalution.y3distributionsa1.entities.settings.Users;
import com.smalution.y3distributionsa1.fragments.SuperFragment;
import com.smalution.y3distributionsa1.utils.AppConstant;
import com.smalution.y3distributionsa1.utils.PickImageByCameraOrGallery;

import java.io.File;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Hashtable;

import org.json.JSONException;
import org.json.JSONObject;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.location.Location;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Toast;

import com.androidquery.AQuery;
import com.androidquery.callback.AjaxStatus;
import com.androidquery.callback.LocationAjaxCallback;

public class CustomerAddFragment extends SuperFragment 
{
	boolean[] selectedAssignToOptions;
  private Customer customer;
	View rootView;
	AQuery aq; 
	PickImageByCameraOrGallery PickImageByCameraOrGalleryObj;
	public static final int FLAG_SELECT_STATE=101;
	public static final int FLAG_SELECT_LGA=102;
	public static final int FLAG_SELECT_REGION=103;
	public static final int FLAG_SELECT_DEPOT=104;
	public static final int FLAG_SELECT_ASSIGNTO=105;
	public static final int FLAG_SELECT_ROUTE = 106;
	public static final int FLAG_SELECT_CATEGORY = 107;
	public static final int FLAG_SELECT_SUBCATEGORY = 108;
	public static final int FLAG_SELECT_PAYMENT_TERMS = 109;
	public static  String jsonString;
	public static  String selectedImagePath;
	UIHandler uiHandler;
	public String states_id;
	public String lga_id="0";
	public String region_id;
	public String depot_id;
	public String route_id="0";
	public String category_id="0";
	public String subcat_id="0";
	public String payment_terms_id="0";
	public String jsonAssignOption;
	public boolean isDraft = false;
	public int userGrade;
	public class UIHandler extends Handler 
	{ 
        public void handleMessage(Message msg) 
        { 
        	switch(msg.arg1)
        	{
        		
        		case FLAG_SELECT_REGION:
        		{
        			String selectedValue=(String)msg.obj;
        			aq.id(R.id.buttonRegion).text(selectedValue);
        			Regions regions = AppManager.getInstance().getRegions(aq);
        			if(regions !=null)
        			{
        				
        				region_id=regions.getItem(msg.arg2).getId();
        				aq.id(R.id.buttonDepot).text(getString(R.string.select_depot));
        				aq.id(R.id.buttonRoute).text(getString(R.string.select_route));
        			}
        			break;
        		}
        		case FLAG_SELECT_DEPOT:
	    		{
	    			String selectedValue=(String)msg.obj;
	    			aq.id(R.id.buttonDepot).text(selectedValue);
	    			Depots depots=AppManager.getInstance().getDepots(aq,region_id);
	    			if(depots!=null)
	    			{
	    				depot_id=depots.getItem(msg.arg2).getId();	    				
	    			}
	    			aq.id(R.id.buttonRoute).text(getString(R.string.select_route));
	    			break;
	    		}
	    		
        		case FLAG_SELECT_ROUTE:
	    		{
	    			String selectedValue=(String)msg.obj;
	    			aq.id(R.id.buttonRoute).text(selectedValue);
	    			Routes routes=AppManager.getInstance().getRoutes(aq,region_id, depot_id);
	    			if(routes!=null)
	    			{
	    				
	    				route_id=routes.getItem(msg.arg2).getId();
	    			}
	    			break;
	    		}
	    		
        		case FLAG_SELECT_ASSIGNTO:
	    		{
	    			@SuppressWarnings("unchecked")
	    			Object[] data=(Object[])msg.obj;
	    			selectedAssignToOptions = (boolean[])data[0];
	    			ArrayList<String> selectedValues=(ArrayList<String>)data[1];
	    			Log.d("MTK", ""+selectedValues.size());
	    			String json = (String)data[2];
	    			jsonAssignOption=json;    			
        			//aq.id(R.id.buttonAssignTo).text(selectedValue);
	    			break;
	    		}
	    		
	    		
        		case FLAG_SELECT_CATEGORY:
        		{
        			String selectedValue=(String)msg.obj;
        			aq.id(R.id.buttonCategory).text(selectedValue);
        			ParseListItems categories = AppManager.getInstance().getParseItems(aq, "categories");
        			if(categories!=null)
        			{
        				
        				category_id=categories.getItem(msg.arg2).getId();
        			}
        			break;
				}
        		
        		case FLAG_SELECT_SUBCATEGORY:
        		{
        			String selectedValue=(String)msg.obj;
        			aq.id(R.id.buttonSubCategory).text(selectedValue);
        			ParseListItems subcategories = AppManager.getInstance().getParseItems(aq, "subcategories");
        			if(subcategories != null)
        			{
        				
        				subcat_id = subcategories.getItem(msg.arg2).getId();
        			}
        			break;
				}
        		
        		case FLAG_SELECT_PAYMENT_TERMS:
        		{
        			String selectedValue=(String)msg.obj;
        			aq.id(R.id.buttonPaymentTerm).text(selectedValue);
        			ParseListItems paymentterms = AppManager.getInstance().getParseItems(aq, "paymentterms");
        			if(paymentterms!=null)
        			{
        				
        				payment_terms_id = paymentterms.getItem(msg.arg2).getId();
        			}
        			break;
				}
	    		
        	}
        }
    };
	public void setUIArguments(final Bundle args) 
	{
	    getActivity().runOnUiThread(new Runnable() 
	    {
	        public void run() 
	        {
	        	customer = args.getParcelable("CUSTOMER");
	        }
	    });
	}
	

	@Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,Bundle savedInstanceState) 
	{
        rootView = inflater.inflate(R.layout.customer_add_fragment, container, false);
        customer = new Customer();
        customer = getArguments().getParcelable("CUSTOMER");
        uiHandler = new UIHandler();
        aq = new AQuery(rootView);
        initUI();
        cfillfromDraft();
        return rootView;
    }
	
	public void onPause(){
		super.onPause();
		System.out.println("This is OnPause activity");
		caddDraft();
	}
	
	public void onStop(){
		super.onStop();
		System.out.println("This is onStop activity");
		caddDraft();
	}
	
	public void onDestroy(){
		super.onDestroy();
		System.out.println("This is onDestroy activity");
		caddDraft();
	}
	
	@Override
	public void onActivityResult(int requestCode, int resultCode, Intent data) 
	{
		super.onActivityResult(requestCode, resultCode, data);
		PickImageByCameraOrGalleryObj.onActivityResult(requestCode, resultCode, data, aq.id(R.id.imageViewPhoto).getImageView());
	}
	public void destroyItem(ViewGroup container, int position, Object object) {
        // TODO Auto-generated method stub 
	
		System.out.println("This is close...");

        
    }
	private void initUI() 
	{
		addLatLong();
		Users users = AppManager.getInstance().getUsers(aq);
		if(users!=null)
		{
			String[]  AssignToOptions = users.getNamesArr();
			if(AssignToOptions!=null && AssignToOptions.length>0)
			{
				selectedAssignToOptions=new boolean[AssignToOptions.length]; 
			}
		}
		
		
		final SharedPreferences prefs = getActivity().getSharedPreferences("BGGeoCollector", getActivity().MODE_PRIVATE);
		userGrade = prefs.getInt("grade", 0);
	
		//System.out.println(userObject);
		if (userGrade > 2){
			aq.id(R.id.tableRowRegion).gone();
			//aq.id(R.id.tableRowState).gone();
			region_id = prefs.getString("region_id", null);
		}
		
		if (userGrade > 3){
			aq.id(R.id.tableRowDepot).gone();
			depot_id = prefs.getString("depot_id", null);
		}
		
		PickImageByCameraOrGalleryObj=new PickImageByCameraOrGallery(CustomerAddFragment.this);
		aq.id(R.id.buttonSelectPhoto).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				PickImageByCameraOrGalleryObj.pickImage();
			}
		});
	
		aq.id(R.id.buttonRegion).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				boolean flag=false;
				Regions regions = AppManager.getInstance().getRegions(aq);
				if(regions!=null)
				{
					String arr[]=regions.getRegionNames();
					if(arr.length>0)
					{
						AppManager.getInstance().showSelectionAlertDialog(getActivity(), uiHandler, FLAG_SELECT_REGION, arr);
						flag=true;
					}
				}
				if(!flag)
				{
					Toast.makeText(getActivity(), getString(R.string.region_req_mess), Toast.LENGTH_SHORT).show();
				}
			}
		});
		aq.id(R.id.buttonDepot).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				boolean flag=false;
				Depots depots=AppManager.getInstance().getDepots(aq,region_id);
				if(depots!=null)
				{
					String[] arr=depots.getTitleArr();
					if(arr.length>0)
					{
						AppManager.getInstance().showSelectionAlertDialog(getActivity(), uiHandler, FLAG_SELECT_DEPOT, arr);
						flag=true;
					}
				}
				if(!flag)
				{
					Toast.makeText(getActivity(), getString(R.string.depot_req_mess), Toast.LENGTH_SHORT).show();
				}
			}
		});
		aq.id(R.id.buttonRoute).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				boolean flag=false;
				Routes routes=AppManager.getInstance().getRoutes(aq,region_id,depot_id);
				if(routes!=null)
				{
					String[] arr=routes.getTitleArr();
					if(arr.length>0)
					{
						AppManager.getInstance().showSelectionAlertDialog(getActivity(), uiHandler, FLAG_SELECT_ROUTE, arr);
						flag=true;
					}
				}
				if(!flag)
				{
					Toast.makeText(getActivity(), getString(R.string.empty_route_mess), Toast.LENGTH_SHORT).show();
				}
			}
		});
		aq.id(R.id.buttonAssignTo).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				boolean flag=false; 
				Users users = AppManager.getInstance().getUsers(aq);
				if(users!=null)
				{
					String[]  AssignToOptions = users.getNamesArr();
					if(AssignToOptions!=null && AssignToOptions.length>0)
					{
						AppManager.getInstance().showMultiSelectionAlertDialog(getActivity(), uiHandler, FLAG_SELECT_ASSIGNTO, AssignToOptions, selectedAssignToOptions,users);
						flag=true;
					}
				}
				if(!flag)
				{
					Toast.makeText(getActivity(), getString(R.string.assign_req_mess), Toast.LENGTH_SHORT).show();	
				}
			}
		});
		
		
		aq.id(R.id.buttonCategory).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				boolean flag=false;
				ParseListItems categories  = AppManager.getInstance().getParseItems(aq,"categories");
				if(categories!=null)
				{
					String[] arr=categories.getItemsNameArr();
					if(arr.length>0)
					{
						AppManager.getInstance().showSelectionAlertDialog(getActivity(), uiHandler, FLAG_SELECT_CATEGORY, arr);
						flag=true;
					}
				}
				if(!flag)
				{
					Toast.makeText(getActivity(), getString(R.string.category_req_mess), Toast.LENGTH_SHORT).show();
				}
			}
		});
		
		aq.id(R.id.buttonSubCategory).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				boolean flag=false;
				ParseListItems subcategories  = AppManager.getInstance().getParseItems(aq, "subcategories");
				if(subcategories != null)
				{
					String[] arr= subcategories.getItemsNameArr();
					if(arr.length>0)
					{
						AppManager.getInstance().showSelectionAlertDialog(getActivity(), uiHandler, FLAG_SELECT_SUBCATEGORY, arr);
						flag=true;
					}
				}
				if(!flag)
				{
					Toast.makeText(getActivity(), getString(R.string.subcat_req_mess), Toast.LENGTH_SHORT).show();
				
				}
			}
		});
		//st.makeText(getActivity(), getString(R.string.state_req_mess), Toast.LENGTH_SHORT).show();
		aq.id(R.id.buttonPaymentTerm).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				boolean flag=false;
				ParseListItems paymentterms = AppManager.getInstance().getParseItems(aq, "paymentterms");
				if(paymentterms!=null)
				{
					String[] arr=paymentterms.getItemsNameArr();
					if(arr.length>0)
					{
						AppManager.getInstance().showSelectionAlertDialog(getActivity(), uiHandler, FLAG_SELECT_PAYMENT_TERMS, arr);
						flag=true;
					}
				}
				if(!flag)
				{
					Toast.makeText(getActivity(), getString(R.string.paymentterm_req_mess), Toast.LENGTH_SHORT).show();
				}
			}
		});
		
		
		aq.id(R.id.buttonSave).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				updateCustomer();
			}
		});
	}
	private boolean isValidated()
	{
		if(aq.id(R.id.editTextFirstName).getEditText().getText().toString().length()>0)
		{
			if(aq.id(R.id.editTextLastName).getEditText().getText().toString().length()>0)
			{
				if(aq.id(R.id.editTextEmail).getEditText().getText().toString().length()>0)
				{
					if(!AppManager.getInstance().isValidEmailId(aq.id(R.id.editTextEmail).getEditText().getText().toString()))
					{
						Toast.makeText(getActivity(), getString(R.string.please_enter_email_id), Toast.LENGTH_SHORT).show();
						return false;
					}
				}
				if(aq.id(R.id.buttonCategory).getButton().getText().toString().length()>0 &&
						!aq.id(R.id.buttonCategory).getButton().getText().toString().startsWith(getString(R.string.select)))
				{
					if(aq.id(R.id.buttonSubCategory).getButton().getText().toString().length()>0 &&
							!aq.id(R.id.buttonSubCategory).getButton().getText().toString().startsWith(getString(R.string.select)))
					{
						if(aq.id(R.id.buttonPaymentTerm).getButton().getText().toString().length()>0 &&
								!aq.id(R.id.buttonPaymentTerm).getButton().getText().toString().startsWith(getString(R.string.select)))
						{
						
							if(aq.id(R.id.editTextPhone).getEditText().getText().toString().length() == 10
									&& AppManager.getInstance().isValidNumber(aq.id(R.id.editTextPhone).getEditText().getText().toString()) && !aq.id(R.id.editTextPhone).getEditText().getText().toString().equals("0") )
							{
								if(aq.id(R.id.editTextAddress).getEditText().getText().toString().length()>0)
								{
									if(aq.id(R.id.editTextCity).getEditText().getText().toString().length()>0)
									{
										if(aq.id(R.id.editTextZipcode).getEditText().getText().toString().length()>0)
										{
											if(!AppManager.getInstance().isValidNumber(aq.id(R.id.editTextZipcode).getEditText().getText().toString()))
											{
												Toast.makeText(getActivity(), getString(R.string.valid_zipcode), Toast.LENGTH_SHORT).show();
												return false;
											}
										}


											if( (aq.id(R.id.buttonRegion).getButton().getText().toString().length()>0 &&
													!aq.id(R.id.buttonRegion).getButton().getText().toString().startsWith(getString(R.string.select))) || userGrade > 2)
											{
												if((aq.id(R.id.buttonDepot).getButton().getText().toString().length()>0 &&
														!aq.id(R.id.buttonDepot).getButton().getText().toString().startsWith(getString(R.string.select))) || userGrade > 3)
												{
													if((aq.id(R.id.buttonRoute).getButton().getText().toString().length()>0 &&
															!aq.id(R.id.buttonRoute).getButton().getText().toString().startsWith(getString(R.string.select))) )
													{
														return true;
													}
													else
													{
														Toast.makeText(getActivity(), getString(R.string.pls_select_route), Toast.LENGTH_SHORT).show();
													}
												}
												else
												{
													Toast.makeText(getActivity(), getString(R.string.pls_select_depot), Toast.LENGTH_SHORT).show();
												}
											}
											else
											{
												Toast.makeText(getActivity(), getString(R.string.pls_select_region), Toast.LENGTH_SHORT).show();
											}
										}
										else
										{
											Toast.makeText(getActivity(), getString(R.string.pls_select_state), Toast.LENGTH_SHORT).show();
										}

							}
								else
								{
									Toast.makeText(getActivity(), getString(R.string.please_enter_address), Toast.LENGTH_SHORT).show();
								}
							}
							else
							{
								Toast.makeText(getActivity(), getString(R.string.please_enter_phn_number), Toast.LENGTH_SHORT).show();
							}
						}
						else
						{
							Toast.makeText(getActivity(), getString(R.string.pls_select_paymentterm), Toast.LENGTH_SHORT).show();
						}
						
					}
					else
					{
						Toast.makeText(getActivity(), getString(R.string.pls_select_subcategory), Toast.LENGTH_SHORT).show();
					}
					
				}
				else
				{
					Toast.makeText(getActivity(), getString(R.string.pls_select_category), Toast.LENGTH_SHORT).show();
				}
						
				
			}
			else
			{
				Toast.makeText(getActivity(), getString(R.string.please_enter_lname), Toast.LENGTH_SHORT).show();
			}
		}
		else
		{
			Toast.makeText(getActivity(), getString(R.string.please_enter_fname), Toast.LENGTH_SHORT).show();
		}
		return false;
	}
	private void updateCustomer()
	{
		if(!isValidated())
			return;
		
		customer=new Customer();
		customer.getCustomer().setFirst_name(aq.id(R.id.editTextFirstName).getEditText().getText().toString());
		customer.getCustomer().setLast_name(aq.id(R.id.editTextLastName).getEditText().getText().toString());
		customer.getCustomer().setEmail(aq.id(R.id.editTextEmail).getEditText().getText().toString());
		customer.getCustomer().setPhone(aq.id(R.id.editTextPhone).getEditText().getText().toString());
		customer.getCustomer().setAddress(aq.id(R.id.editTextAddress).getEditText().getText().toString());
		customer.getCustomer().setCity(aq.id(R.id.editTextCity).getEditText().getText().toString());
		customer.getCustomer().setZipcode(aq.id(R.id.editTextZipcode).getEditText().getText().toString());		
		
		//customer.getState().setId(states_id);
		//customer.getCustomer().setState_id(states_id);
		
		//customer.getState().setState(aq.id(R.id.buttonState).getButton().getText().toString());
		customer.getCustomer().setLatitude(aq.id(R.id.editTextLatitude).getEditText().getText().toString());
		customer.getCustomer().setLongitude(aq.id(R.id.editTextLongitude).getEditText().getText().toString());
		
		customer.setToAssignOptionSelectedJSON(jsonAssignOption);
		//customer.getLgArea().setId(lga_id);
		//customer.getCustomer().setLg_area_id(lga_id);
		customer.getCustomer().setRoute_id(route_id);
		//customer.getLgArea().setName(aq.id(R.id.buttonLGA).getButton().getText().toString());
		customer.getRegion().setId(region_id);
		customer.getCustomer().setRegion_id(region_id);
		customer.getRegion().setTitle(aq.id(R.id.buttonRegion).getButton().getText().toString());
		customer.getDepot().setId(depot_id);
		customer.getCustomer().setDepot_id(depot_id);
		customer.getDepot().setTitle(aq.id(R.id.buttonDepot).getButton().getText().toString());
		customer.getCustomer().setDescription(aq.id(R.id.editTextDescription).getEditText().getText().toString());
		customer.getCustomer().setView_details(aq.id(R.id.checkBoxIsDisplayCustDetail).getCheckBox().isChecked());//2014-03-02 20:30:19
		
		customer.getCustomer().setCategory_id(category_id);		
		customer.getCustomer().setSub_category_id(subcat_id);
		customer.getCustomer().setPayment_term(payment_terms_id);
		
		jsonString = customer.createJson(aq,true);
		Log.d("MTK", "edit customer="+jsonString);
		 selectedImagePath=null;
		if(aq.id(R.id.imageViewPhoto).getImageView().getTag()!=null)
		{
			selectedImagePath = aq.id(R.id.imageViewPhoto).getImageView().getTag().toString();
			Log.d("MTK", "user selected image path:"+selectedImagePath);
		}
		
		if(AppManager.isOnline(getActivity())){
			
			
			new AddCustomerAsync().execute();
		}else{
			Y3QueryDataSource datasource = new Y3QueryDataSource(getActivity());
		    datasource.open();
		    //customer.getCustomer().getId()
		    DateFormat dateFormat = new SimpleDateFormat("HHmmss");
			Date date = new Date();
	
			String  firstLetter = dateFormat.format(date).toString().replaceFirst("^0+(?!$)", "");	
		  	customer.getCustomer().setId(firstLetter);
		    customer.getCustomer().setImage_path(selectedImagePath);
		    customer.getCustomer().setCreated(AppConstant.getCurrentDateAndTime());
		    customer.getCustomer().setModified(AppConstant.SYNC_NOT_DONE);
		    datasource.addCustomerData(customer, "1", "0");
		    showSaveDialog();
		    SharedPreferences cprefs = getActivity().getSharedPreferences("BGGeoCollector", getActivity().MODE_PRIVATE);
			Editor edt = cprefs.edit();
			edt.putString("cdraftJsonString", null);
			edt.commit();
			isDraft = true;
		  
			
		}
		
		
		

	}
	
	private void addLatLong()
	{
		try
		{
			LocationAjaxCallback lac=new LocationAjaxCallback();			
			lac.weakHandler(this, "locationCB");
			lac.async(getActivity());
		}
		catch(NumberFormatException ex)
		{
			ex.printStackTrace();
		}
	}
	public void locationCB(String url, Location loc, AjaxStatus status)
	{
		aq.id(R.id.editTextLatitude).text(""+loc.getLatitude());
		aq.id(R.id.editTextLongitude).text(""+loc.getLongitude());
	}
	
private class AddCustomerAsync extends AsyncTask<Void, Void, String> {


ProgressDialog progressDialog;

@Override
protected void onPreExecute() {
	super.onPreExecute();
	progressDialog = new ProgressDialog(getActivity());
	progressDialog.setMessage(getString(R.string.wait_progress));
	progressDialog.setCancelable(false);
	progressDialog.setIndeterminate(true);
	progressDialog.show();
	progressDialog
			.setOnKeyListener(new DialogInterface.OnKeyListener() {
				@Override
				public boolean onKey(DialogInterface dialog,
						int keyCode, KeyEvent event) {
					return false;
				}
			});
}


protected String doInBackground(Void... params) {
	String response=null;
	if (AppManager.getInstance().isOnline(aq.getContext())) {
		//return AppManager.getInstance().getCustomerList(aq, pageCount);
		Hashtable<String,String> params1=new Hashtable<String,String>();
		params1.put("jsonString", jsonString);
		Hashtable<String,File> fileParams=null;
		if(selectedImagePath!=null && selectedImagePath.length()>0)
		{
			fileParams=new Hashtable<String,File>();
    		fileParams.put("image", new File(selectedImagePath));
		}
		response = Utils.post(getActivity(), AppManager.getInstance().URL_UPDATE_CUSTOMER, params1, fileParams);
		if(response!=null){
			int errorCode;
			try {
				errorCode = new JSONObject(response).getInt("error");
				if(errorCode==0){
					AppManager.getInstance().getAppSettingData(aq);
				}
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}			
			
		
		}
	}
		return response;

}

protected void onPostExecute(String response) {
	
	progressDialog.dismiss();
	
	try {
		if(response!=null){
		int errorCode=new JSONObject(response).getInt("error");
		
		if(errorCode==0){
			System.out.println("Added");
			showSaveDialog();
			SharedPreferences cprefs = getActivity().getSharedPreferences("BGGeoCollector", getActivity().MODE_PRIVATE);
			Editor edt = cprefs.edit();
			edt.putString("cdraftJsonString", null);
			edt.commit();
			isDraft = true;
		}
		else{
			System.out.println("something wrong");
			
		}
		}
	} catch (JSONException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}
}	
	
private void showSaveDialog(){	
	AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
			getActivity());
	alertDialogBuilder.setTitle(getString(R.string.confirm));
	alertDialogBuilder
			.setMessage(getString(R.string.customer_added))
			.setCancelable(false)
			.setPositiveButton(
					getString(R.string.OK),
					new DialogInterface.OnClickListener() {
						public void onClick(
								DialogInterface dialog,
								int id) {
							
							getActivity().getSupportFragmentManager().popBackStack();
							dialog.cancel();
						}
					});
		
	AlertDialog alertDialog = alertDialogBuilder
			.create();
	alertDialog.show();
}

public void caddDraft(){
	if(!isDraft){
		customer=new Customer();
		customer.getCustomer().setFirst_name(aq.id(R.id.editTextFirstName).getEditText().getText().toString());
		customer.getCustomer().setLast_name(aq.id(R.id.editTextLastName).getEditText().getText().toString());
		customer.getCustomer().setCategory_id(aq.id(R.id.buttonCategory).getButton().getText().toString());	
		customer.getCustomer().setSub_category_id(aq.id(R.id.buttonSubCategory).getButton().getText().toString());	
		customer.getCustomer().setPayment_term(aq.id(R.id.buttonPaymentTerm).getButton().getText().toString());	
		customer.getCustomer().setEmail(aq.id(R.id.editTextEmail).getEditText().getText().toString());
		customer.getCustomer().setPhone(aq.id(R.id.editTextPhone).getEditText().getText().toString());
		customer.getCustomer().setAddress(aq.id(R.id.editTextAddress).getEditText().getText().toString());
		customer.getCustomer().setCity(aq.id(R.id.editTextCity).getEditText().getText().toString());
		customer.getCustomer().setZipcode(aq.id(R.id.editTextZipcode).getEditText().getText().toString());		
		customer.getCustomer().setLatitude(aq.id(R.id.editTextLatitude).getEditText().getText().toString());
		customer.getCustomer().setLongitude(aq.id(R.id.editTextLongitude).getEditText().getText().toString());
		customer.getCustomer().setDescription(aq.id(R.id.editTextDescription).getEditText().getText().toString());
	
		customer.getRegion().setId(region_id);
		customer.getCustomer().setRegion_id(region_id);
		customer.getRegion().setTitle(aq.id(R.id.buttonRegion).getButton().getText().toString());
		
		customer.getDepot().setId(depot_id);
		customer.getCustomer().setDepot_id(depot_id);
		customer.getDepot().setTitle(aq.id(R.id.buttonDepot).getButton().getText().toString());
		
		customer.getState().setId(route_id);
		customer.getCustomer().setRoute_id(route_id);
		customer.getState().setState(aq.id(R.id.buttonRoute).getButton().getText().toString());
		//System.out.println("ROUTEID"+aq.id(R.id.buttonRoute).getButton().getText().toString());
        

		String cdraftJsonString = customer.createJson(aq,true);		
		SharedPreferences cprefs = getActivity().getSharedPreferences("BGGeoCollector", getActivity().MODE_PRIVATE);
		Editor edt = cprefs.edit();
		edt.putString("cdraftJsonString", cdraftJsonString);
		edt.commit();
		isDraft = true;
	}
}



public void cfillfromDraft(){
	SharedPreferences cprefs = getActivity().getSharedPreferences("BGGeoCollector", getActivity().MODE_PRIVATE);
	String cdraftJsonString = cprefs.getString("cdraftJsonString", null);
	//System.out.println("CUstomerLIST:"+draftJsonString);
	if(cdraftJsonString != null){
		try {
			JSONObject custJson = new JSONObject(cdraftJsonString);
			String FirstName = custJson.isNull("first_name") ? ""	: custJson.getString("first_name");
			aq.id(R.id.editTextFirstName).text(FirstName);
			String LastName = custJson.isNull("last_name") ? ""	: custJson.getString("last_name");
			aq.id(R.id.editTextLastName).text(LastName);
			String category_id = custJson.isNull("category_id") ? ""	: custJson.getString("category_id");
			aq.id(R.id.buttonCategory).text(category_id);
			String sub_category_id = custJson.isNull("sub_category_id") ? ""	: custJson.getString("sub_category_id");
			aq.id(R.id.buttonSubCategory).text(sub_category_id);
			String payment_term = custJson.isNull("payment_term") ? ""	: custJson.getString("payment_term");
			aq.id(R.id.buttonPaymentTerm).text(payment_term);
			String Email = custJson.isNull("email") ? ""	: custJson.getString("email");
			aq.id(R.id.editTextEmail).text(Email);
			String PhoneNumber = custJson.isNull("phone") ? ""	: custJson.getString("phone");
			aq.id(R.id.editTextPhone).text(PhoneNumber);
			String Address = custJson.isNull("address") ? ""	: custJson.getString("address");
			aq.id(R.id.editTextAddress).text(Address);
			String City = custJson.isNull("city") ? ""	: custJson.getString("city");
			aq.id(R.id.editTextCity).text(City);
			String Zipcode = custJson.isNull("zipcode") ? ""	: custJson.getString("zipcode");
			aq.id(R.id.editTextZipcode).text(Zipcode);
			String Latitude = custJson.isNull("latitude") ? ""	: custJson.getString("latitude");
			aq.id(R.id.editTextLatitude).text(Latitude);
			String Longitude = custJson.isNull("longitude") ? ""	: custJson.getString("longitude");
			aq.id(R.id.editTextLongitude).text(Longitude);
			String Description = custJson.isNull("description") ? ""	: custJson.getString("description");
			aq.id(R.id.editTextDescription).text(Description);
			
			

			region_id = custJson.isNull("region_id") ? ""	: custJson.getString("region_id");
			Regions regions = AppManager.getInstance().getRegions(aq);
			String RegionName = regions.getDepotNameById(region_id);
			aq.id(R.id.buttonRegion).text(RegionName); 
			
			
			depot_id = custJson.isNull("depot_id") ? ""	: custJson.getString("depot_id");
			Depots depots = AppManager.getInstance().getDepots(aq);
			String DepotName = depots.getDepotNameById(depot_id);
			aq.id(R.id.buttonDepot).text(DepotName);
			
			route_id = custJson.isNull("route_id") ? ""	: custJson.getString("route_id");
			String RouteName = custJson.isNull("route_name") ? ""	: custJson.getString("route_name");
			aq.id(R.id.buttonRoute).text(RouteName);
		
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}

		
}
