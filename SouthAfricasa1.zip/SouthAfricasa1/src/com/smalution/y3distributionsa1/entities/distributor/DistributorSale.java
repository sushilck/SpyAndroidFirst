package com.smalution.y3distributionsa1.entities.distributor;




import java.util.ArrayList;

import org.json.JSONObject;

import com.smalution.y3distributionsa1.entities.salesorder.SOSale;

import android.os.Parcel;
import android.os.Parcelable;

public class DistributorSale implements Parcelable
{
	RedistributorSaleItem RedistributorSaleitem;
	RedistributorBrand Brand;
	
	public DistributorSale()
	{
		RedistributorSaleitem=new RedistributorSaleItem();
		Brand=new RedistributorBrand();
	}
	public DistributorSale(JSONObject jsonObject)
	{
		try
		{
			RedistributorSaleitem=jsonObject.isNull("RedistributorSaleitem")?null:new RedistributorSaleItem(jsonObject.getJSONObject("RedistributorSaleitem"));
			Brand=jsonObject.isNull("Brand")?null:new RedistributorBrand(jsonObject.getJSONObject("Brand"));
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	public DistributorSale(JSONObject jsonObject,String json)
	{
		try
		{
			//Sale=new SOSale(jsonObject);
			RedistributorSaleitem=new RedistributorSaleItem(jsonObject);
			Brand=jsonObject.isNull("Brand")?null:new RedistributorBrand(jsonObject.getJSONObject("Brand"));
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	public DistributorSale(Parcel in)
 	{
		RedistributorSaleitem=in.readParcelable(RedistributorSaleItem.class.getClassLoader());
		Brand=in.readParcelable(RedistributorBrand.class.getClassLoader());
	}
 	@Override
 	public int describeContents() 
 	{
 		return 0;
 	}
 	@Override
 	public void writeToParcel(Parcel dest, int flags) 
 	{
 		dest.writeParcelable( RedistributorSaleitem,flags);
 		dest.writeParcelable( Brand,flags);
 	}
 	public static final Parcelable.Creator<DistributorSale> CREATOR = new Parcelable.Creator<DistributorSale>() 
 	{
 		public DistributorSale createFromParcel(Parcel in) 
 		{
 			return new DistributorSale(in);
 		}
 	
 		public DistributorSale[] newArray (int size) 
 		{
 			return new DistributorSale[size];
 		}
 	};

	public RedistributorSaleItem getRedistributorSaleitem() {
		return RedistributorSaleitem;
	}
	public void setRedistributorSaleitem(RedistributorSaleItem redistributorSaleitem) {
		RedistributorSaleitem = redistributorSaleitem;
	}
	public RedistributorBrand getBrand() {
		return Brand;
	}
	public void setBrand(RedistributorBrand brand) {
		Brand = brand;
	}
 	
	
	
	
//	public String createJson(AQuery aq, boolean isForAddCustomer)
//	{
//		SharedPreferences prefs = AppManager.getInstance().getPrefs(aq.getContext());
//		String token = prefs.getString("token", null);
//		if(isForAddCustomer)
//		{
//			String json="{" +
//					"\"token\":\""+token+"\"," +
//					"\"first_name\":\""+getCustomer().getFirst_name()+"\"," +
//					"\"last_name\":\""+getCustomer().getLast_name()+"\"," +
//					"\"email\":\""+getCustomer().getEmail()+"\"," +
//					"\"address\":\""+getCustomer().getAddress()+"\"," +
//					"\"city\":\""+getCustomer().getCity()+"\"," +
//					"\"state_id\":\""+getCustomer().getState_id()+"\"," +
//					"\"latitude\":\""+getCustomer().getLatitude()+"\"," +
//					"\"longitude\":\""+getCustomer().getLongitude()+"\"," +
//					"\"zipcode\":\""+getCustomer().getZipcode()+"\"," +
//					"\"phone\":\""+getCustomer().getPhone()+"\"," +
//					"\"region_id\":\""+getCustomer().getRegion_id()+"\"," +
//					"\"depot_id\":\""+getCustomer().getDepot_id()+"\"," +
//					"\"lg_area_id\":\""+getCustomer().getLg_area_id()+"\"," +
//					"\"description\":\""+getCustomer().getDescription()+"\"," +
//					"\"view_details\":\""+getCustomer().getView_details()+"\"" +
//					"}";
//			return json;
//		}
//		else
//		{
//			String json="{" +
//					"\"token\":\""+token+"\"," +
//					"\"id\":\""+getCustomer().getId()+"\"," +
//					"\"oldFile_id\":\""+getCustomer().getFile_id()+"\"," +
//					"\"first_name\":\""+getCustomer().getFirst_name()+"\"," +
//					"\"last_name\":\""+getCustomer().getLast_name()+"\"," +
//					"\"email\":\""+getCustomer().getEmail()+"\"," +
//					"\"address\":\""+getCustomer().getAddress()+"\"," +
//					"\"city\":\""+getCustomer().getCity()+"\"," +
//					"\"state_id\":\""+getCustomer().getState_id()+"\"," +
//					"\"latitude\":\""+getCustomer().getLatitude()+"\"," +
//					"\"longitude\":\""+getCustomer().getLongitude()+"\"," +
//					"\"zipcode\":\""+getCustomer().getZipcode()+"\"," +
//					"\"phone\":\""+getCustomer().getPhone()+"\"," +
//					"\"region_id\":\""+getCustomer().getRegion_id()+"\"," +
//					"\"depot_id\":\""+getCustomer().getDepot_id()+"\"," +
//					"\"lg_area_id\":\""+getCustomer().getLg_area_id()+"\"," +
//					"\"description\":\""+getCustomer().getDescription()+"\"," +
//					"\"view_details\":\""+getCustomer().getView_details()+"\"" +
//					"}";
//			return json;
//		}
//		
//		
//	}
 	
 	
}
