package com.smalution.y3distributionsa1.entities.settings;

import org.json.JSONObject;

public class Brand 
{
	 private String id="";
     private String name="";
     private String price_set="";
    // private String sku="";
     
    // private String category_id="";
   //  private String groupA="";
    // private String groupB="";
    // private String groupC="";
    /// private String groupD="";
     //private String status="";
     
     public Brand(){}
	public Brand(JSONObject jsonObect)
	{
		try
		{
			setId(jsonObect.isNull("id")?"":jsonObect.getString("id"));
			setName(jsonObect.isNull("name")?"":jsonObect.getString("name"));			
			setPrice_set(jsonObect.isNull("price_set")?"":jsonObect.getString("price_set"));
			
			/*setSku(jsonObect.isNull("sku")?"":jsonObect.getString("sku"));
			setCategory_id(jsonObect.isNull("category_id") ? "":jsonObect.getString("category_id"));
			setGroupA(jsonObect.isNull("groupA") ? "" : jsonObect.getString("groupA"));
			setGroupB(jsonObect.isNull("groupB") ? "" : jsonObect.getString("groupB"));
			setGroupC(jsonObect.isNull("groupC") ? "" : jsonObect.getString("groupC"));
			setGroupD(jsonObect.isNull("groupD") ? "" : jsonObect.getString("groupD"));
			setStatus(jsonObect.isNull("status") ? "" : jsonObect.getString("status"));*/
			
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
/*	public String getSku() {
		return sku;
	}
	public void setSku(String sku) {
		this.sku = sku;
	}
	public String getCategory_id() {
		return category_id;
	}
	public void setCategory_id(String category_id) {
		this.category_id = category_id;
	}
	public String getGroupA() {
		return groupA;
	}
	public void setGroupA(String groupA) {
		this.groupA = groupA;
	}
	public String getGroupB() {
		return groupB;
	}
	public void setGroupB(String groupB) {
		this.groupB = groupB;
	}
	public String getGroupC() {
		return groupC;
	}
	public void setGroupC(String groupC) {
		this.groupC = groupC;
	}
	public String getGroupD() {
		return groupD;
	}
	public void setGroupD(String groupD) {
		this.groupD = groupD;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}	*/
	public String getPrice_set() {
		return price_set;
	}
	public void setPrice_set(String price_set) {
		this.price_set = price_set;
	}
	
	
}