package com.smalution.y3distributionbz.fragments.customervisit;
import org.json.JSONException;
import org.json.JSONObject;

import com.smalution.y3distributionbz.AppManager;
import com.smalution.y3distributionbz.R;
import com.smalution.y3distributionbz.entities.customervisits.CustomerVisit;
import com.smalution.y3distributionbz.entities.settings.Brands;
import com.smalution.y3distributionbz.fragments.SuperFragment;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.TableRow.LayoutParams;

import com.androidquery.AQuery;

public class CustomerVisitViewFragment extends SuperFragment 
{
	CustomerVisit customerVisit;
	View rootView;
	AQuery aq; 
	public void setUIArguments(final Bundle args) 
	{
	    getActivity().runOnUiThread(new Runnable() 
	    {
	        public void run() 
	        {
	        	customerVisit = args.getParcelable("CUSTOMERVISIT");
	        }
	    });
	}
	@Override
	public void onCreate(Bundle savedInstanceState) 
	{
		super.onCreate(savedInstanceState);
		customerVisit = getArguments().getParcelable("CUSTOMERVISIT");
	}
	@Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,Bundle savedInstanceState) 
	{
        rootView = inflater.inflate(R.layout.customer_visit_view_fragment, container, false);
        aq=new AQuery(rootView);
        initUI();
        addbrandUI(aq.getContext());
        return rootView;
    }
	private void initUI() 
	{
		aq.id(R.id.textViewName).text(customerVisit.getCustomer().getFirst_name()+" "+customerVisit.getCustomer().getLast_name());
		aq.id(R.id.textViewDepot).text(customerVisit.getDepot().getTitle());
		//aq.id(R.id.textViewLGA).text(customerVisit.getLgArea().getName());
		aq.id(R.id.textViewVisitingDate).text(customerVisit.getCustomerVisit().getVisiting_date());
		aq.id(R.id.textViewCreatedDate).text(customerVisit.getCustomerVisit().getCreated());
		aq.id(R.id.textViewSynchronizationData).text(customerVisit.getCustomerVisit().getModified());
		aq.id(R.id.textViewComment).text(customerVisit.getCustomerVisit().getComment());
		String comments = customerVisit.getCustomerVisit().getComment();
		if(comments.equals("Stock Available")){
			aq.id(R.id.stockstatus_layout).visible();		
		}
	}
	
	public void addbrandUI(Context context){
    	Brands brands = AppManager.getInstance().getBrands(aq);
    	String[] arr=brands.getBrandsNames();
    	if ( arr.length > 0 ){
    		final TableLayout tblLayout = (TableLayout) aq.id(R.id.stockstatus_layout).getView();
    		
    		String  stockStatus = customerVisit.getCustomerVisit().getStock_status();
    		JSONObject statusObj = null;
    		try {
				System.out.println(stockStatus);
				statusObj = new JSONObject(stockStatus);					
    		} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			// Create LinearLayout
    		for (int j=0; j<arr.length; j++){
    			TableRow tblRow = new TableRow(context);
    			TableLayout.LayoutParams tblRowParms = new TableLayout.LayoutParams(LayoutParams.WRAP_CONTENT,
    					LayoutParams.WRAP_CONTENT, 1f);
    			tblRowParms.setMargins(0, convertPixToDp(5, context), 0, convertPixToDp(5, context));
    			tblRow.setLayoutParams(tblRowParms);
    			
    			// Create TextView
    			String brandName = brands.getItem(j).getName();
    			String brandId = brands.getItem(j).getId();
    				    			
                TextView brandLable = new TextView(context);
                
                TableRow.LayoutParams txtparams = new TableRow.LayoutParams(LayoutParams.WRAP_CONTENT,LayoutParams.WRAP_CONTENT, 1f);
                brandLable.setTextColor(Color.BLACK);
                brandLable.setWidth(convertPixToDp(100, context));
                brandLable.setLayoutParams(txtparams);
                brandLable.setTypeface(null, Typeface.BOLD);
                brandLable.setTextSize(convertPixToDp(12, context));
                brandLable.setSingleLine(true);
                brandLable.setText(brandName);
                tblRow.addView(brandLable);
                               
                TextView editText = new TextView(context); 
               // txtparams.weight= (float) 0.65;
                editText.setTextColor(Color.BLACK);
                editText.setSingleLine(true);
                editText.setLayoutParams(txtparams);
                editText.setTextSize(convertPixToDp(12, context));
                //editText.setBackgroundResource(R.drawable.round_corner_edittext_bg);
                editText.setId(Integer.valueOf(brandId)); 
                
                try {
					String stVal = statusObj.isNull(brandId)?"-":statusObj.getString(brandId);
					editText.setText(stVal);;
				} catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
                tblRow.addView(editText);
                
                tblLayout.addView(tblRow);
    		}
    		
    	}
    }
	public static int convertPixToDp(float px, Context context){
        Resources resources = context.getResources();
        DisplayMetrics metrics = resources.getDisplayMetrics();
        int dp = (int) (px / (metrics.densityDpi / 160f));
        return dp;
    }	 
}
