package com.smalution.y3distributionbz.entities.customer;


import org.json.JSONObject;

import com.smalution.y3distributionbz.entities.Expense;

import android.os.Parcel;
import android.os.Parcelable;

public class CustDepot implements Parcelable
{
	private String id;
	private String title;
	public CustDepot(){}
	public CustDepot(JSONObject jsonObect)
	{
		try
		{
			id=jsonObect.isNull("id")?"":jsonObect.getString("id");
			title=jsonObect.isNull("title")?"":jsonObect.getString("title");
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	public CustDepot(Parcel in)
 	{
		id = in.readString();
		title = in.readString();
	}
 	@Override
 	public int describeContents() 
 	{
 		return 0;
 	}
 	@Override
 	public void writeToParcel(Parcel dest, int flags) 
 	{
 		dest.writeString(id);
 		dest.writeString(title);
	}
 	public static final Parcelable.Creator<CustDepot> CREATOR = new Parcelable.Creator<CustDepot>() 
 	{
 		public CustDepot createFromParcel(Parcel in) 
 		{
 			return new CustDepot(in);
 		}
 	
 		public CustDepot[] newArray (int size) 
 		{
 			return new CustDepot[size];
 		}
 	};
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	
}
