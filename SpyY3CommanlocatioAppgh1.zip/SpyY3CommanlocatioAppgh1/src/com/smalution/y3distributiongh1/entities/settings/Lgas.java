package com.smalution.y3distributiongh1.entities.settings;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONObject;

public class Lgas 
{
	private ArrayList<SelectionButtonItem> lgas;
	String[] lgaNamesArr; 
	public Lgas(){}
	public Lgas(JSONArray jsonArray)
	{
		try
		{
			lgas=new ArrayList<SelectionButtonItem>();
			lgaNamesArr=new String[jsonArray.length()];
			for(int i=0;i<jsonArray.length();i++)
			{
				JSONObject jsonObject = jsonArray.getJSONObject(i).getJSONObject("LgArea"); 
				String id=jsonObject.isNull("id")?"":jsonObject.getString("id");
				String name=jsonObject.isNull("name")?"":jsonObject.getString("name");
				String state_id=jsonObject.isNull("state_id")?"":jsonObject.getString("state_id");
				SelectionButtonItem itm=new SelectionButtonItem(id, state_id, name);
				lgas.add(itm);
				lgaNamesArr[i]=itm.getTitle();
			}
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	public String getDepotNameById(String id)
	{
		for(SelectionButtonItem itm:lgas)
		{
			if(itm.getId().equals(id))
				return itm.getTitle();
		}
		return null;
	}
	public SelectionButtonItem getItem(int position)
	{
		return lgas.get(position);
	}
	public String[] getLgaNamesArr() {
		return lgaNamesArr;
	}
	public void setLgaNamesArr(String[] lgaNamesArr) {
		this.lgaNamesArr = lgaNamesArr;
	}
}
