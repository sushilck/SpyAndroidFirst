package com.smalution.y3distributiongh1.entities.settings;

import java.util.ArrayList;

import org.json.JSONArray;

import com.smalution.y3distributiongh1.entities.settings.Brand;

public class Brands 
{
	private ArrayList<Brand> brands;
	String[] brandsNames; 
	public Brands(){}
	public Brands(JSONArray jsonArray)
	{
		try
		{
			brands=new ArrayList<Brand>();
			brandsNames=new String[jsonArray.length()];
			for(int i=0;i<jsonArray.length();i++)
			{
				Brand b = new Brand(jsonArray.getJSONObject(i).getJSONObject("Brand"));
				brands.add(b);
				brandsNames[i]=b.getName();
			}
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	
	public Brand getBrandByName(String name)
	{
		for(Brand itm:brands)
		{
			if(itm.getName().equals(name))
				return itm;
		}
		return null;
	}
	public Brand getBrandById(String id)
	{
		for(Brand itm:brands)
		{
			if(itm.getId().equals(id))
				return itm;
		}
		return null;
	}
	public Brand getItem(int position)
	{
		return brands.get(position);
	}
	public String[] getBrandsNames() {
		return brandsNames;
	}
	public void setBrandsNames(String[] brandsNames) {
		this.brandsNames = brandsNames;
	}
	public String getDepotNameById(String brand_id)
	{
		for(Brand itm:brands)
		{
			if(itm.getId().equals(brand_id))
				return itm.getName();
		}
		return null;
	}
	
	
}
