package com.smalution.y3distributiongh1.entities.settings;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;

import org.json.JSONArray;
import org.json.JSONObject;

public class Distributors 
{
	private ArrayList<SelectionButtonItem> distributors;
	String[] nameArray;
	public Distributors(){}
	public Distributors(JSONArray jsonArray)
	{
		try
		{
			distributors=new ArrayList<SelectionButtonItem>();
			nameArray=new String[jsonArray.length()];
			for(int i=0;i<jsonArray.length();i++)
			{
				JSONObject jsonObject = jsonArray.getJSONObject(i).getJSONObject("distributors"); 
				String id=jsonObject.isNull("id")?"":jsonObject.getString("id");
				String title=jsonObject.isNull("title")?"":jsonObject.getString("title");
				String state_id=jsonObject.isNull("state_id")?"":jsonObject.getString("state_id");
				SelectionButtonItem itm=new SelectionButtonItem(id, state_id, title);
				distributors.add(itm);
				nameArray[i]=itm.getTitle();
			}
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	public String getDepotNameById(String id)
	{
		for(SelectionButtonItem itm:distributors)
		{
			if(itm.getId().equals(id))
				return itm.getTitle();
		}
		return null;
	}
	public SelectionButtonItem getItem(int position)
	{
		return distributors.get(position);
	}
	public String[] getNameArray() {
		return nameArray;
	}
	public void setNameArray(String[] nameArray) {
		this.nameArray = nameArray;
	}
	
	
}
