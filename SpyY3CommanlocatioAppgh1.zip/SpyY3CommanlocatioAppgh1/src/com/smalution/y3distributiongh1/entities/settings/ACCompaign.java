package com.smalution.y3distributiongh1.entities.settings;

import org.json.JSONObject;

public class ACCompaign 
{
	private String id;
	private String title;
	private String brand_id;
	private String user_id;
	private String start_date;
	private String end_date;
	private String required_qty;
	private String required_unit;
	private String free_qty;
	private String free_unit;
	private String cal_percent;
	private String status;
	private String created;
	private String modified;
	
    public ACCompaign(){}
	public ACCompaign(JSONObject jsonObect)
	{
		try
		{
			id=jsonObect.isNull("id")?"":jsonObect.getString("id");
			title=jsonObect.isNull("title")?"":jsonObect.getString("title");
			brand_id=jsonObect.isNull("brand_id")?"":jsonObect.getString("brand_id");
			user_id=jsonObect.isNull("user_id")?"":jsonObect.getString("user_id");
			start_date=jsonObect.isNull("start_date")?"":jsonObect.getString("start_date");
			end_date=jsonObect.isNull("end_date")?"":jsonObect.getString("end_date");
			required_qty=jsonObect.isNull("required_qty")?"":jsonObect.getString("required_qty");
			required_unit=jsonObect.isNull("required_unit")?"":jsonObect.getString("required_unit");
			free_qty=jsonObect.isNull("free_qty")?"":jsonObect.getString("free_qty");
			free_unit=jsonObect.isNull("free_unit")?"":jsonObect.getString("free_unit");
			cal_percent=jsonObect.isNull("cal_percent")?"":jsonObect.getString("cal_percent");
			status=jsonObect.isNull("status")?"":jsonObect.getString("status");
			created=jsonObect.isNull("created")?"":jsonObect.getString("created");
			modified=jsonObect.isNull("modified")?"":jsonObect.getString("modified");
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getBrand_id() {
		return brand_id;
	}
	public void setBrand_id(String brand_id) {
		this.brand_id = brand_id;
	}
	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	public String getStart_date() {
		return start_date;
	}
	public void setStart_date(String start_date) {
		this.start_date = start_date;
	}
	public String getEnd_date() {
		return end_date;
	}
	public void setEnd_date(String end_date) {
		this.end_date = end_date;
	}
	public String getRequired_qty() {
		return required_qty;
	}
	public void setRequired_qty(String required_qty) {
		this.required_qty = required_qty;
	}
	public String getRequired_unit() {
		return required_unit;
	}
	public void setRequired_unit(String required_unit) {
		this.required_unit = required_unit;
	}
	public String getFree_qty() {
		return free_qty;
	}
	public void setFree_qty(String free_qty) {
		this.free_qty = free_qty;
	}
	public String getFree_unit() {
		return free_unit;
	}
	public void setFree_unit(String free_unit) {
		this.free_unit = free_unit;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getCreated() {
		return created;
	}
	public void setCreated(String created) {
		this.created = created;
	}
	public String getModified() {
		return modified;
	}
	public void setModified(String modified) {
		this.modified = modified;
	}
	/**
	 * @return the cal_percent
	 */
	public String getCal_percent() {
		return cal_percent;
	}
	/**
	 * @param cal_percent the cal_percent to set
	 */
	public void setCal_percent(String cal_percent) {
		this.cal_percent = cal_percent;
	}
	
}
