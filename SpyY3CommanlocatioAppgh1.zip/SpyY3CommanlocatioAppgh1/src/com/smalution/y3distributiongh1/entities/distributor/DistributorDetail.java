package com.smalution.y3distributiongh1.entities.distributor;


import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONObject;

import android.content.SharedPreferences;
import android.os.Parcel;
import android.os.Parcelable;

import com.androidquery.AQuery;
import com.smalution.y3distributiongh1.AppManager;
import com.smalution.y3distributiongh1.utils.AppConstant;

public class DistributorDetail implements Parcelable
{
	Distributor rdsale;
	ArrayList<DistributorSale> sales;
	ArrayList<DistributorFreeItem> freeItems;
	String offlineCustomerJSON;
	public DistributorDetail()
	{
		 rdsale=new Distributor();
		 sales=new ArrayList<DistributorSale>();
		 freeItems=new ArrayList<DistributorFreeItem>();
	}
	public DistributorDetail(JSONObject jsonObject)
	{
		try
		{
			rdsale=jsonObject.isNull("rdsale")?null:new Distributor(jsonObject.getJSONObject("rdsale"));
			sales=jsonObject.isNull("sales")?null:getSalesList(jsonObject.getJSONArray("sales"));
			freeItems=jsonObject.isNull("freeItems")?null:getSalesFreeItemsList(jsonObject.getJSONArray("freeItems"));
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	public DistributorDetail(JSONObject jsonObject,int i,String json)
	{
		try
		{
			//SaleItems
			rdsale=new Distributor(new JSONObject(json));
			sales=jsonObject.isNull("sales")?null:getSalesList(jsonObject.getJSONArray("sales"),json);
			//freeItems=jsonObject.isNull("freeItems")?null:getSalesFreeItemsList(jsonObject.getJSONArray("freeItems"),json);
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	private ArrayList<DistributorFreeItem> getSalesFreeItemsList(JSONArray jsonArray) throws Exception
	{
		ArrayList<DistributorFreeItem> list = new ArrayList<DistributorFreeItem>();
		for(int i=0;i<jsonArray.length();i++)
		{
			list.add(new DistributorFreeItem(jsonArray.getJSONObject(i)));
		}
		return list;
	}
	private ArrayList<DistributorFreeItem> getSalesFreeItemsList(JSONArray jsonArray,String json) throws Exception
	{
		ArrayList<DistributorFreeItem> list = new ArrayList<DistributorFreeItem>();
		for(int i=0;i<jsonArray.length();i++)
		{
			list.add(new DistributorFreeItem(jsonArray.getJSONObject(i),json));
		}
		return list;
	}
	private ArrayList<DistributorSale> getSalesList(JSONArray jsonArray) throws Exception
	{
		ArrayList<DistributorSale> list=new ArrayList<DistributorSale>();
		for(int i=0;i<jsonArray.length();i++)
		{
			list.add(new DistributorSale(jsonArray.getJSONObject(i)));
		}
		return list;
	}
	private ArrayList<DistributorSale> getSalesList(JSONArray jsonArray,String json) throws Exception
	{
		ArrayList<DistributorSale> list=new ArrayList<DistributorSale>();
		for(int i=0;i<jsonArray.length();i++)
		{
			list.add(new DistributorSale(jsonArray.getJSONObject(i),json));
		}
		return list;
	}
	public DistributorDetail(Parcel in)
 	{
		rdsale=in.readParcelable(Distributor.class.getClassLoader());
		in.readTypedList(sales, DistributorSale.CREATOR);
		in.readTypedList(freeItems, DistributorFreeItem.CREATOR);
	}
 	@Override
 	public int describeContents() 
 	{
 		return 0;
 	}
 	@Override
 	public void writeToParcel(Parcel dest, int flags) 
 	{
 		dest.writeParcelable(rdsale,flags);
 		dest.writeTypedList(sales);
 		dest.writeTypedList(freeItems);
	}
 	public static final Parcelable.Creator<DistributorDetail> CREATOR = new Parcelable.Creator<DistributorDetail>() 
 	{
 		public DistributorDetail createFromParcel(Parcel in) 
 		{
 			return new DistributorDetail(in);
 		}
 	
 		public DistributorDetail[] newArray (int size) 
 		{
 			return new DistributorDetail[size];
 		}
 	};
	
	public Distributor getRdsale() {
		return rdsale;
	}
	public void setRdsale(Distributor rdsale) {
		this.rdsale = rdsale;
	}
	public ArrayList<DistributorSale> getSales() {
		return sales;
	}
	public void setSales(ArrayList<DistributorSale> sales) {
		this.sales = sales;
	}
	public ArrayList<DistributorFreeItem> getFreeItems() {
		return freeItems;
	}
	public void setFreeItems(ArrayList<DistributorFreeItem> freeItems) {
		this.freeItems = freeItems;
	}
 	
	public String createJson(AQuery aq,boolean isOnlineCustomerSelectionModeOn)
	{
		SharedPreferences prefs = AppManager.getInstance().getPrefs(aq.getContext());
		String token = prefs.getString("token", null);
		
		String json="{" +
			"\"token\":\""+token+"\"," +
			"\"created\":\""+AppConstant.getCurrentDateAndTime()+"\"," +	
			"\"request_id\":\""+AppConstant.ANDROIDDEVICEID + AppConstant.getRequestId()+"\"," +
			"\"customer_id\":\""+getRdsale().getRedistributorSale().getCustomer_id()+"\"," +
			"\"customer_name\":\""+getRdsale().getCustomer().getFirst_name()+"\"," +
			"\"redistributor_id\":\""+getRdsale().getRedistributorSale().getRedistributor_id()+"\"," +
			"\"sale_date\":\""+getRdsale().getRedistributorSale().getSale_date()+"\"," +
			"\"grand_total\":\""+getRdsale().getRedistributorSale().getTotal()+"\",";
			json=json+"\"sales\":[";
			if(getSales()!=null && getSales().size()>0)
			{
				for(DistributorSale sale:getSales())
				{
					json=json+"{\"brand_id\":\""+sale.getRedistributorSaleitem().getBrand_id()+"\"," +
							"\"unit\":\""+sale.getRedistributorSaleitem().getUnit()+"\"," +
							"\"unit_price\":\""+sale.getRedistributorSaleitem().getUnit_price()+"\"," +
							"\"quantity\":\""+sale.getRedistributorSaleitem().getQuantity()+"\"," +
							"\"amount\":\""+sale.getRedistributorSaleitem().getAmount()+"\"},";
				}
				json=json.substring(0, json.length()-1);
			}
			json=json+"],";
			json=json+"\"freeItem\":[";
			if(getFreeItems()!=null && getFreeItems().size()>0)
			{
				/*for(DistributorFreeItem freeItem:getFreeItems())
				{
					json=json+"{\"brand_id\":\""+freeItem.getRdFreeItem().getBrand_id()+"\"," +
							"\"unit\":\""+freeItem.getRdFreeItem().getUnit()+"\"," +
							"\"quantity\":\""+freeItem.getRdFreeItem().getQuantity()+"\"," +
							"\"compaign_id\":\""+freeItem.getRdFreeItem().getCompaign_id()+"\"},";
				}
				json=json.substring(0, json.length()-1);*/
			}
			if(!isOnlineCustomerSelectionModeOn)
			{
				json=json+"],";
				json=json+"\"newCustomer\":" ;
				json=json+getOfflineCustomerJSON();		
				json=json+"}";
			}
			else
			{
				json=json+"]}";
			}
		return json;
	}
	public String createJson(AQuery aq,boolean isOnlineCustomerSelectionModeOn,int id)
	{
		SharedPreferences prefs = AppManager.getInstance().getPrefs(aq.getContext());
		String token = prefs.getString("token", null);
		
		String json=
				
			"\"request_id\":\""+AppConstant.ANDROIDDEVICEID+AppConstant.getRequestId()+"\"," +	
			"\"created\":\""+AppConstant.getCurrentDateAndTime()+"\"," +
			"\"customer_id\":\""+getRdsale().getRedistributorSale().getCustomer_id()+"\"," +
			"\"customer_name\":\""+getRdsale().getCustomer().getFirst_name()+"\"," +
			"\"redistributor_id\":\""+getRdsale().getRedistributorSale().getRedistributor_id()+"\"," +
			"\"sale_date\":\""+getRdsale().getRedistributorSale().getSale_date()+"\"," +
			"\"grand_total\":\""+getRdsale().getRedistributorSale().getTotal()+"\",";
			json=json+"\"sales\":[";
			if(getSales()!=null && getSales().size()>0)
			{
				for(DistributorSale sale:getSales())
				{
					json=json+"{\"brand_id\":\""+sale.getRedistributorSaleitem().getBrand_id()+"\"," +
							"\"unit\":\""+sale.getRedistributorSaleitem().getUnit()+"\"," +
							"\"unit_price\":\""+sale.getRedistributorSaleitem().getUnit_price()+"\"," +
							"\"quantity\":\""+sale.getRedistributorSaleitem().getQuantity()+"\"," +
							"\"amount\":\""+sale.getRedistributorSaleitem().getAmount()+"\"},";
				}
				json=json.substring(0, json.length()-1);
			}
			json=json+"],";
			json=json+"\"freeItem\":[";
			if(getFreeItems()!=null && getFreeItems().size()>0)
			{
				/*for(DistributorFreeItem freeItem:getFreeItems())
				{
					json=json+"{\"brand_id\":\""+freeItem.getRdFreeItem().getBrand_id()+"\"," +
							"\"unit\":\""+freeItem.getRdFreeItem().getUnit()+"\"," +
							"\"quantity\":\""+freeItem.getRdFreeItem().getQuantity()+"\"," +
							"\"compaign_id\":\""+freeItem.getRdFreeItem().getCompaign_id()+"\"},";
				}
				json=json.substring(0, json.length()-1);*/
			}
			if(!isOnlineCustomerSelectionModeOn)
			{
				json=json+"],";
				json=json+"\"newCustomer\":" ;
				json=json+getOfflineCustomerJSON();		
				json=json+"}";
			}
			else
			{
				json=json+"]}";
			}
		return json;
	}
	public String getOfflineCustomerJSON() {
		return offlineCustomerJSON;
	}
	public void setOfflineCustomerJSON(String offlineCustomerJSON) {
		this.offlineCustomerJSON = offlineCustomerJSON;
	}
	
}
