package com.smalution.y3distributiongh1.entities.customer;

import org.json.JSONObject;

import android.os.Parcel;
import android.os.Parcelable;

public class CustState implements Parcelable
{
	private String id;
	private String state;
	public CustState(){}
	public CustState(JSONObject jsonObect)
	{
		try
		{
			id=jsonObect.isNull("id")?"":jsonObect.getString("id");
			state=jsonObect.isNull("state")?"":jsonObect.getString("state");
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	
	public CustState(Parcel in)
 	{
		id = in.readString();
		state = in.readString();
	}
 	@Override
 	public int describeContents() 
 	{
 		return 0;
 	}
 	@Override
 	public void writeToParcel(Parcel dest, int flags) 
 	{
 		dest.writeString(id);
 		dest.writeString(state);
	}
 	public static final Parcelable.Creator<CustState> CREATOR = new Parcelable.Creator<CustState>() 
 	{
 		public CustState createFromParcel(Parcel in) 
 		{
 			return new CustState(in);
 		}
 	
 		public CustState[] newArray (int size) 
 		{
 			return new CustState[size];
 		}
 	};
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	
}
