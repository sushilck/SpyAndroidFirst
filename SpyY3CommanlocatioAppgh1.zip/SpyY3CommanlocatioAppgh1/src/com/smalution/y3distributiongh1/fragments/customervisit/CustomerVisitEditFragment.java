package com.smalution.y3distributiongh1.fragments.customervisit;
import com.smalution.y3distributiongh1.AppManager;
import com.smalution.y3distributiongh1.R;
import com.smalution.y3distributiongh1.SendDataToServerAsyncTask;
import com.smalution.y3distributiongh1.database.Y3QueryDataSource;
import com.smalution.y3distributiongh1.entities.customer.SearchCutomer;
import com.smalution.y3distributiongh1.entities.customervisits.CustomerVisit;
import com.smalution.y3distributiongh1.entities.settings.Customers;
import com.smalution.y3distributiongh1.entities.settings.Depots;
import com.smalution.y3distributiongh1.entities.settings.Lgas;
import com.smalution.y3distributiongh1.entities.settings.SelectionButtonItem;
import com.smalution.y3distributiongh1.entities.settings.States;
import com.smalution.y3distributiongh1.fragments.SuperFragment;
import com.smalution.y3distributiongh1.utils.AppConstant;
import com.smalution.y3distributiongh1.utils.DateTimePickerCallbackInterface;
import com.smalution.y3distributiongh1.utils.DateTimePickerFragment;

import java.util.Hashtable;
import java.util.Set;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Toast;

import com.androidquery.AQuery;

public class CustomerVisitEditFragment extends SuperFragment {
	
	boolean isOnlineCustomerSelectionModeOn=true;
	Hashtable<String, String> offlineCustomers;
	CustomerVisit customerVisit;
	View rootView;
	AQuery aq; 
	public static final int FLAG_SELECT_CUSTOMER=101;
	public static final int FLAG_SELECT_LGA=102;
	public static final int FLAG_SELECT_DEPOT=103;
	public static final int FLAG_SELECT_STATE=104;
	UIHandler uiHandler;
	private String states_id;
	public static String jsonString;
	public class UIHandler extends Handler 
	{ 
        public void handleMessage(Message msg) 
        { 
        	switch(msg.arg1)
        	{
        		case FLAG_SELECT_CUSTOMER:
        		{
        			
        			if(isOnlineCustomerSelectionModeOn)
        			{
        				/*aq.id(R.id.buttonCustomer).text(selectedValue);
            			Customers customers = AppManager.getInstance().getCustomers(aq);
            			if(customers!=null)
            			{
            				SelectionButtonItem itm = customers.getItem(msg.arg2);
            				if(itm!=null)
            				{
            					customerVisit.getCustomerVisit().setCustomer_id(itm.getId());
            					customerVisit.getCustomer().setFirst_name(itm.getTitle());
            					customerVisit.getCustomer().setLast_name("");
            				}
                		}*/
        				SelectionButtonItem itm = (SelectionButtonItem) msg.obj;
        				aq.id(R.id.buttonCustomer).text(itm.getTitle());
        				if(itm!=null)
        				{
        					customerVisit.getCustomerVisit().setCustomer_id(itm.getId());
        					customerVisit.getCustomer().setFirst_name(itm.getTitle());
        					customerVisit.getCustomer().setLast_name("");
        				}
            			
        			}
        			else
        			{
        				String selectedValue=(String)msg.obj;
        				aq.id(R.id.buttonOfflineCustomer).text(selectedValue);
        			    String jsonString = offlineCustomers.get(selectedValue);
        			    customerVisit.getCustomer().setFirst_name(selectedValue);
        			    customerVisit.setOfflineCustomerJSON(jsonString);
        			}
        			break;
        		}
        		case FLAG_SELECT_LGA:
        		{
        			String selectedValue=(String)msg.obj;
        			aq.id(R.id.buttonLGA).text(selectedValue);
        			Lgas lgas = AppManager.getInstance().getLgas(aq);
        			if(lgas!=null)
        			{
        				customerVisit.getLgArea().setId(lgas.getItem(msg.arg2).getId());
        				customerVisit.getCustomerVisit().setLg_area_id(lgas.getItem(msg.arg2).getId());
        				customerVisit.getLgArea().setName(selectedValue);
        				
        				
        			}
        			break;
        		}
        		case FLAG_SELECT_STATE:
        		{
        			String selectedValue=(String)msg.obj;
        			aq.id(R.id.buttonState).text(selectedValue);
        			States states = AppManager.getInstance().getStates(aq);
        			if(states!=null)
        			{
        				
        				states_id=states.getItem(msg.arg2).getId();
        				aq.id(R.id.buttonLGA).text("AllLGA");
        				//System.out.println("DEMO");
        			}
        			break;
				}
        		case FLAG_SELECT_DEPOT:
	    		{
	    			String selectedValue=(String)msg.obj;
        			aq.id(R.id.buttonDepot).text(selectedValue);
        			Depots depots=AppManager.getInstance().getDepots(aq);
        			if(depots!=null)
        			{
        				customerVisit.getCustomerVisit().setDepot_id(depots.getItem(msg.arg2).getId());
        				customerVisit.getDepot().setTitle(selectedValue);
        			}
	    			break;
	    		}
        	}
        }
    };
	public void setUIArguments(final Bundle args) 
	{
	    getActivity().runOnUiThread(new Runnable() 
	    {
	        public void run() 
	        {
	        	customerVisit = args.getParcelable("CUSTOMER");
	        }
	    });
	}
	@Override
	public void onCreate(Bundle savedInstanceState) 
	{
		super.onCreate(savedInstanceState);
		customerVisit = getArguments().getParcelable("CUSTOMER");
	}
	@Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,Bundle savedInstanceState) 
	{
        rootView = inflater.inflate(R.layout.customer_visit_edit_fragment, container, false);
        uiHandler=new UIHandler();
        aq=new AQuery(rootView);
        initUI();
        return rootView;
    }
	private void initUI() 
	{
		aq.id(R.id.buttonCustomer).text(customerVisit.getCustomer().getFirst_name()+" "+customerVisit.getCustomer().getLast_name());
		aq.id(R.id.buttonLGA).text(customerVisit.getLgArea().getName());
		aq.id(R.id.buttonDepot).text(customerVisit.getDepot().getTitle());
		aq.id(R.id.editTextVisitingDate).text(customerVisit.getCustomerVisit().getVisiting_date());
		aq.id(R.id.editTextDescription).text(customerVisit.getCustomerVisit().getComment());
		//aq.id(R.id.buttonState).text(customerVisit.getState().getState());
		states_id=customerVisit.getState().getId();		
		aq.id(R.id.buttonCustomer).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				aq.id(R.id.buttonOfflineCustomer).text(getString(R.string.select_offline_customer));
				isOnlineCustomerSelectionModeOn=true;
			//	boolean flag=false;
				SearchCutomer.showAutosearchAlertDialog(getActivity(), uiHandler, FLAG_SELECT_CUSTOMER);
				/*Customers customers = AppManager.getInstance().getCustomers(aq);
				if(customers!=null)
				{
					String[] arr=customers.getCustomerNamesArr();
					if(arr.length>0)
					{
						AppManager.getInstance().showSelectionAlertDialog(getActivity(), uiHandler, FLAG_SELECT_CUSTOMER,arr);
						flag=true;
					}
				}
				if(!flag)
				{
					Toast.makeText(getActivity(), getString(R.string.customer_required_mess), Toast.LENGTH_SHORT).show();
				}*/
			}
		});
		aq.id(R.id.buttonOfflineCustomer).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				isOnlineCustomerSelectionModeOn=false;
				aq.id(R.id.buttonCustomer).text(getString(R.string.select_customer));
				new GetOfflineCustomersAsyncTask(aq).execute();
			}
		});
		/*aq.id(R.id.buttonState).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				boolean flag=false;
				States states = AppManager.getInstance().getStates(aq);
				if(states!=null)
				{
					String[] arr=states.getStatesNameArr();
					if(arr.length>0)
					{
						AppManager.getInstance().showSelectionAlertDialog(getActivity(), uiHandler, FLAG_SELECT_STATE, arr);
						flag=true;
					}
				}
				if(!flag)
				{
					Toast.makeText(getActivity(), getString(R.string.state_req_mess), Toast.LENGTH_SHORT).show();
				}
			}
		});
		aq.id(R.id.buttonLGA).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				boolean flag=false;
				//Lgas lgas = AppManager.getInstance().getLgas(aq);
				Lgas lgas = AppManager.getInstance().getLgas(aq,states_id);
				if(lgas!=null)
				{
					String[] arr=lgas.getLgaNamesArr();
					if(arr.length>0)
					{
						AppManager.getInstance().showSelectionAlertDialog(getActivity(), uiHandler, FLAG_SELECT_LGA, arr);
						flag=true;
					}
				}
				if(!flag)
				{
					Toast.makeText(getActivity(), "LGA is required, please contact administrator.", Toast.LENGTH_SHORT).show();
				}
			}
		});
		aq.id(R.id.buttonDepot).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				boolean flag=false;
				Depots depots=AppManager.getInstance().getDepots(aq);
				if(depots!=null)
				{
					String[] arr=depots.getTitleArr();
					if(arr.length>0)
					{
						AppManager.getInstance().showSelectionAlertDialog(getActivity(), uiHandler, FLAG_SELECT_DEPOT, arr);
						flag=true;
					}
				}
				if(!flag)
				{
					Toast.makeText(getActivity(), "Depots are required field, please contact administrator.", Toast.LENGTH_SHORT).show();
				}
			}
		});*/
		
		aq.id(R.id.buttonSave).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				updateCustomer();
			}
		});
		aq.id(R.id.editTextVisitingDate).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				showDatePicker();
			}
		});
	}
	private void showDatePicker() 
	{
		  DateTimePickerFragment date=new DateTimePickerFragment();
		  date.setCallBack(dateTimePickerCallbackInterface);
		  date.show(getActivity().getSupportFragmentManager(), getString(R.string.date_picker) );
	}
	DateTimePickerCallbackInterface dateTimePickerCallbackInterface = new DateTimePickerCallbackInterface() 
	{
		@Override
		public void onDateTimeSet(int year, int month, int day, int hours,int mins) 
		{
			String dateStr=String.valueOf(year) + "-" + String.valueOf(month+1)+ "-" + String.valueOf(day)+" "+hours+":"+mins;
			aq.id(R.id.editTextVisitingDate).text(dateStr);
		}
	};
	private boolean isValidated()
	{
		if((aq.id(R.id.buttonCustomer).getButton().getText().toString().length()>0 &&
				!aq.id(R.id.buttonCustomer).getButton().getText().toString().startsWith(getString(R.string.select))) || 
				(aq.id(R.id.buttonOfflineCustomer).getButton().getText().toString().length()>0 &&
						!aq.id(R.id.buttonOfflineCustomer).getButton().getText().toString().startsWith(getString(R.string.select))))
		{
			/*if(aq.id(R.id.buttonLGA).getButton().getText().toString().length()>0 &&
					!aq.id(R.id.buttonLGA).getButton().getText().toString().startsWith("Select"))
			{
				if(aq.id(R.id.buttonDepot).getButton().getText().toString().length()>0 &&
						!aq.id(R.id.buttonDepot).getButton().getText().toString().startsWith("Select"))
				{ */
					if(aq.id(R.id.editTextDescription).getEditText().getText().toString().length()>0)
					{
						return true;
					}
					else
					{
						Toast.makeText(getActivity(), getString(R.string.enter_description), Toast.LENGTH_SHORT).show();
					}
				/*}
				else
				{
					Toast.makeText(getActivity(), "Please select depot.", Toast.LENGTH_SHORT).show();
				}
			}
			else
			{
				Toast.makeText(getActivity(), "Please select lga.", Toast.LENGTH_SHORT).show();
			}*/
		}
		else
		{
			Toast.makeText(getActivity(), getString(R.string.select_customer_btn), Toast.LENGTH_SHORT).show();
		}
		return false;
	}
	private void updateCustomer()
	{
		if(!isValidated())
		{
			return;
		}
		
		
		customerVisit.getCustomerVisit().setVisiting_date(aq.id(R.id.editTextVisitingDate).getTextView().getText().toString());
		customerVisit.getCustomerVisit().setComment(aq.id(R.id.editTextDescription).getTextView().getText().toString());
		
		
		
		if(AppManager.isOnline(getActivity())){
			String jsonString = customerVisit.createJson(aq, false,isOnlineCustomerSelectionModeOn);
		new SendDataToServerAsyncTask<CustomerVisit>(
				getActivity(), 
				jsonString,
				null, 
				AppManager.getInstance().URL_UPDATE_CUSTOMERVISITS,
				getString(R.string.customer_visit_updated),
				true,
				null,
				null,
				-1,AppConstant.CUSTOMER_VISIT_EDIT).execute();
		}
		else{
			Y3QueryDataSource datasource = new Y3QueryDataSource(getActivity());
		    datasource.open();					   
		    customerVisit.getOfflineCustomerJSON();
		    datasource.updateCustomerVisit(customerVisit,customerVisit.getCustomerVisit().getId(),jsonString);
		    showEditDialog();
		    //Toast.makeText(getActivity(), "CustomerVisit update successfully.", Toast.LENGTH_SHORT).show();
	    	//getActivity().getSupportFragmentManager().popBackStack();
		}
		
		
	}
	private class GetOfflineCustomersAsyncTask extends AsyncTask<Void, Void,String[]>
	{
		AQuery aq;
		ProgressDialog progressDialog;
		boolean flag=false;
		public GetOfflineCustomersAsyncTask(AQuery aq)
		{
			this.aq=aq;
		}
		@Override
		protected void onPreExecute() 
		{
			super.onPreExecute();
			progressDialog = new ProgressDialog(getActivity());
	        progressDialog.setMessage(getString(R.string.wait_progress));
	        progressDialog.setCancelable(false);
	        progressDialog.setIndeterminate(true);
	        progressDialog.show();
	        progressDialog.setOnKeyListener(new DialogInterface.OnKeyListener() 
	        {
	            @Override
	            public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) 
	            {
	                return false;
	            }
	        });
		}
		@Override
		protected String[] doInBackground(Void... params) 
		{
			Y3QueryDataSource datasource = new Y3QueryDataSource(getActivity());
		    datasource.open();
		    SharedPreferences prefs = AppManager.getInstance().getPrefs(getActivity());
			String token = prefs.getString("token", null);
		    offlineCustomers = datasource.getOfflineCustomeData(token);
		    datasource.close();
		    
		    if(offlineCustomers!=null)
			{
		    	Set<String> keys = offlineCustomers.keySet();
			    String[] arr=new String[keys.size()];
			    keys.toArray(arr);
			    return arr;
			}
			return null;
		}
		@Override
		protected void onPostExecute(String[] result) 
		{
			super.onPostExecute(result);
			if(result!=null)
			{
		    	if(result.length>0)
				{
					AppManager.getInstance().showSelectionAlertDialog(getActivity(), uiHandler, FLAG_SELECT_CUSTOMER, result);
					flag=true;
				}
			}
			if(!flag)
			{
				Toast.makeText(getActivity(), getString(R.string.offline_customer_mess), Toast.LENGTH_SHORT).show();
			}
			progressDialog.dismiss();
		}
	}
	private void showEditDialog(){	
		AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
				getActivity());
		alertDialogBuilder.setTitle(getString(R.string.confirm));
		alertDialogBuilder
				.setMessage(getString(R.string.customer_visit_updated))
				.setCancelable(false)
				.setPositiveButton(
						getString(R.string.OK),
						new DialogInterface.OnClickListener() {
							public void onClick(
									DialogInterface dialog,
									int id) {
								
								getActivity().getSupportFragmentManager().popBackStack();
								dialog.cancel();
							}
						});
			
		AlertDialog alertDialog = alertDialogBuilder
				.create();
		alertDialog.show();
	}
}
