package com.smalution.y3distributiongh1.fragments.payments;

import com.smalution.y3distributiongh1.AppManager;
import com.smalution.y3distributiongh1.R;
import com.smalution.y3distributiongh1.SendDataToServerAsyncTask;
import com.smalution.y3distributiongh1.Utils;
import com.smalution.y3distributiongh1.database.MySQLiteHelper;
import com.smalution.y3distributiongh1.database.Y3Query;
import com.smalution.y3distributiongh1.database.Y3QueryDataSource;
import com.smalution.y3distributiongh1.entities.customer.Customer;
import com.smalution.y3distributiongh1.entities.payments.Payments;
import com.smalution.y3distributiongh1.fragments.SuperFragment;
import com.smalution.y3distributiongh1.quickaction.ActionItem;
import com.smalution.y3distributiongh1.quickaction.QuickAction;
import com.smalution.y3distributiongh1.utils.AppConstant;

import java.io.File;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;

import org.json.JSONException;
import org.json.JSONObject;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.DataSetObserver;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.androidquery.AQuery;

public class PaymentsDisplayFragment extends SuperFragment 
{
	ListView customerList;
	ArrayAdapter<Payments> adapter;
	ArrayList<Payments> paymentArrayList=new ArrayList<Payments>();
	View rootView;
	AQuery aq; 
	int pageCount=0;
	View foolterLoadMoreView;
	AQuery aqf;
	@Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,Bundle savedInstanceState) 
	{
        rootView = inflater.inflate(R.layout.payments_display_fragment, container, false);
        aq=new AQuery(rootView);
        pageCount=0;
        paymentArrayList.clear();
        initUI(true);
        initApplication();
        
        return rootView;
    }
	private void initApplication() {
		AppConstant. JSONGSTRING=null;
		AppConstant.DELETE_ID=null;
		AppConstant. LOADFILLLISTVIEW=false;		
		AppConstant. OPTION_MODE=null;
		if(AppManager.isOnline(getActivity())){
			//new DeletePaymentfromServer().execute();
			new PaymentsListAsyncTask(aq).execute();
			
			
		} else {
				paymentArrayList.clear();		
				fillLIstView();

	}

		
	}
	
	private void fillLIstView() {
		Y3QueryDataSource datasource = new Y3QueryDataSource(getActivity());
		datasource.open();
		// pageCount = 1;
		paymentArrayList.clear();
		ArrayList<Payments> result = datasource.getAllPayemtQueries();

		if (result.size() > 0) {
			paymentArrayList.addAll(result);

		}
		initUI(false);
		
	}
	
	
	
	
	private void initUI(boolean addHeader) 
	{
		aq.id(R.id.buttonRefresh).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				if(AppManager.isOnline(getActivity())){
				 pageCount=0;
		        paymentArrayList.clear();
		        initUI(false);
		        new PaymentsListAsyncTask(aq).execute();
			}
			}
		});
		aq.id(R.id.buttonAddNewPayment).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				FragmentManager fragmentManager=getActivity().getSupportFragmentManager();
				FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
				Fragment fragment = fragmentManager.findFragmentByTag("PaymentsAddFragment");
				Bundle bundle=new Bundle();
				if(fragment==null)
				{
					fragment=new PaymentsAddFragment();
					fragment.setArguments(bundle);
					fragmentTransaction.addToBackStack("PaymentsAddFragment");
				}
				else
				{
					((PaymentsAddFragment)fragment).setUIArguments(bundle);
				}
				fragmentTransaction.replace(R.id.frame_container, fragment, "PaymentsAddFragment");
				fragmentTransaction.commit();
			}
		});
		SharedPreferences prefs = AppManager.getInstance().getPrefs(aq.getContext());
		int grade = prefs.getInt("grade", -1);
		if(grade!=-1 && grade==2)
		{
			aq.id(R.id.buttonAddNewPayment).invisible();
		}
		adapter = new ArrayAdapter<Payments>(this.getActivity(), R.layout.payments_display_listitem, paymentArrayList)
		{
			public View getView(int position, View convertView, ViewGroup parent) 
	        {
	            if(convertView == null)
	            {
                     convertView = getActivity().getLayoutInflater().inflate(R.layout.payments_display_listitem, parent, false);
	            }
                final Payments payment = getItem(position);
                AQuery aql = new AQuery(convertView);
                position=position+1;
                aql.id(R.id.textViewSerialNo).text(""+position);
                aql.id(R.id.textViewUser).text(payment.getUser().getFirst_name()+" "+payment.getUser().getLast_name());
                aql.id(R.id.textViewPaymentDate).text(payment.getPayment().getPayment_date());
                aql.id(R.id.textViewAmount).text(payment.getPayment().getAmount());
                final int pos=position;
                aql.id(R.id.quickActionParent1).clicked(new OnClickListener() 
                {
					@Override
					public void onClick(View v) 
					{
						showQuickActionPopup(v, payment,pos);
					}
				});
	            return convertView;
	        }
		};
		if(pageCount==0 && addHeader)
		{
			foolterLoadMoreView=LayoutInflater.from(getActivity()).inflate(R.layout.load_more_list_footer, null);
			aqf=new AQuery(foolterLoadMoreView);
			aqf.id(R.id.buttonLoadMoreListItems).clicked(new OnClickListener() 
			{
				@Override
				public void onClick(View v) 
				{
					if(AppManager.isOnline(getActivity()))
						
					{
					new PaymentsListAsyncTask(aq).execute();
					}
				}
			});
		aq.id(R.id.customerList).getListView().addFooterView(foolterLoadMoreView, null, true);
		}
		aq.id(R.id.customerList).getListView().setTranscriptMode(AbsListView.TRANSCRIPT_MODE_ALWAYS_SCROLL);
		aq.id(R.id.customerList).adapter(adapter);
		adapter.registerDataSetObserver(new DataSetObserver() 
		{
		    @Override
		    public void onChanged() 
		    {
		        super.onChanged();
		        if(pageCount==1)
		        {
		        	aq.id(R.id.customerList).getListView().setSelection(0);
		        }
		        else
		        {
		        	aq.id(R.id.customerList).getListView().setSelection(adapter.getCount() - 1);
		        }    
		    }
		});
	}
	private void showQuickActionPopup(View anchorView, final Payments payment,final int position)
	{
		
		ActionItem viewAction = new ActionItem();
		viewAction.setTitle(getString(R.string.view));
		viewAction.setIcon(getResources().getDrawable(R.drawable.icon_view));
		final QuickAction mQuickAction = new QuickAction(getActivity());
		mQuickAction.addActionItem(viewAction);
		ActionItem addAction = new ActionItem();
		SharedPreferences prefs = AppManager.getInstance().getPrefs(aq.getContext());
		int grade = prefs.getInt("grade", -1);
		if(grade!=-1 && grade!=2)
		{
			
			addAction.setTitle(getString(R.string.edit));
			addAction.setIcon(getResources().getDrawable(R.drawable.icon_edit));
		}
			// Upload action item
			ActionItem deleteAction = new ActionItem();
			SharedPreferences prefss = AppManager.getInstance().getPrefs(aq.getContext());
			int grades = prefss.getInt("grade", -1);
			if(grades!=-1 && (grades==1 || grades==3))
			{
			deleteAction.setTitle(getString(R.string.delete));
			deleteAction.setIcon(getResources().getDrawable(R.drawable.icon_delete));
			}
			mQuickAction.addActionItem(addAction);
			mQuickAction.addActionItem(deleteAction);
		
		
		mQuickAction.setOnActionItemClickListener(new QuickAction.OnActionItemClickListener() 
		{
			public void onItemClick(int pos) 
			{
				if (pos == 0) 
				{ 
					FragmentManager fragmentManager=getActivity().getSupportFragmentManager();
					FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
					Fragment fragment = fragmentManager.findFragmentByTag("PaymentsViewFragment");
					Bundle bundle=new Bundle();
					bundle.putParcelable("PAYMENT", payment);
					if(fragment==null)
					{
						fragment=new PaymentsViewFragment();
						fragment.setArguments(bundle);
						fragmentTransaction.addToBackStack("PaymentsViewFragment");
					}
					else
					{
						((PaymentsViewFragment)fragment).setUIArguments(bundle);
					}
					fragmentTransaction.replace(R.id.frame_container, fragment, "PaymentsViewFragment");
					fragmentTransaction.commit();
				} 
				else if (pos == 1) 
				{ 
					FragmentManager fragmentManager=getActivity().getSupportFragmentManager();
					FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
					Fragment fragment = fragmentManager.findFragmentByTag("PaymentsEditFragment");
					Bundle bundle=new Bundle();
					bundle.putParcelable("PAYMENT", payment);
					if(fragment==null)
					{
						fragment=new PaymentsEditFragment();
						fragment.setArguments(bundle);
						fragmentTransaction.addToBackStack("PaymentsEditFragment");
					}
					else
					{
						((PaymentsEditFragment)fragment).setUIArguments(bundle);
					}
					fragmentTransaction.replace(R.id.frame_container, fragment, "PaymentsEditFragment");
					fragmentTransaction.commit();
				} 
				else if (pos == 2) 
				{ 
					SharedPreferences prefs = AppManager.getInstance().getPrefs(aq.getContext());
					String token = prefs.getString("token", null);
				  final  String jsonString="{\"token\":\""+token+"\",\"payment_id\":\""+payment.getPayment().getId()+"\"}";
				    
				   // AppConstant.JSONGSTRING=jsonString;
				    AppConstant.DELETE_ID=payment.getPayment().getId();
				    AppConstant.OPTION_MODE="PAYMENT";
				    
				    if (AppManager.isOnline(getActivity())) {
				    	//int deleteposition= position-1;
				    	
				    	 SendDataToServerAsyncTask<Payments> deletor = new SendDataToServerAsyncTask<Payments>(
						    		getActivity(), 
						    		jsonString,
						    		null, 
						    		AppManager.getInstance().URL_DELETE_PAYMENTS,
						    		getString(R.string.payment_deleted),
						    		false,
						    		adapter,
						    		paymentArrayList,
						    		position,"");//.execute();
						    AppManager.getInstance().showDeleteConfDialog(getActivity(),deletor);
				    	
				    }else{
				    	
				    	
				    	AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
								getActivity());
						alertDialogBuilder.setTitle(getString(R.string.warning));
						alertDialogBuilder
								.setMessage(getString(R.string.payment_deleted))
								.setCancelable(false)
								.setPositiveButton(
										getString(R.string.yes),
										new DialogInterface.OnClickListener() {
											public void onClick(
													DialogInterface dialog,
													int id) {
												Y3QueryDataSource datasource = new Y3QueryDataSource(getActivity());
												datasource.open();
												
												long result = datasource.addY3Query(Y3QueryDataSource.ACTION_PAYMENT_DELETE,jsonString,null);									 
												if (result != -1) {
													if (datasource.deletePaymentSingleRow(payment.getPayment().getId()))
													{
														AppConstant.LOADFILLLISTVIEW=true;
														Toast.makeText(getActivity(), getString(R.string.payment_deleted),Toast.LENGTH_SHORT).show();														
														paymentArrayList.clear();
														fillLIstView();
													}
												}					
												
												datasource.close();

											}
										})
								.setNegativeButton(
										getString(R.string.no),
										new DialogInterface.OnClickListener() {
											public void onClick(
													DialogInterface dialog,
													int id) {
												dialog.cancel();
											}
										});
						AlertDialog alertDialog = alertDialogBuilder
								.create();
						alertDialog.show(); 		
				    	
				    	
				    }
				    
				   
				   
				    
				} 
			}
		});
		mQuickAction.show(anchorView);
		mQuickAction.setAnimStyle(QuickAction.ANIM_GROW_FROM_CENTER);
	}
	private class PaymentsListAsyncTask extends AsyncTask<Void, Void, ArrayList<Payments>>
	{
		AQuery aq;
		ProgressDialog progressDialog;
		public PaymentsListAsyncTask(AQuery aq)
		{
			this.aq=aq;
			pageCount=pageCount+1;
		}
		@Override
		protected void onPreExecute() 
		{
			super.onPreExecute();
			if(getActivity()==null){
				progressDialog = new ProgressDialog(aq.getContext());
			}
			else{
				progressDialog = new ProgressDialog(getActivity());
			}
			progressDialog.setMessage(getString(R.string.wait_progress));
	        progressDialog.setCancelable(false);
	        progressDialog.setIndeterminate(true);
	        progressDialog.show();
	        progressDialog.setOnKeyListener(new DialogInterface.OnKeyListener() 
	        {
	            @Override
	            public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) 
	            {
	                return false;
	            }
	        });
		}
		@Override
		protected ArrayList<Payments> doInBackground(Void... params) 
		{
			if(AppManager.getInstance().isOnline(aq.getContext()))
			{
				return AppManager.getInstance().getPaymentsList(aq, pageCount);
			}
			return null;
		}
		@Override
		protected void onPostExecute(ArrayList<Payments> result) 
		{
			super.onPostExecute(result);
			if(result!=null && adapter!=null)
			{
				if(result.size()>0)
				{
					paymentArrayList.addAll(result);
					adapter.notifyDataSetChanged();
					aqf.id(R.id.buttonLoadMoreListItems).visible();
					if(result.size()<20)
					{
						aqf.id(R.id.buttonLoadMoreListItems).invisible();
					}
				}
				else
				{
					if(pageCount==1)
					{
						Toast.makeText(getActivity(), getString(R.string.no_data), Toast.LENGTH_SHORT).show();
					}
					adapter.notifyDataSetChanged();
					aqf.id(R.id.buttonLoadMoreListItems).invisible();
				}
			}
			else
			{
				Toast.makeText(aq.getContext(), getString(R.string.no_data), Toast.LENGTH_SHORT).show();
			}
			
			progressDialog.dismiss();
		}
	}

	
	
	
}
