package com.smalution.y3distributionng2.fragments.customer;

import com.smalution.y3distributionng2.AppManager;
import com.smalution.y3distributionng2.R;
import com.smalution.y3distributionng2.Utils;
import com.smalution.y3distributionng2.database.Y3QueryDataSource;
import com.smalution.y3distributionng2.entities.customer.Customer;
import com.smalution.y3distributionng2.fragments.SuperFragment;
import com.smalution.y3distributionng2.quickaction.ActionItem;
import com.smalution.y3distributionng2.quickaction.QuickAction;


import java.io.File;
import java.util.ArrayList;
import java.util.Hashtable;
import org.json.JSONObject;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.database.DataSetObserver;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.androidquery.AQuery;

public class CustomerDisplayFragment extends SuperFragment {
	ListView customerList;
	ArrayAdapter<Customer> adapter;
	ArrayList<Customer> customerArrayList = new ArrayList<Customer>();

	View rootView;
	AQuery aq;
	int pageCount = 0;
	View foolterLoadMoreView;
	AQuery aqf;
	private String deleteIdForSqlite;	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,Bundle savedInstanceState) {
		rootView = inflater.inflate(R.layout.customer_display_fragment,container, false);
		aq = new AQuery(rootView);
		pageCount = 0;
		
		customerArrayList.clear();
		initUI(true);
		intiApplication();
		return rootView;
	}

	private void initUI(boolean addFooter) {
		aq.id(R.id.buttonRefresh).clicked(new OnClickListener() {
			@Override
			public void onClick(View v) {
				if(AppManager.isOnline(getActivity())){
				pageCount = 0;
				customerArrayList.clear();
				initUI(false);
				new CustomersListAsyncTask(aq).execute();
				}
				
			}
		});
		aq.id(R.id.buttonAddNewCustomer).clicked(new OnClickListener() {
			@Override
			public void onClick(View v) {
				FragmentManager fragmentManager = getActivity()	.getSupportFragmentManager();
				FragmentTransaction fragmentTransaction = fragmentManager
						.beginTransaction();
				Fragment fragment = fragmentManager
						.findFragmentByTag("CustomerAddFragment");
				Bundle bundle = new Bundle();
				// bundle.putParcelable("CUSTOMER", customer);
				if (fragment == null) {
					fragment = new CustomerAddFragment();
					fragment.setArguments(bundle);
					fragmentTransaction.addToBackStack("CustomerAddFragment");
				} else {
					((CustomerAddFragment) fragment).setUIArguments(bundle);
				}
				fragmentTransaction.replace(R.id.frame_container, fragment,"CustomerAddFragment");
				fragmentTransaction.addToBackStack(null);
				fragmentTransaction.commit();
			}
		});
		adapter = new ArrayAdapter<Customer>(this.getActivity(),
				R.layout.customer_display_listitem, customerArrayList) {
			public View getView(int position, View convertView, ViewGroup parent) {
				if (convertView == null) {
					convertView = getActivity().getLayoutInflater().inflate(
							R.layout.customer_display_listitem, parent, false);
				}
				//System.out.println("POSITION"+position);
				final Customer customer = getItem(position);
				AQuery aql = new AQuery(convertView);
				position=position+1;
				aql.id(R.id.textViewSerialNo).text("" + position);
				if (customer.getCustomer().getImage_path() != null&& customer.getCustomer().getImage_path().length() > 0) {
					aql.id(R.id.imageViewCustomerPhoto).image(customer.getCustomer().getImage_path(),
							true,
							true,
							aql.id(R.id.imageViewCustomerPhoto).getImageView().getWidth(), 0);
				}

				aql.id(R.id.textViewFirstName).text(
						customer.getCustomer().getFirst_name());
				aql.id(R.id.textViewLastName).text(
						customer.getCustomer().getLast_name());
				aql.id(R.id.textViewEmail).text(
						customer.getCustomer().getPhone());
				
				
				final int pos = position;
				aql.id(R.id.quickActionParent).clicked(new OnClickListener() {
					@Override
					public void onClick(View v) {
						showQuickActionPopup(v, customer, pos);
					}
				});
				
				

				return convertView;
			}
		};
		if (pageCount == 0 && addFooter) {
			foolterLoadMoreView = LayoutInflater.from(getActivity()).inflate(R.layout.load_more_list_footer, null);
			aqf = new AQuery(foolterLoadMoreView);
			
			aqf.id(R.id.buttonLoadMoreListItems).clicked(new OnClickListener() {
				@Override
				public void onClick(View v) {
					if(AppManager.isOnline(getActivity()))
					
					{
						//customerArrayList.clear();
						new CustomersListAsyncTask(aq).execute();
					}
				}
			});
			aq.id(R.id.customerList).getListView().addFooterView(foolterLoadMoreView, null, true);
		}

		aq.id(R.id.customerList).getListView()
				.setTranscriptMode(AbsListView.TRANSCRIPT_MODE_ALWAYS_SCROLL);
		aq.id(R.id.customerList).adapter(adapter);
		adapter.registerDataSetObserver(new DataSetObserver() {
			@Override
			public void onChanged() {
				super.onChanged();
				if (pageCount == 1) {
					aq.id(R.id.customerList).getListView().setSelection(0);
				} else {
					aq.id(R.id.customerList).getListView()
							.setSelection(adapter.getCount() - 1);
				}
			}
		});
	}

	private void showQuickActionPopup(View anchorView, final Customer customer,
			final int position) {
		ActionItem viewAction = new ActionItem();
		viewAction.setTitle(getString(R.string.view));
		viewAction.setIcon(getResources().getDrawable(R.drawable.icon_view));

		ActionItem editAction = new ActionItem();
		editAction.setTitle(getString(R.string.edit));
		editAction.setIcon(getResources().getDrawable(R.drawable.icon_edit));

		// Upload action item
		ActionItem deleteAction = new ActionItem();
		SharedPreferences prefs = AppManager.getInstance().getPrefs(aq.getContext());
		int grade = prefs.getInt("grade", -1);
		if(grade!=-1 && (grade==1 || grade==3))
		{
		deleteAction.setTitle(getString(R.string.delete));
		deleteAction.setIcon(getResources().getDrawable(R.drawable.icon_delete));
		}
		final QuickAction mQuickAction = new QuickAction(getActivity());

		mQuickAction.addActionItem(viewAction);
		mQuickAction.addActionItem(editAction);
		mQuickAction.addActionItem(deleteAction);
		mQuickAction
				.setOnActionItemClickListener(new QuickAction.OnActionItemClickListener() {
					public void onItemClick(int pos) {
						if (pos == 0) {
							FragmentManager fragmentManager = getActivity()
									.getSupportFragmentManager();
							FragmentTransaction fragmentTransaction = fragmentManager
									.beginTransaction();
							Fragment fragment = fragmentManager
									.findFragmentByTag("CustomerViewFragment");
							Bundle bundle = new Bundle();
							bundle.putParcelable("CUSTOMER", customer);
							if (fragment == null) {
								fragment = new CustomerViewFragment();
								fragment.setArguments(bundle);
								fragmentTransaction
										.addToBackStack("CustomerViewFragment");
							} else {
								((CustomerViewFragment) fragment)
										.setUIArguments(bundle);
							}
							fragmentTransaction.replace(R.id.frame_container,
									fragment, "CustomerViewFragment");
							fragmentTransaction.commit();
						} else if (pos == 1) {
							FragmentManager fragmentManager = getActivity()
									.getSupportFragmentManager();
							FragmentTransaction fragmentTransaction = fragmentManager
									.beginTransaction();
							Fragment fragment = fragmentManager
									.findFragmentByTag("CustomerEditFragment");
							Bundle bundle = new Bundle();
							bundle.putParcelable("CUSTOMER", customer);
							if (fragment == null) {
								fragment = new CustomerEditFragment();
								fragment.setArguments(bundle);
								fragmentTransaction
										.addToBackStack("CustomerEditFragment");
							} else {
								((CustomerEditFragment) fragment)
										.setUIArguments(bundle);
							}
							fragmentTransaction.replace(R.id.frame_container,
									fragment, "CustomerEditFragment");
							fragmentTransaction.commit();
						}
						// this is for delete customer data.
						else if (pos == 2) {
							SharedPreferences prefs = AppManager.getInstance()
									.getPrefs(aq.getContext());
							String token = prefs.getString("token", null);
							final String jsonString = "{\"token\":\"" + token
									+ "\",\"customer_id\":\""
									+ customer.getCustomer().getId() + "\"}";

							if (AppManager.isOnline(getActivity())) {

								AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
										getActivity());
								alertDialogBuilder.setTitle(getString(R.string.warning));
								alertDialogBuilder
										.setMessage(getString(R.string.confirm_delete))
										.setCancelable(false)
										.setPositiveButton(
												"Yes",
												new DialogInterface.OnClickListener() {
													public void onClick(
															DialogInterface dialog,
															int id) {
														
														
														
														deleteIdForSqlite=customer.getCustomer().getId();
														new SendDataToServerAsyncTask<Customer>(
																getActivity(),
																jsonString,
																null,
																AppManager
																		.getInstance().URL_DELETE_CUSTOMER,
																getString(R.string.customer_deleted),
																false,
																adapter,
																customerArrayList,
																position)
																.execute();

													}
												})
										.setNegativeButton(
												getString(R.string.no),
												new DialogInterface.OnClickListener() {
													public void onClick(
															DialogInterface dialog,
															int id) {
														dialog.cancel();
													}
												});
								AlertDialog alertDialog = alertDialogBuilder
										.create();
								alertDialog.show();
								

							} else {

								AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
										getActivity());
								alertDialogBuilder.setTitle(getString(R.string.warning));
								alertDialogBuilder
										.setMessage(getString(R.string.confirm_delete))
										.setCancelable(false)
										.setPositiveButton(
												getString(R.string.yes),
												new DialogInterface.OnClickListener() {
													public void onClick(
															DialogInterface dialog,
															int id) {
														Y3QueryDataSource datasource = new Y3QueryDataSource(
																getActivity());
														datasource.open();
														long result = datasource
																.addY3Query(
																		Y3QueryDataSource.ACTION_CUSTOMER_DELETE,
																		jsonString,
																		null);
														 
														if (result != -1) {
															if (datasource
																	.deleteCustomerData(customer.getCustomer().getId()))
																
															{
																Toast.makeText(
																		getActivity(),
																		getString(R.string.customer_deleted),
																		Toast.LENGTH_SHORT)
																		.show();
																customerArrayList
																		.clear();
																fillLIstView();
															}
														}
														datasource.close();

													}
												})
										.setNegativeButton(
												getString(R.string.no),
												new DialogInterface.OnClickListener() {
													public void onClick(
															DialogInterface dialog,
															int id) {
														dialog.cancel();
													}
												});
								AlertDialog alertDialog = alertDialogBuilder
										.create();
								alertDialog.show();

							}
						}
					}
				});
		mQuickAction.show(anchorView);
		mQuickAction.setAnimStyle(QuickAction.ANIM_GROW_FROM_CENTER);
	}

	private class CustomersListAsyncTask extends
			AsyncTask<Void, Void, ArrayList<Customer>> {
		AQuery aq;

		public CustomersListAsyncTask(AQuery aq) 
		{
			this.aq = aq;
			pageCount = pageCount + 1;
			
		}

		ProgressDialog progressDialog;

		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			if(getActivity()==null){
				progressDialog = new ProgressDialog(aq.getContext());
			}
			else{
				progressDialog = new ProgressDialog(getActivity());
			}
			progressDialog.setMessage(getString(R.string.wait_progress));
			progressDialog.setCancelable(false);
			progressDialog.setIndeterminate(true);
			progressDialog.show();
			progressDialog
					.setOnKeyListener(new DialogInterface.OnKeyListener() {
						@Override
						public boolean onKey(DialogInterface dialog,
								int keyCode, KeyEvent event) {
							return false;
						}
					});
		}

		@Override
		protected ArrayList<Customer> doInBackground(Void... params) {
			if (AppManager.getInstance().isOnline(aq.getContext())) {
				//System.out.println("The page count"+pageCount);
				return AppManager.getInstance().getCustomerList(aq, pageCount);
			}
			return null;
		}

		@Override
		protected void onPostExecute(ArrayList<Customer> result) {
			super.onPostExecute(result);
			progressDialog.dismiss();
			
			if (result != null && adapter != null) {
				if (result.size() > 0) {
					customerArrayList.addAll(result);					
					adapter.notifyDataSetChanged();
					//aqf.id(R.id.buttonLoadMoreListItems).invisible();
					if (result.size() < 20) {
						aqf.id(R.id.buttonLoadMoreListItems).invisible();
					}
					} else {
					if (pageCount == 1) {
						Toast.makeText(getActivity(), getString(R.string.no_data),
								Toast.LENGTH_SHORT).show();
					}
					adapter.notifyDataSetChanged();
					aqf.id(R.id.buttonLoadMoreListItems).invisible();
				}
			} else {
				Toast.makeText(aq.getContext(), getString(R.string.network_not_available),Toast.LENGTH_SHORT).show();
			}
			
		}
	}

	private class DeleteCustomerfromServer extends
			AsyncTask<Void, Void, ArrayList<Customer>> {	

		ProgressDialog progressDialog;
		@Override
		protected void onPreExecute() {
			
			progressDialog = new ProgressDialog(getActivity());
			progressDialog.setMessage(getString(R.string.wait_progress));
			progressDialog.setCancelable(false);
			progressDialog.setIndeterminate(true);
			progressDialog.show();
			progressDialog
					.setOnKeyListener(new DialogInterface.OnKeyListener() {
						@Override
						public boolean onKey(DialogInterface dialog,
								int keyCode, KeyEvent event) {
							return false;
						}
					});
		}

		@Override
		protected ArrayList<Customer> doInBackground(Void... params) {

			// this is for add customer 
			//------------------------------------
			
			

			return null;
		}

		@Override
		protected void onPostExecute(ArrayList<Customer> result) {
			progressDialog.dismiss();
			
		}
	}

	
	private void fillLIstView() {
		
		Y3QueryDataSource datasource = new Y3QueryDataSource(aq.getContext());
		datasource.open();
		// pageCount = 1;
		customerArrayList.clear();
		ArrayList<Customer> result = datasource.getAllCustomerQueries();

		if (result.size() > 0) {
			customerArrayList.addAll(result);

		}
		datasource.close();
		initUI(false);
	}

	private void intiApplication() {

		if (AppManager.isOnline(getActivity())) {
			// this is for online operation...... in application.
			//new DeleteCustomerfromServer().execute();
			new CustomersListAsyncTask(aq).execute();	
						
			

		} else {
			customerArrayList.clear();
			
			fillLIstView();

		}
	}

	public class SendDataToServerAsyncTask<T> extends
			AsyncTask<Void, Void, Integer> {
		FragmentActivity context;
		String jsonStr;
		String imagePath;
		String url;
		String successMessage;
		boolean isPopFragment;
		ArrayAdapter<T> adapter;
		ArrayList<T> list;
		int position;

		public SendDataToServerAsyncTask(FragmentActivity context,
				String jsonStr, String imagePath, String url,
				String successMessage, boolean isPopFragment,
				ArrayAdapter<T> adapter, ArrayList<T> list, int position) {
			this.context = context;
			this.jsonStr = jsonStr;
			this.imagePath = imagePath;
			this.url = url;
			this.successMessage = successMessage;
			this.isPopFragment = isPopFragment;
			this.adapter = adapter;
			this.list = list;
			this.position = position;
		}

		ProgressDialog progressDialog;

		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			progressDialog = new ProgressDialog(context);
			progressDialog
					.setMessage(context.getString(R.string.wait_progress));
			progressDialog.setCancelable(false);
			progressDialog.setIndeterminate(true);
			progressDialog.show();
			progressDialog
					.setOnKeyListener(new DialogInterface.OnKeyListener() {
						@Override
						public boolean onKey(DialogInterface dialog,
								int keyCode, KeyEvent event) {
							return false;
						}
					});
		}

		@Override
		protected Integer doInBackground(Void... params) {
			try {
				
				if (AppManager.getInstance().isOnline(context)) {
					Hashtable<String, String> parameters = new Hashtable<String, String>();
					parameters.put("jsonString", jsonStr);
					Hashtable<String, File> fileParams = null;
					if (imagePath != null && imagePath.length() > 0
							&& new File(imagePath).exists()) {
						fileParams = new Hashtable<String, File>();
						fileParams.put("image", new File(imagePath));
					}
					String response = Utils.post(context, url, parameters,
							fileParams);
					Log.d("MTK", "server response: " + response);
					if (response != null) {
						int error = new JSONObject(response).getInt("error");
						if (error == 0) {
							Y3QueryDataSource datasource = new Y3QueryDataSource(
									getActivity());
							datasource.open();
							datasource.deleteCustomerData(deleteIdForSqlite);
							datasource.close();
							return 0;
						} else if (error == 3)// invalid token
						{
							return 3;
						} else {
							return 2;
						}
					}
				} else {
					return 1;
				}
			} catch (Exception ex) {
				ex.printStackTrace();
			}
			return 2;
		}

		@Override
		protected void onPostExecute(Integer result) {
			super.onPostExecute(result);
			
			position=position-1;
			if (result == 0) {
				Toast.makeText(context, successMessage, Toast.LENGTH_SHORT)
						.show();
				//getData();
			if (isPopFragment)
		      context.getSupportFragmentManager().popBackStack();
		   if (adapter != null) {
			adapter.notifyDataSetChanged();
			list.remove(position);
			}
			} else if (result == 1)// network not available
			{
				Toast.makeText(context, getString(R.string.network_not_available),
						Toast.LENGTH_SHORT).show();
			} else if (result == 2)// server error
			{
				Toast.makeText(context,
						getString(R.string.something_wrong),
						Toast.LENGTH_SHORT).show();
			} else if (result == 3)// invalid token
			{
				Toast.makeText(context,
						getString(R.string.login_expire),
						Toast.LENGTH_LONG).show();
			}
			progressDialog.dismiss();
			
		}
	}



}
