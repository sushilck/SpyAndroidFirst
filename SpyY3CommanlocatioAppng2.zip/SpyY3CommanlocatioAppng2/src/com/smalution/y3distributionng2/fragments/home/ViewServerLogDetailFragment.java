package com.smalution.y3distributionng2.fragments.home;

import com.smalution.y3distributionng2.R;
import com.smalution.y3distributionng2.database.ServerLog;
import com.smalution.y3distributionng2.database.Y3QueryDataSource;
import com.smalution.y3distributionng2.fragments.SuperFragment;

import java.io.File;
import java.util.Hashtable;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Toast;

import com.androidquery.AQuery;



public class ViewServerLogDetailFragment extends SuperFragment 
{
	ServerLog log;
	AQuery aq;
	public void setUIArguments(final Bundle args) 
	{
	    getActivity().runOnUiThread(new Runnable() 
	    {
	        public void run() 
	        {
	        	log= args.getParcelable("LOG");
	        }
	    });
	}
	@Override
	public void onCreate(Bundle savedInstanceState) 
	{
		super.onCreate(savedInstanceState);
		log = getArguments().getParcelable("LOG");
	}
	@Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,Bundle savedInstanceState) 
	{
        View rootView = inflater.inflate(R.layout.view_server_log_detail_fragment, container, false);
        aq=new AQuery(rootView);
        initUI();
        return rootView;
    }
	private void initUI()
	{
		aq.id(R.id.TextView_ID).text(""+log.get_id());
		aq.id(R.id.TextView_action).text(log.getAction());
		aq.id(R.id.TextView_RequestData).text(log.getJson());
		aq.id(R.id.TextView_Status).text(log.getStatus());
		aq.id(R.id.TextView_ServerLog).text(log.getServerlog());
		aq.id(R.id.TextView_ServerLogDetail).text(log.getServerlogdetail());
		aq.id(R.id.deleteQuery).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				Y3QueryDataSource datasource = new Y3QueryDataSource(getActivity());
			    datasource.open();
				boolean isQueryDeleted = datasource.deleteY3Query(log.get_id());
			    datasource.close();
				Log.d("MTK","isQueryDeleted:"+isQueryDeleted);
				Toast.makeText(getActivity(), R.string.confirm_query_remove, Toast.LENGTH_SHORT).show();
				getActivity().getSupportFragmentManager().popBackStack();
			}
		});
	}
}
