package com.smalution.y3distributionburf1.fragments.incentive;

import com.smalution.y3distributionburf1.R;
import com.smalution.y3distributionburf1.entities.incentive.IncentiveItem;
import com.smalution.y3distributionburf1.fragments.SuperFragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.androidquery.AQuery;

public class IncentiveViewFragment extends SuperFragment {
	
	IncentiveItem incentiveItem;
	View rootView;
	AQuery aq; 
	public void setUIArguments(final Bundle args) 
	{
	    getActivity().runOnUiThread(new Runnable() 
	    {
	        public void run() 
	        {
	        	incentiveItem = args.getParcelable("PAYMENT");
	        }
	    });
	}
	@Override
	public void onCreate(Bundle savedInstanceState) 
	{
		super.onCreate(savedInstanceState);
		incentiveItem = getArguments().getParcelable("PAYMENT");
	}
	@Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,Bundle savedInstanceState) 
	{
        rootView = inflater.inflate(R.layout.incentive_view_fragment, container, false);
        aq=new AQuery(rootView);
        initUI();
        return rootView;
    }
	private void initUI() 
	{
		aq.id(R.id.textViewCustomer).text(incentiveItem.getCustomer().getFname()+" "+incentiveItem.getCustomer().getLname());
		aq.id(R.id.textViewBrand).text(incentiveItem.getBrand().getName());
		aq.id(R.id.textViewDepot).text(incentiveItem.getDepot().getTitle());
		aq.id(R.id.textViewIncentiveType).text(incentiveItem.getIncentive().getIncentive_type());
		aq.id(R.id.textViewDateOfIncentive).text(incentiveItem.getIncentive().getIncentive_date());
		aq.id(R.id.textViewUnit).text(incentiveItem.getIncentive().getUnit());
		aq.id(R.id.textViewQuantity).text(incentiveItem.getIncentive().getQuantity());
		aq.id(R.id.textViewCreated).text(incentiveItem.getIncentive().getCreated());
		aq.id(R.id.textViewCreatedDate).text(incentiveItem.getIncentive().getCreated());
		aq.id(R.id.textViewSynchronizationData).text(incentiveItem.getIncentive().getModified());
		
	}
}
