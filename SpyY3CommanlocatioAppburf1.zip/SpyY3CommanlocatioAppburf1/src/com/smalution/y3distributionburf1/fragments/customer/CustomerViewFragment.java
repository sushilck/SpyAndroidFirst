package com.smalution.y3distributionburf1.fragments.customer;

import com.smalution.y3distributionburf1.AppManager;
import com.smalution.y3distributionburf1.R;
import com.smalution.y3distributionburf1.entities.customer.Customer;
import com.smalution.y3distributionburf1.entities.settings.Routes;
import com.smalution.y3distributionburf1.fragments.SuperFragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.androidquery.AQuery;

public class CustomerViewFragment extends SuperFragment 
{
	Customer customer;
	View rootView;
	AQuery aq; 
	public void setUIArguments(final Bundle args) 
	{
	    getActivity().runOnUiThread(new Runnable() 
	    {
	        public void run() 
	        {
	        	customer = args.getParcelable("CUSTOMER");
	        }
	    });
	}
	@Override
	public void onCreate(Bundle savedInstanceState) 
	{
		super.onCreate(savedInstanceState);
		customer = getArguments().getParcelable("CUSTOMER");
	}
	@Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,Bundle savedInstanceState) 
	{
        rootView = inflater.inflate(R.layout.customer_view_fragment, container, false);
        aq=new AQuery(rootView);
        initUI();
        return rootView;
    }
	private void initUI() 
	{
		if(customer.getCustomer().getImage_path()!=null && customer.getCustomer().getImage_path().length()>0)
		{
			aq.id(R.id.imageViewUserPhoto).image(customer.getCustomer().getImage_path(), true, true, aq.id(R.id.imageViewUserPhoto).getImageView().getWidth(), 0);
		}
		aq.id(R.id.textViewName).text(customer.getCustomer().getFirst_name()+" "+customer.getCustomer().getLast_name());
		aq.id(R.id.textViewAddress).text(customer.getCustomer().getAddress()+", "+customer.getCustomer().getCity()+", "+customer.getState().getState());
		aq.id(R.id.textViewEmail).text(customer.getCustomer().getEmail());
		aq.id(R.id.textViewPhone).text(customer.getCustomer().getPhone());
		aq.id(R.id.textViewRegion).text(customer.getRegion().getTitle());
		aq.id(R.id.textViewDepot).text(customer.getDepot().getTitle());
		aq.id(R.id.textViewCreatedDate).text(customer.getCustomer().getCreated());
		aq.id(R.id.textViewSynchronizationData).text(customer.getCustomer().getModified());
		
		String route_id=customer.getCustomer().getRoute_id();
		String region_id=customer.getCustomer().getRegion_id();
		String depot_id=customer.getCustomer().getDepot_id();
		if(route_id != "0" && route_id != null){
			Routes routes=AppManager.getInstance().getRoutes(aq,region_id, depot_id);
		
			if(routes != null){
				String defRoute = routes.getRouteNameById(route_id);
				if(defRoute != null){
					aq.id(R.id.textViewRoute).text(defRoute);
				}else{
					aq.id(R.id.tableRowRoute).gone();
				}
			}else{
				aq.id(R.id.tableRowRoute).gone();
			}
		}
		
		String str="";
		for(String s:customer.getAssignToList())
		{
			str=str+"\n"+s;
		}
		aq.id(R.id.textViewAssignTo).text(str);
	}
}
