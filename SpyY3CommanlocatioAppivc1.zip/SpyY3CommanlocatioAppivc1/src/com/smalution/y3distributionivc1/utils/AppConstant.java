package com.smalution.y3distributionivc1.utils;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import android.content.Context;
import android.telephony.TelephonyManager;

public class AppConstant {
	public static String JSONGSTRING=null;
	public static String DELETE_ID=null;
	
	public static boolean LOADFILLLISTVIEW=false;
	
	public static String OPTION_MODE=null;
	
	public static int pageCount;
	
	public static boolean isLogin=false;
	
	public static String ANDROIDDEVICEID=null;
	
	// this are some operation code for application.
	// this is for customer edit operation code...
	public static String CUSTOMER_EDIT_OPCODE="CE02";
	
	// this is for customervisit edit operation code...
	public static String CUSTOMER_VISIT_EDIT="CVE02";
	
	// this is for IncentiveEdit operation code...
	
	public static String INCENTIVE_EDIT="IE02";
	
	// this is for payment operation code..
	public static String PAYMENT_EDIT="PE02";
	
	
// this is for username and password..
	
	public static String USERNAME="username";
	public static String PASSWORD="password";
	
	public static String getCurrentDateAndTime()
	{
		SimpleDateFormat sim = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		System.out.println(sim.format(new Date()));
		return sim.format(new Date());
	}
	public static String getCurrentDate()
	{
		SimpleDateFormat sim = new SimpleDateFormat("yyyy-MM-dd");
		return sim.format(new Date());
	}
	
	public static String getBackDate( int days )
	{
		SimpleDateFormat sim = new SimpleDateFormat("yyyy-MM-dd");
		
		Calendar calendar = Calendar.getInstance();
		
		calendar.add(Calendar.DAY_OF_YEAR, -days);
		Date backDate = calendar.getTime();
		
		return sim.format(backDate);
	}
	
	
	public static String getRequestId()
	{
		  DateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmss");
		  Date date = new Date();
		  return "::"+dateFormat.format(date).toString();
	}
/// this is for synchronization not done string....
 public static String SYNC_NOT_DONE="Not yet Sync";
}
