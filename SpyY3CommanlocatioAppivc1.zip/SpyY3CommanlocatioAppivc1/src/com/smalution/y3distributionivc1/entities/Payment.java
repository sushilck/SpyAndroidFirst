package com.smalution.y3distributionivc1.entities;

import android.os.Parcel;
import android.os.Parcelable;

public class Payment implements Parcelable
{
	private String distributors;
	private String paymentMode;
	private String bank;
	private String amount;
	private String brand;
	private String paymentReference;
	private String paymentDate;
	private String notes;
	
	
	
	public Payment(){}
	
	public Payment(Parcel in)
 	{
		distributors = in.readString();
		paymentMode = in.readString();
		bank = in.readString();
		amount = in.readString();
		brand = in.readString();
		paymentReference = in.readString();
		paymentDate = in.readString();
		notes = in.readString();
	}
 	@Override
 	public int describeContents() 
 	{
 		return 0;
 	}
 	@Override
 	public void writeToParcel(Parcel dest, int flags) 
 	{
 		dest.writeString(distributors);
 		dest.writeString(paymentMode);
 		dest.writeString(bank);
 		dest.writeString(amount);
 		dest.writeString(brand);
 		dest.writeString(paymentReference);
 		dest.writeString(paymentDate);
 		dest.writeString(notes);
	}
 	public static final Parcelable.Creator<Payment> CREATOR = new Parcelable.Creator<Payment>() 
 	{
 		public Payment createFromParcel(Parcel in) 
 		{
 			return new Payment(in);
 		}
 	
 		public Payment[] newArray (int size) 
 		{
 			return new Payment[size];
 		}
 	};



	public String getDistributors() {
		return distributors;
	}

	public void setDistributors(String distributors) {
		this.distributors = distributors;
	}

	public String getPaymentMode() {
		return paymentMode;
	}

	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}

	public String getBank() {
		return bank;
	}

	public void setBank(String bank) {
		this.bank = bank;
	}

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public String getPaymentReference() {
		return paymentReference;
	}

	public void setPaymentReference(String paymentReference) {
		this.paymentReference = paymentReference;
	}

	public String getPaymentDate() {
		return paymentDate;
	}

	public void setPaymentDate(String paymentDate) {
		this.paymentDate = paymentDate;
	}

	public String getNotes() {
		return notes;
	}

	public void setNotes(String notes) {
		this.notes = notes;
	}
 	
}
