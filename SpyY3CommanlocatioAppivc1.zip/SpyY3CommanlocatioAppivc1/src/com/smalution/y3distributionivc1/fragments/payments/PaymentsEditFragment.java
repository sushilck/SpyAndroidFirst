package com.smalution.y3distributionivc1.fragments.payments;

import com.smalution.y3distributionivc1.AppManager;
import com.smalution.y3distributionivc1.R;
import com.smalution.y3distributionivc1.SendDataToServerAsyncTask;
import com.smalution.y3distributionivc1.database.Y3QueryDataSource;
import com.smalution.y3distributionivc1.entities.payments.Payments;
import com.smalution.y3distributionivc1.entities.settings.Banks;
import com.smalution.y3distributionivc1.entities.settings.Brand;
import com.smalution.y3distributionivc1.entities.settings.Brands;
import com.smalution.y3distributionivc1.entities.settings.Distributors;
import com.smalution.y3distributionivc1.entities.settings.PaymentModes;
import com.smalution.y3distributionivc1.fragments.SuperFragment;
import com.smalution.y3distributionivc1.utils.AppConstant;
import com.smalution.y3distributionivc1.utils.DatePickerFragment;

import java.util.Calendar;

import android.app.AlertDialog;
import android.app.DatePickerDialog.OnDateSetListener;
import android.content.DialogInterface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.DatePicker;
import android.widget.Toast;

import com.androidquery.AQuery;

public class PaymentsEditFragment extends SuperFragment 
{
	Payments psyments;
	View rootView;
	AQuery aq; 
	public static final int FLAG_SELECT_DISTRIBUTOR=101;
	public static final int FLAG_SELECT_PAYMENTMODE=102;
	public static final int FLAG_SELECT_BANK=103;
	public static final int FLAG_SELECT_AMOUNT=104;
	public static final int FLAG_SELECT_BRAND=105;
	UIHandler uiHandler;
	public class UIHandler extends Handler 
	{ 
        public void handleMessage(Message msg) 
        { 
        	switch(msg.arg1)
        	{
        		case FLAG_SELECT_DISTRIBUTOR:
        		{
        			String selectedValue=(String)msg.obj;
        			aq.id(R.id.buttonDistributors).text(selectedValue);
        			Distributors distributors = AppManager.getInstance().getDistributor(aq);
        			if(distributors!=null)
        			{
        				psyments.getPayment().setDistributor_id(distributors.getItem(msg.arg2).getId());		
        			}
        			break;
				}
        		case FLAG_SELECT_PAYMENTMODE:
        		{
        			String selectedValue=(String)msg.obj;
        			aq.id(R.id.buttonPaymentMode).text(selectedValue);
        			//psyments.getPayment().setPayment_mode(AppManager.getInstance().getPaymentModes(aq).getId(selectedValue));
        			psyments.getPayment().setPayment_mode(selectedValue);
        			break;
        		}
        		case FLAG_SELECT_BANK:
        		{
        			String selectedValue=(String)msg.obj;
        			aq.id(R.id.buttonBank).text(selectedValue);
        			Banks banks= AppManager.getInstance().getBanks(aq);
        			if(banks!=null)
        			{
        				psyments.getPayment().setBank_id(banks.getItem(msg.arg2).getId());
        			}
        			break;
        		}
        		case FLAG_SELECT_BRAND:
	    		{
	    			String selectedValue=(String)msg.obj;
        			aq.id(R.id.buttonBrand).text(selectedValue);
        			Brands brands = AppManager.getInstance().getBrands(aq);
        			if(brands!=null)
        			{
        				psyments.getPayment().setBrand_id(brands.getItem(msg.arg2).getId());	
        			}
        			break;
	    		}
	    	}
        }
    };
	public void setUIArguments(final Bundle args) 
	{
	    getActivity().runOnUiThread(new Runnable() 
	    {
	        public void run() 
	        {
	        	psyments = args.getParcelable("PAYMENT");
	        }
	    });
	}
	@Override
	public void onCreate(Bundle savedInstanceState) 
	{
		super.onCreate(savedInstanceState);
		psyments = getArguments().getParcelable("PAYMENT");
	}
	@Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,Bundle savedInstanceState) 
	{
        rootView = inflater.inflate(R.layout.payments_edit_fragment, container, false);
        uiHandler=new UIHandler();
        aq=new AQuery(rootView);
        initUI();
        return rootView;
    }
	private void initUI() 
	{
		final Distributors distributors= AppManager.getInstance().getDistributor(aq);
		if(distributors!=null)
		{
			String distributor = distributors.getDepotNameById(psyments.getPayment().getDistributor_id());
			if(distributor!=null)
			{
				aq.id(R.id.buttonDistributors).text(distributor);
			}
		}
		aq.id(R.id.buttonDistributors).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				boolean flag=false;
				if(distributors!=null)
				{
					String[] arr=distributors.getNameArray();
					if(arr.length>0)
					{
						AppManager.getInstance().showSelectionAlertDialog(getActivity(), uiHandler, FLAG_SELECT_DISTRIBUTOR, arr);
						flag=true;
					}
				}
				if(!flag)
				{
					Toast.makeText(getActivity(), getString(R.string.distributor_required_mess), Toast.LENGTH_SHORT).show();
				}
			}
		});
		aq.id(R.id.buttonPaymentMode).text(psyments.getPayment().getPayment_mode());
		aq.id(R.id.buttonPaymentMode).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				boolean flag=false;
				PaymentModes paymentModes=AppManager.getInstance().getPaymentModes(aq);
				if(paymentModes!=null)
				{
					String[] arr=paymentModes.getName();
					if(arr.length>0)
					{
						AppManager.getInstance().showSelectionAlertDialog(getActivity(), uiHandler, FLAG_SELECT_PAYMENTMODE, arr);
						flag=true;
					}
				}
				if(!flag)
				{
					Toast.makeText(getActivity(), getString(R.string.payment_mode_required_mess), Toast.LENGTH_SHORT).show();
				}
			}
		});
		aq.id(R.id.buttonBank).text(psyments.getBank().getName());
		aq.id(R.id.buttonBank).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				boolean flag=false;
				Banks banks=AppManager.getInstance().getBanks(aq);
				if(banks!=null)
				{
					String[] arr=banks.getName();
					if(arr.length>0)
					{
						AppManager.getInstance().showSelectionAlertDialog(getActivity(), uiHandler, FLAG_SELECT_BANK, arr);
						flag=true;
					}
				}
				if(!flag)
				{
					Toast.makeText(getActivity(), getString(R.string.bank_required_mess), Toast.LENGTH_SHORT).show();
				}
			}
		});
		final Brands brands = AppManager.getInstance().getBrands(aq);
		if(brands!=null)
		{
			Brand brand = brands.getBrandById(psyments.getPayment().getBrand_id());
			if(brand!=null)
			{
				aq.id(R.id.buttonBrand).text(brand.getName());
			}
		}
		aq.id(R.id.buttonBrand).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				boolean flag=false;
				if(brands!=null)
				{
					String[] arr=brands.getBrandsNames();
					if(arr.length>0)
					{
						AppManager.getInstance().showSelectionAlertDialog(getActivity(), uiHandler, FLAG_SELECT_BRAND, arr);
						flag=true;
					}
				}
				if(!flag)
				{
					Toast.makeText(getActivity(), getString(R.string.brand_required_mess), Toast.LENGTH_SHORT).show();
				}
			}
		});
		aq.id(R.id.editTextPaymentDate).text(psyments.getPayment().getPayment_date());
		aq.id(R.id.editTextPaymentDate).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				showDatePicker();
			}
		});
		aq.id(R.id.buttonSave).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				if(validateInput())
				{
					
					if(AppManager.isOnline(getActivity())){
						String jsonString = psyments.createJson(aq, true);
						new SendDataToServerAsyncTask<Payments>(
					    		getActivity(), 
					    		jsonString,
					    		null, 
					    		AppManager.getInstance().URL_UPDATE_PAYMENTS,
					    		getString(R.string.payment_updated),
					    		true,
					    		null,
					    		null,
					    		-1,AppConstant.PAYMENT_EDIT).execute();
					}
					else{
						 Y3QueryDataSource datasource=new Y3QueryDataSource(getActivity());
						 datasource.open();
						 datasource.updatePaymentData(psyments, psyments.getPayment().getId());//(customer,customer.getCustomer().getId());			
						 showEditDialog();
						 // Toast.makeText(getActivity(), "Customer updated successfully.", Toast.LENGTH_SHORT).show();
					     //getActivity().getSupportFragmentManager().popBackStack();
					}
				
				}
			}
		});
		aq.id(R.id.editTextAmount).text(psyments.getPayment().getAmount());
		aq.id(R.id.editTextPaymentRef).text(psyments.getPayment().getPayment_ref());
		aq.id(R.id.editTextNotes).text(psyments.getPayment().getNotes());
	}
	private boolean validateInput()
	{
		String distributor = aq.id(R.id.buttonDistributors).getText().toString();
		if(distributor!=null && distributor.length()>0)
		{
			String paymentMode = aq.id(R.id.buttonPaymentMode).getText().toString();
			if(paymentMode!=null && paymentMode.length()>0)
			{
				String bank = aq.id(R.id.buttonBank).getText().toString();
				String  amount= aq.id(R.id.editTextAmount).getText().toString();
				if(amount!=null && amount.length()>0)
				{
					psyments.getPayment().setAmount(amount);
					String brand = aq.id(R.id.buttonBrand).getText().toString();
					if(brand!=null && brand.length()>0)
					{
						String pamentRef = aq.id(R.id.editTextPaymentRef).getText().toString();
						if(pamentRef!=null && pamentRef.length()>0)
						{
							psyments.getPayment().setPayment_ref(pamentRef);
							String date = aq.id(R.id.editTextPaymentDate).getText().toString();
							if(date!=null && date.length()>0)
							{
								psyments.getPayment().setPayment_date(date);
								String notes = aq.id(R.id.editTextNotes).getText().toString();
								psyments.getPayment().setNotes(notes);
								return true;
							}
							else
							{
								Toast.makeText(getActivity(), getString(R.string.Payment_Date), Toast.LENGTH_SHORT).show();
							}
						}
						else
						{
							Toast.makeText(getActivity(), getString(R.string.Payment_Ref), Toast.LENGTH_SHORT).show();
						}
					}
					else
					{
						Toast.makeText(getActivity(), getString(R.string.select_brand), Toast.LENGTH_SHORT).show();
					}
				}
				else
				{
					Toast.makeText(getActivity(), getString(R.string.pls_enter_amt), Toast.LENGTH_SHORT).show();
				}
			}
			else
			{
				Toast.makeText(getActivity(),getString(R.string.Payment_Mode) , Toast.LENGTH_SHORT).show();
			}
		}
		else
		{
			Toast.makeText(getActivity(), getString(R.string.select_distributor), Toast.LENGTH_SHORT).show();
		}
		return false;
	}
	private void showEditDialog(){	
		AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
				getActivity());
		alertDialogBuilder.setTitle(getString(R.string.confirm));
		alertDialogBuilder
				.setMessage(getString(R.string.payment_updated))
				.setCancelable(false)
				.setPositiveButton(
						getString(R.string.OK),
						new DialogInterface.OnClickListener() {
							public void onClick(
									DialogInterface dialog,
									int id) {
								
								getActivity().getSupportFragmentManager().popBackStack();
								dialog.cancel();
							}
						});
			
		AlertDialog alertDialog = alertDialogBuilder
				.create();
		alertDialog.show();
	}
	private void showDatePicker() 
	{
		  DatePickerFragment date = new DatePickerFragment();
		  Calendar calender = Calendar.getInstance();
		  Bundle args = new Bundle();
		  args.putInt("year", calender.get(Calendar.YEAR));
		  args.putInt("month", calender.get(Calendar.MONTH));
		  args.putInt("day", calender.get(Calendar.DAY_OF_MONTH));
		  date.setArguments(args);
		  date.setCallBack(ondate);
		  date.show(getActivity().getSupportFragmentManager(), getString(R.string.date_picker));
	}
	OnDateSetListener ondate = new OnDateSetListener() 
	{
		@Override
		public void onDateSet(DatePicker view, int year, int monthOfYear,int dayOfMonth) 
		{
			String dateStr=String.valueOf(year) + "-" + String.valueOf(monthOfYear+1)+ "-" + String.valueOf(dayOfMonth);
			aq.id(R.id.editTextPaymentDate).text(dateStr);
			psyments.getPayment().setPayment_date(dateStr);
		}
	};
}
