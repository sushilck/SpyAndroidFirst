package com.smalution.y3distributiondr1.utils;

public class Constants 
{
	public static String PREFKEY_DEPOTS="depots";
	public static String PREFKEY_REGIONS="regions";
	public static String PREFKEY_LGAS="lgas";
	public static String PREFKEY_STATES="states";
	public static String PREFKEY_USERS="users";
	public static String PREFKEY_CUSTOMERS="customers";
	public static String PREFKEY_BRANDS="brands";
	public static String PREFKEY_DISTRIBUTOR="distributors";
	public static String PREFKEY_PAYMENTMODE="paymentMode";
	public static String PREFKEY_BANKLIST="bankList";
	public static String PREFKEY_ACTIVECOMPAIGN="activeCompaigns";
	public static String PREFKEY_EXPENSETYPELIST="expenseTypeList";
	public static String PREFKEY_REDISTRIBUTOR="redistributors";
}
