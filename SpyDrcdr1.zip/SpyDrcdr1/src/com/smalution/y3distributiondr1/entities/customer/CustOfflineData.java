package com.smalution.y3distributiondr1.entities.customer;

import org.json.JSONObject;

import android.os.Parcel;
import android.os.Parcelable;

public class CustOfflineData {
	private int customerOfflineId;
	private String JsonData;
	private String isOfflineAddedSales;
	private String offlineJson;
	public CustOfflineData(){}
	
	
	public CustOfflineData(int customerId,String jsonData,String isOfflineAdded,String offlineJson)
	{
		try
		{
			setCustomerOfflineId(customerId);
			setJsonData(jsonData);
			setIsOfflineAddedSales(isOfflineAdded);
			setOfflineJson(offlineJson);
			
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	public CustOfflineData(int customerId)
	{
		try
		{
			setCustomerOfflineId(customerId);
			
			
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}

	
	public int getCustomerOfflineId() {
		return customerOfflineId;
	}


	public void setCustomerOfflineId(int customerOfflineId) {
		this.customerOfflineId = customerOfflineId;
	}

	public String getJsonData() {
		return JsonData;
	}

	public void setJsonData(String jsonData) {
		this.JsonData = jsonData;
	}


	public String getIsOfflineAddedSales() {
		return isOfflineAddedSales;
	}


	public void setIsOfflineAddedSales(String isOfflineAddedSales) {
		this.isOfflineAddedSales = isOfflineAddedSales;
	}


	public String getOfflineJson() {
		return offlineJson;
	}


	public void setOfflineJson(String offlineJson) {
		this.offlineJson = offlineJson;
	}
	
	
 	
	
	
	
}
