package com.smalution.y3distributiondr1.entities.settings;

import java.util.ArrayList;
import org.json.JSONArray;
import org.json.JSONObject;

public class ParseListItems 
{
	ArrayList<SelectionButtonItem> items;
	String[] itemsNameArr; 
	public ParseListItems(){}
	public ParseListItems(JSONArray jsonArray)
	{
		try
		{
			items=new ArrayList<SelectionButtonItem>();
			itemsNameArr=new String[jsonArray.length()];
			for(int i=0;i<jsonArray.length();i++)
			{
				JSONObject jsonObject = jsonArray.getJSONObject(i); 
				String id=jsonObject.isNull("id")?"":jsonObject.getString("id");
				String value=jsonObject.isNull("value")?"":jsonObject.getString("value");
				SelectionButtonItem itm=new SelectionButtonItem(id, "", value);
				items.add(itm);
				itemsNameArr[i]=itm.getTitle();
			}
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	public String getItemNameById(String id)
	{
		for(SelectionButtonItem itm:items)
		{
			if(itm.getId().equals(id))
				return itm.getTitle();
		}
		return null;
	}
	
	
	public SelectionButtonItem getItem(int position)
	{
		return items.get(position);
	}
	public String[] getItemsNameArr() {
		return itemsNameArr;
	}
	public void setItemsNameArr(String[] statesNameArr) {
		this.itemsNameArr = statesNameArr;
	}
}
