package com.smalution.y3distributionlb2.fragments.payments;

import com.smalution.y3distributionlb2.AppManager;
import com.smalution.y3distributionlb2.R;
import com.smalution.y3distributionlb2.Utils;
import com.smalution.y3distributionlb2.database.Y3QueryDataSource;
import com.smalution.y3distributionlb2.entities.User;
import com.smalution.y3distributionlb2.entities.payments.Payments;
import com.smalution.y3distributionlb2.entities.settings.Banks;
import com.smalution.y3distributionlb2.entities.settings.Brands;
import com.smalution.y3distributionlb2.entities.settings.Depots;
import com.smalution.y3distributionlb2.entities.settings.Distributors;
import com.smalution.y3distributionlb2.entities.settings.PaymentModes;
import com.smalution.y3distributionlb2.fragments.SuperFragment;
import com.smalution.y3distributionlb2.utils.AppConstant;
import com.smalution.y3distributionlb2.utils.DatePickerFragment;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Hashtable;

import org.json.JSONException;
import org.json.JSONObject;

import android.app.AlertDialog;
import android.app.DatePickerDialog.OnDateSetListener;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.DatePicker;
import android.widget.Toast;

import com.androidquery.AQuery;

public class PaymentsAddFragment extends SuperFragment 
{
	Payments psyments;
	View rootView;
	AQuery aq; 
	public static final int FLAG_SELECT_DISTRIBUTOR=101;
	public static final int FLAG_SELECT_PAYMENTMODE=102;
	public static final int FLAG_SELECT_BANK=103;
	public static final int FLAG_SELECT_AMOUNT=104;
	public static final int FLAG_SELECT_BRAND=105;
	public static final int FLAG_SELECT_DEPOT=106;
	UIHandler uiHandler;
	public String jsonStr;
	private boolean isaddMore;
	public String bank_id;
	public String distributor_id;
	public String brand_id;
	private String depot_id;
	public boolean isDraft = false;
	public class UIHandler extends Handler 
	{ 
        public void handleMessage(Message msg) 
        { 
        	switch(msg.arg1)
        	{
        		case FLAG_SELECT_DISTRIBUTOR:
        		{
        			String selectedValue=(String)msg.obj;
        			aq.id(R.id.buttonDistributors).text(selectedValue);
        			Distributors distributors = AppManager.getInstance().getDistributor(aq);
        			if(distributors!=null)
        			{
        				distributor_id=distributors.getItem(msg.arg2).getId();
        				psyments.getPayment().setDistributor_id(distributors.getItem(msg.arg2).getId());		
        			}
        			break;
				}
        		case FLAG_SELECT_PAYMENTMODE:
        		{
        			String selectedValue=(String)msg.obj;
        			aq.id(R.id.buttonPaymentMode).text(selectedValue);
        			//psyments.getPayment().setPayment_mode(AppManager.getInstance().getPaymentModes(aq).getId(selectedValue));
        			psyments.getPayment().setPayment_mode(selectedValue);
        			break;
        		}
        		case FLAG_SELECT_BANK:
        		{
        			String selectedValue=(String)msg.obj;
        			aq.id(R.id.buttonBank).text(selectedValue);
        			Banks banks= AppManager.getInstance().getBanks(aq);
        			if(banks!=null)
        			{
        				bank_id=banks.getItem(msg.arg2).getId();
        				psyments.getBank().setName(banks.getItem(msg.arg2).getTitle());
        				psyments.getPayment().setBank_id(banks.getItem(msg.arg2).getId());
        				//psyments.getPayment().set
        			}
        			break;
        		}
        		case FLAG_SELECT_BRAND:
	    		{
	    			String selectedValue=(String)msg.obj;
        			aq.id(R.id.buttonBrand).text(selectedValue);
        			Brands brands = AppManager.getInstance().getBrands(aq);
        			if(brands!=null)
        			{
        				brand_id=brands.getItem(msg.arg2).getId();
        				psyments.getPayment().setBrand_id(brands.getItem(msg.arg2).getId());	
        			}
        			break;
	    		}
        		case FLAG_SELECT_DEPOT:
	    		{
	    			String selectedValue=(String)msg.obj;
	    			aq.id(R.id.buttonDepot).text(selectedValue);
	    			Depots depots=AppManager.getInstance().getDepots(aq);
	    			
	    			if(depots!=null)
	    			{
	    				
	    				depot_id=depots.getItem(msg.arg2).getId();
	    				psyments.getPayment().setDepot_id(depot_id);
	    			}
	    			break;
	    		}
	    	}
        }
    };
	public void setUIArguments(final Bundle args) 
	{
	    getActivity().runOnUiThread(new Runnable() 
	    {
	        public void run() 
	        {
	        	
	        }
	    });
	}
	@Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,Bundle savedInstanceState) 
	{
        rootView = inflater.inflate(R.layout.payments_add_fragment, container, false);
        uiHandler=new UIHandler();
        aq=new AQuery(rootView);
        psyments=new Payments();
        isaddMore=false;
        initUI();
        pfillfromDraft();
        return rootView;
    }
	
	public void onPause(){
		super.onPause();
		System.out.println("This is OnPause activity");
		paddDraft();
	}
	
	public void onStop(){
		super.onStop();
		System.out.println("This is onStop activity");
		paddDraft();
	}
	
	public void onDestroy(){
		super.onDestroy();
		System.out.println("This is onDestroy activity");
		paddDraft();
	}
	private void initUI() 
	{
		aq.id(R.id.buttonDistributors).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				boolean flag=false;
				Distributors distributors= AppManager.getInstance().getDistributor(aq);
				if(distributors!=null)
				{
					String[] arr=distributors.getNameArray();
					if(arr.length>0)
					{
						AppManager.getInstance().showSelectionAlertDialog(getActivity(), uiHandler, FLAG_SELECT_DISTRIBUTOR, arr);
						flag=true;
					}
				}
				if(!flag)
				{
					Toast.makeText(getActivity(), getString(R.string.distributor_required_mess), Toast.LENGTH_SHORT).show();
				}
			}
		});
		aq.id(R.id.buttonPaymentMode).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				boolean flag=false;
				PaymentModes paymentModes=AppManager.getInstance().getPaymentModes(aq);
				if(paymentModes!=null)
				{
					String[] arr=paymentModes.getName();
					if(arr.length>0)
					{
						AppManager.getInstance().showSelectionAlertDialog(getActivity(), uiHandler, FLAG_SELECT_PAYMENTMODE, arr);
						flag=true;
					}
				}
				if(!flag)
				{
					Toast.makeText(getActivity(), getString(R.string.payment_mode_required_mess), Toast.LENGTH_SHORT).show();
				}
			}
		});
		aq.id(R.id.buttonBank).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				boolean flag=false;
				Banks banks=AppManager.getInstance().getBanks(aq);
				if(banks!=null)
				{
					String[] arr=banks.getName();
					if(arr.length>0)
					{
						AppManager.getInstance().showSelectionAlertDialog(getActivity(), uiHandler, FLAG_SELECT_BANK, arr);
						flag=true;
					}
				}
				if(!flag)
				{
					Toast.makeText(getActivity(), getString(R.string.bank_required_mess), Toast.LENGTH_SHORT).show();
				}
			}
		});
//		aq.id(R.id.buttonAmount) 
		
		aq.id(R.id.buttonBrand).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				boolean flag=false;
				Brands brands = AppManager.getInstance().getBrands(aq);
				if(brands!=null)
				{
					String[] arr=brands.getBrandsNames();
					if(arr.length>0)
					{
						AppManager.getInstance().showSelectionAlertDialog(getActivity(), uiHandler, FLAG_SELECT_BRAND, arr);
						flag=true;
					}
				}
				if(!flag)
				{
					Toast.makeText(getActivity(), getString(R.string.bank_required_mess), Toast.LENGTH_SHORT).show();
				}
			}
		});
		aq.id(R.id.buttonDepot).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				boolean flag=false;
				Depots depots=AppManager.getInstance().getDepots(aq);
				if(depots!=null)
				{
					String[] arr=depots.getTitleArr();
					if(arr.length>0)
					{
						AppManager.getInstance().showSelectionAlertDialog(getActivity(), uiHandler, FLAG_SELECT_DEPOT, arr);
						flag=true;
					}
				}
				if(!flag)
				{
					Toast.makeText(getActivity(), getString(R.string.depot_req_mess), Toast.LENGTH_SHORT).show();
				}
			}
		});
		aq.id(R.id.editTextPaymentDate).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				showDatePicker();
			}
		});
		aq.id(R.id.buttonSave).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				if(validateInput())
				{
					jsonStr = psyments.createJson(aq, false);
					
					if(AppManager.isOnline(getActivity())){		
						isaddMore=false;
						new AddPaymentAsync().execute();
					}else{
						
					    //customer.getCustomer().getId()
					    DateFormat dateFormat = new SimpleDateFormat("HHmmss");
						Date date = new Date();
						System.out.println(dateFormat.format(date));
						String  firstLetter = dateFormat.format(date).toString().replaceFirst("^0+(?!$)", "");
						psyments.getPayment().setId(firstLetter);
						final SharedPreferences prefs=getActivity().getSharedPreferences("BGGeoCollector", getActivity().MODE_PRIVATE);
						String str = prefs.getString("user_object", "");
						final String token = prefs.getString("token", null);
						if(str!="")
						{
							try
							{
								JSONObject userJSONObject = new JSONObject(str);
								final User user=new User(userJSONObject);
								psyments.getUser().setFirst_name(user.getFirst_name());
								psyments.getUser().setLast_name(user.getLast_name());
								
								SharedPreferences pprefs = getActivity().getSharedPreferences("BGGeoCollector", getActivity().MODE_PRIVATE);
								Editor edt = pprefs.edit();
								edt.putString("pdraftJsonString", null);
								edt.commit();
								isDraft = true;
							}
							catch(Exception e){
								
							}
						}
						Y3QueryDataSource datasource = new Y3QueryDataSource(getActivity());
					    datasource.open();
					    psyments.getPayment().setCreated(AppConstant.getCurrentDateAndTime());
					    psyments.getPayment().setModified(AppConstant.SYNC_NOT_DONE);
					   long result= datasource.addPaymentData(psyments,"1");	
					   if(result!=-1)
					    {
						   showSaveDialog();
					    }
					    //Toast.makeText(getActivity(), "Payment added successfully.", Toast.LENGTH_SHORT).show();
				    	//getActivity().getSupportFragmentManager().popBackStack();
						
					}
	
				}
			}
		});
		aq.id(R.id.buttonSaveAddMore).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				if(validateInput())
				{
					jsonStr = psyments.createJson(aq, false);
					
					if(AppManager.isOnline(getActivity())){		
						isaddMore=true;
						new AddPaymentAsync().execute();
					}else{
						Y3QueryDataSource datasource = new Y3QueryDataSource(getActivity());
					    datasource.open();
					    //customer.getCustomer().getId()
					    DateFormat dateFormat = new SimpleDateFormat("HHmmss");
						Date date = new Date();
						System.out.println(dateFormat.format(date));
						String  firstLetter = dateFormat.format(date).toString().replaceFirst("^0+(?!$)", "");
						psyments.getPayment().setId(firstLetter);
						final SharedPreferences prefs=getActivity().getSharedPreferences("BGGeoCollector", getActivity().MODE_PRIVATE);
						String str = prefs.getString("user_object", "");
						final String token = prefs.getString("token", null);
						if(str!="")
						{
							try
							{
								JSONObject userJSONObject = new JSONObject(str);
								final User user=new User(userJSONObject);
								psyments.getUser().setFirst_name(user.getFirst_name());
								psyments.getUser().setLast_name(user.getLast_name());
							}
							catch(Exception e){
								e.printStackTrace();
							}
						}
						psyments.getPayment().setCreated(AppConstant.getCurrentDateAndTime());
					    psyments.getPayment().setModified(AppConstant.SYNC_NOT_DONE);
						long result= datasource.addPaymentData(psyments,"1");
					    datasource.close();
					    if(result!=-1)
					    {
					    	showSaveMoreDialog();
					    }				    
						
					}
				    
				}
			}
		});
	}
	private void initFeilds() 
	{
		aq.id(R.id.buttonDistributors).text("");
		aq.id(R.id.buttonPaymentMode).text("");
		aq.id(R.id.buttonBank).text("");
		aq.id(R.id.editTextAmount).text("");
		aq.id(R.id.buttonBrand).text("");
		aq.id(R.id.editTextPaymentRef).text("");
		aq.id(R.id.editTextPaymentDate).text("");
		aq.id(R.id.editTextNotes).text("");

		psyments=new Payments();
	}
	private boolean validateInput()
	{
		String distributor = aq.id(R.id.buttonDistributors).getText().toString();
		if(distributor!=null && distributor.length()>0)
		{
			String paymentMode = aq.id(R.id.buttonPaymentMode).getText().toString();
			if(paymentMode!=null && paymentMode.length()>0)
			{
				String bank = aq.id(R.id.buttonBank).getText().toString();
				String  amount= aq.id(R.id.editTextAmount).getText().toString();
				if(amount!=null && amount.length()>0 
						&& AppManager.getInstance().isValidNumber(amount))
				{
					psyments.getPayment().setAmount(amount);
					String brand = aq.id(R.id.buttonBrand).getText().toString();
					if(brand!=null && brand.length()>0)
					{
						//Toast.makeText(getActivity(), "Please select depot.", Toast.LENGTH_SHORT).show();
						String pamentRef = aq.id(R.id.editTextPaymentRef).getText().toString();
						if(aq.id(R.id.buttonDepot).getButton().getText().toString().length()>0 &&
								!aq.id(R.id.buttonDepot).getButton().getText().toString().startsWith(getString(R.string.select)))
						{
						if(pamentRef!=null && pamentRef.length()>0)
						{
							psyments.getPayment().setPayment_ref(pamentRef);
							String date = aq.id(R.id.editTextPaymentDate).getText().toString();
							if(date!=null && date.length()>0)
							{
								psyments.getPayment().setPayment_date(date);
								String notes = aq.id(R.id.editTextNotes).getText().toString();
								psyments.getPayment().setNotes(notes);
								return true;
							}
							else
							{
								Toast.makeText(getActivity(), getString(R.string.enter_payment_date), Toast.LENGTH_SHORT).show();
							}
						}
						else
						{
							Toast.makeText(getActivity(), getString(R.string.enter_payment_ref), Toast.LENGTH_SHORT).show();
						}
					}
					
					else{
						Toast.makeText(getActivity(), getString(R.string.select_depot), Toast.LENGTH_SHORT).show();
					}
					}
					else
					{
						Toast.makeText(getActivity(), getString(R.string.select_brand), Toast.LENGTH_SHORT).show();
					}
				}
				else
				{
					Toast.makeText(getActivity(), getString(R.string.enter_amount), Toast.LENGTH_SHORT).show();
				}
			}
			else
			{
				Toast.makeText(getActivity(), getString(R.string.Payment_Mode), Toast.LENGTH_SHORT).show();
			}
		}
		else
		{
			Toast.makeText(getActivity(), getString(R.string.select_distributor), Toast.LENGTH_SHORT).show();
		}
		return false;
	}
	private void showDatePicker() 
	{
		  DatePickerFragment date = new DatePickerFragment();
		  Calendar calender = Calendar.getInstance();
		  Bundle args = new Bundle();
		  args.putInt("year", calender.get(Calendar.YEAR));
		  args.putInt("month", calender.get(Calendar.MONTH));
		  args.putInt("day", calender.get(Calendar.DAY_OF_MONTH));
		  date.setArguments(args);
		  date.setCallBack(ondate);
		  date.show(getActivity().getSupportFragmentManager(), getString(R.string.date_picker));
	}
	OnDateSetListener ondate = new OnDateSetListener() 
	{
		@Override
		public void onDateSet(DatePicker view, int year, int monthOfYear,int dayOfMonth) 
		{
			String dateStr=String.valueOf(year) + "-" + String.valueOf(monthOfYear+1)+ "-" + String.valueOf(dayOfMonth);
			aq.id(R.id.editTextPaymentDate).text(dateStr);
			psyments.getPayment().setPayment_date(dateStr);
		}
	};
private class AddPaymentAsync extends AsyncTask<Void, Void, String> {


		ProgressDialog progressDialog;

		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			progressDialog = new ProgressDialog(getActivity());
			progressDialog.setMessage(getString(R.string.wait_progress));
			progressDialog.setCancelable(false);
			progressDialog.setIndeterminate(true);
			progressDialog.show();
			progressDialog
					.setOnKeyListener(new DialogInterface.OnKeyListener() {
						@Override
						public boolean onKey(DialogInterface dialog,
								int keyCode, KeyEvent event) {
							return false;
						}
					});
		}


		protected String doInBackground(Void... params) {
			if (AppManager.getInstance().isOnline(aq.getContext())) {
				//return AppManager.getInstance().getCustomerList(aq, pageCount);
				Hashtable<String,String> params1=new Hashtable<String,String>();
				params1.put("jsonString", jsonStr);			
				String response = Utils.post(getActivity(), AppManager.getInstance().URL_UPDATE_PAYMENTS, params1, null);
				System.out.println("payment Response"+response);
				return response;
			}
			return null;
		}

		protected void onPostExecute(String response) {
			
			progressDialog.dismiss();
			
			try {
				if(response!=null){
				int errorCode=new JSONObject(response).getInt("error");				
				if(errorCode==0){
					 System.out.println("Added");
					 if(isaddMore){
						 	//Toast.makeText(getActivity(), "payment added successfully.", Toast.LENGTH_SHORT).show();
						  //initFeilds();
						 showSaveMoreDialog();
					 }else{
					 //Toast.makeText(getActivity(), "payment added successfully.", Toast.LENGTH_SHORT).show();
				     //getActivity().getSupportFragmentManager().popBackStack();
						 showSaveDialog();
						 SharedPreferences pprefs = getActivity().getSharedPreferences("BGGeoCollector", getActivity().MODE_PRIVATE);
						 Editor edt = pprefs.edit();
						 edt.putString("pdraftJsonString", null);
						 edt.commit();
						 isDraft = true;
						 
					 }
				}
				else{
					System.out.println("something wrong");
					
				}
				}
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}	
	
}

private void showSaveDialog(){	
		AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
				getActivity());
		alertDialogBuilder.setTitle(getString(R.string.confirm));
		alertDialogBuilder
				.setMessage(getString(R.string.payment_added))
				.setCancelable(false)
				.setPositiveButton(
						getString(R.string.OK),
						new DialogInterface.OnClickListener() {
							public void onClick(
									DialogInterface dialog,
									int id) {
								
								getActivity().getSupportFragmentManager().popBackStack();
								dialog.cancel();
							}
						});
			
		AlertDialog alertDialog = alertDialogBuilder
				.create();
		alertDialog.show();
	}
	
	private void showSaveMoreDialog(){	
		AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
				getActivity());
		alertDialogBuilder.setTitle(getString(R.string.confirm));
		alertDialogBuilder
				.setMessage(getString(R.string.payment_added))
				.setCancelable(false)
				.setPositiveButton(
						getString(R.string.OK),
						new DialogInterface.OnClickListener() {
							public void onClick(
									DialogInterface dialog,
									int id) {
								
								//getActivity().getSupportFragmentManager().popBackStack();
								initFeilds();
								dialog.cancel();
							}
						});
			
		AlertDialog alertDialog = alertDialogBuilder
				.create();
		alertDialog.show();
	}
	
	public void paddDraft(){
		if(!isDraft){
			
			psyments.getPayment().setAmount(aq.id(R.id.editTextAmount).getEditText().getText().toString());
			psyments.getPayment().setPayment_ref(aq.id(R.id.editTextPaymentRef).getEditText().getText().toString());
			psyments.getPayment().setPayment_date(aq.id(R.id.editTextPaymentDate).getEditText().getText().toString());
			psyments.getPayment().setNotes(aq.id(R.id.editTextNotes).getEditText().getText().toString());
			psyments.getPayment().setPayment_mode(aq.id(R.id.buttonPaymentMode).getButton().getText().toString());			
			psyments.getPayment().setPayment_mode(aq.id(R.id.buttonPaymentMode).getButton().getText().toString());
			
			psyments.getBank().setId(distributor_id);
			psyments.getPayment().setDistributor_id(distributor_id);
			psyments.getBank().setName(aq.id(R.id.buttonDistributors).getButton().getText().toString());

		    psyments.getBank().setId(bank_id);
			psyments.getPayment().setBank_id(bank_id);
			psyments.getBank().setName(aq.id(R.id.buttonBank).getButton().getText().toString());
			
			
			
			psyments.getBank().setId(depot_id);
			psyments.getPayment().setDepot_id(depot_id);
			psyments.getBank().setName(aq.id(R.id.buttonDepot).getButton().getText().toString());
			
			psyments.getBank().setId(brand_id);
			psyments.getPayment().setBrand_id(brand_id);
			psyments.getBank().setName(aq.id(R.id.buttonBrand).getButton().getText().toString());
			
	
			String pdraftJsonString = psyments.createJson(aq,true);			
			SharedPreferences pprefs = getActivity().getSharedPreferences("BGGeoCollector", getActivity().MODE_PRIVATE);
			Editor edt = pprefs.edit();
			edt.putString("pdraftJsonString", pdraftJsonString);
			edt.commit();
			isDraft = true;
		}
	}
	
	
	
	public void pfillfromDraft(){
		SharedPreferences pprefs = getActivity().getSharedPreferences("BGGeoCollector", getActivity().MODE_PRIVATE);
		String pdraftJsonString = pprefs.getString("pdraftJsonString", null);
		//System.out.println("CUstomerLIST:"+pdraftJsonString);
		if(pdraftJsonString != null){
			try {
				JSONObject paymentJson = new JSONObject(pdraftJsonString);
				String Amount = paymentJson.isNull("amount") ? ""	: paymentJson.getString("amount");
				aq.id(R.id.editTextAmount).text(Amount);
				String Payment_ref = paymentJson.isNull("payment_ref") ? ""	: paymentJson.getString("payment_ref");
				aq.id(R.id.editTextPaymentRef).text(Payment_ref);
				String Payment_date = paymentJson.isNull("payment_date") ? ""	: paymentJson.getString("payment_date");
				aq.id(R.id.editTextPaymentDate).text(Payment_date);
				String Notes = paymentJson.isNull("notes") ? ""	: paymentJson.getString("notes");
				aq.id(R.id.editTextNotes).text(Notes);
				
				String Payment_mode = paymentJson.isNull("payment_mode") ? ""	: paymentJson.getString("payment_mode");
				aq.id(R.id.buttonPaymentMode).text(Payment_mode);
				
				
			     distributor_id = paymentJson.isNull("distributor_id") ? ""	: paymentJson.getString("distributor_id");
				 Distributors distributors = AppManager.getInstance().getDistributor(aq);	
			     String DistributorName = distributors.getDepotNameById(distributor_id);
			     aq.id(R.id.buttonDistributors).text(DistributorName);
			  
				bank_id = paymentJson.isNull("bank_id") ? ""	: paymentJson.getString("bank_id");
				Banks banks = AppManager.getInstance().getBanks(aq);
				String BankName = banks.getDepotNameById(bank_id);
				aq.id(R.id.buttonBank).text(BankName); 
				
					
			    depot_id = paymentJson.isNull("depot_id") ? ""	: paymentJson.getString("depot_id");
				Depots depots = AppManager.getInstance().getDepots(aq);
				String DepotName = depots.getDepotNameById(depot_id);
				aq.id(R.id.buttonDepot).text(DepotName);
				
				
				brand_id = paymentJson.isNull("brand_id") ? ""	: paymentJson.getString("brand_id");
				Brands brands = AppManager.getInstance().getBrands(aq);
				String BrandName = brands.getDepotNameById(brand_id);
				aq.id(R.id.buttonBrand).text(BrandName);
				
				
				/*String brands_id = paymentJson.isNull("brand_id") ? ""	: paymentJson.getString("brand_id");
				Brands brands = AppManager.getInstance().getBrands(aq);
				Brand BrandName = brands.getBrandById(brands_id);
				aq.id(R.id.buttonBrand).text(BrandName.getName());
				*/

				
				

			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}
	
}
