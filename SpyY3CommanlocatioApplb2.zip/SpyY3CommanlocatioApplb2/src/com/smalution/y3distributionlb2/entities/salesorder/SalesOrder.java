package com.smalution.y3distributionlb2.entities.salesorder;




import org.json.JSONObject;

import com.smalution.y3distributionlb2.entities.customer.CustOfflineData;

import android.os.Parcel;
import android.os.Parcelable;

public class SalesOrder implements Parcelable
{
	SOCustomer Customer;
	SOUser User;
	SOOrder Order;
	int sno;
	CustOfflineData custofflineData;
	
	public SalesOrder()
	{
		Customer=new SOCustomer();
		User=new SOUser();
		Order=new SOOrder();
		custofflineData=new CustOfflineData();
	}
	public SalesOrder(JSONObject jsonObject)
	{
		try
		{
			Customer=jsonObject.isNull("Customer")?null:new SOCustomer(jsonObject.getJSONObject("Customer"));
			User=jsonObject.isNull("User")?null:new SOUser(jsonObject.getJSONObject("User"));
			Order=jsonObject.isNull("Order")?null:new SOOrder(jsonObject.getJSONObject("Order"));
			sno=jsonObject.isNull("sno")?0:jsonObject.getInt("sno");
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	public SalesOrder(JSONObject jsonObject,int i)
	{
		try
		{
			Customer=jsonObject.isNull("Customer")?null:new SOCustomer(jsonObject.getJSONObject("Customer"));
			User=jsonObject.isNull("User")?null:new SOUser(jsonObject.getJSONObject("User"));
			Order=jsonObject.isNull("Order")?null:new SOOrder(jsonObject.getJSONObject("Order"));
			sno=jsonObject.isNull("sno")?0:jsonObject.getInt("sno");
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	
	public SalesOrder(JSONObject jsonObject,int dbCustomerId,String jsonData,String isOfflineAdded,String offlineJson)
	{
		try
		{
			Customer=jsonObject.isNull("Customer")?null:new SOCustomer(jsonObject.getJSONObject("Customer"));
			User=jsonObject.isNull("User")?null:new SOUser(jsonObject.getJSONObject("User"));
			Order=jsonObject.isNull("Order")?null:new SOOrder(jsonObject.getJSONObject("Order"));
			sno=jsonObject.isNull("sno")?0:jsonObject.getInt("sno");
			custofflineData=new CustOfflineData(dbCustomerId,jsonData,isOfflineAdded,offlineJson);
			
		}
		
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	
	public SalesOrder(Parcel in)
 	{
		Customer=in.readParcelable(SOCustomer.class.getClassLoader());
		User=in.readParcelable(SOUser.class.getClassLoader());
		Order=in.readParcelable(SOOrder.class.getClassLoader());
		sno=in.readInt();
	}
 	@Override
 	public int describeContents() 
 	{
 		return 0;
 	}
 	@Override
 	public void writeToParcel(Parcel dest, int flags) 
 	{
 		dest.writeParcelable(Customer,flags);
 		dest.writeParcelable(User,flags);
 		dest.writeParcelable(Order,flags);
 		dest.writeInt(sno);
 	}
 	public static final Parcelable.Creator<SalesOrder> CREATOR = new Parcelable.Creator<SalesOrder>() 
 	{
 		public SalesOrder createFromParcel(Parcel in) 
 		{
 			return new SalesOrder(in);
 		}
 	
 		public SalesOrder[] newArray (int size) 
 		{
 			return new SalesOrder[size];
 		}
 	};
 	
	public int getSno() {
		return sno;
	}
	public void setSno(int sno) {
		this.sno = sno;
	}
	public SOCustomer getCustomer() {
		return Customer;
	}
	public void setCustomer(SOCustomer customer) {
		Customer = customer;
	}
	public SOUser getUser() {
		return User;
	}
	public void setUser(SOUser user) {
		User = user;
	}
	public SOOrder getOrder() {
		return Order;
	}
	public void setOrder(SOOrder order) {
		Order = order;
	}public CustOfflineData getCustOffline(){
		return custofflineData;
	}
	public void setCustOffline(CustOfflineData offline){
		custofflineData=offline;
	}
	
//	public String createJson(AQuery aq, boolean isForAddCustomer)
//	{
//		SharedPreferences prefs = AppManager.getInstance().getPrefs(aq.getContext());
//		String token = prefs.getString("token", null);
//		if(isForAddCustomer)
//		{
//			String json="{" +
//					"\"token\":\""+token+"\"," +
//					"\"first_name\":\""+getCustomer().getFirst_name()+"\"," +
//					"\"last_name\":\""+getCustomer().getLast_name()+"\"," +
//					"\"email\":\""+getCustomer().getEmail()+"\"," +
//					"\"address\":\""+getCustomer().getAddress()+"\"," +
//					"\"city\":\""+getCustomer().getCity()+"\"," +
//					"\"state_id\":\""+getCustomer().getState_id()+"\"," +
//					"\"latitude\":\""+getCustomer().getLatitude()+"\"," +
//					"\"longitude\":\""+getCustomer().getLongitude()+"\"," +
//					"\"zipcode\":\""+getCustomer().getZipcode()+"\"," +
//					"\"phone\":\""+getCustomer().getPhone()+"\"," +
//					"\"region_id\":\""+getCustomer().getRegion_id()+"\"," +
//					"\"depot_id\":\""+getCustomer().getDepot_id()+"\"," +
//					"\"lg_area_id\":\""+getCustomer().getLg_area_id()+"\"," +
//					"\"description\":\""+getCustomer().getDescription()+"\"," +
//					"\"view_details\":\""+getCustomer().getView_details()+"\"" +
//					"}";
//			return json;
//		}
//		else
//		{
//			String json="{" +
//					"\"token\":\""+token+"\"," +
//					"\"id\":\""+getCustomer().getId()+"\"," +
//					"\"oldFile_id\":\""+getCustomer().getFile_id()+"\"," +
//					"\"first_name\":\""+getCustomer().getFirst_name()+"\"," +
//					"\"last_name\":\""+getCustomer().getLast_name()+"\"," +
//					"\"email\":\""+getCustomer().getEmail()+"\"," +
//					"\"address\":\""+getCustomer().getAddress()+"\"," +
//					"\"city\":\""+getCustomer().getCity()+"\"," +
//					"\"state_id\":\""+getCustomer().getState_id()+"\"," +
//					"\"latitude\":\""+getCustomer().getLatitude()+"\"," +
//					"\"longitude\":\""+getCustomer().getLongitude()+"\"," +
//					"\"zipcode\":\""+getCustomer().getZipcode()+"\"," +
//					"\"phone\":\""+getCustomer().getPhone()+"\"," +
//					"\"region_id\":\""+getCustomer().getRegion_id()+"\"," +
//					"\"depot_id\":\""+getCustomer().getDepot_id()+"\"," +
//					"\"lg_area_id\":\""+getCustomer().getLg_area_id()+"\"," +
//					"\"description\":\""+getCustomer().getDescription()+"\"," +
//					"\"view_details\":\""+getCustomer().getView_details()+"\"" +
//					"}";
//			return json;
//		}
//		
//		
//	}
 	
 	
}
