package com.smalution.y3distributionlb2.entities.settings;

import org.json.JSONObject;

public class LgArea 
{
	private String id;
	private String name;
	private String state_id;
	public LgArea(){}
	public LgArea(JSONObject jsonObect)
	{
		try
		{
			id=jsonObect.isNull("id")?"":jsonObect.getString("id");
			name=jsonObect.isNull("name")?"":jsonObect.getString("name");
			state_id=jsonObect.isNull("state_id")?"":jsonObect.getString("state_id");
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getState_id() {
		return state_id;
	}
	public void setState_id(String state_id) {
		this.state_id = state_id;
	}
	
}
