package com.smalution.y3distributionlb2.entities.distributor;




import java.util.ArrayList;

import org.json.JSONObject;

import com.smalution.y3distributionlb2.entities.customer.CustOfflineData;

import android.os.Parcel;
import android.os.Parcelable;

public class Distributor implements Parcelable
{
	DistCustomer Customer;
	DistUser User;
	DistRedistributor Redistributor;
	DistRedistributorSale RedistributorSale;
	CustOfflineData custofflineData;
	int sno;
	public Distributor()
	{
		Customer=new DistCustomer();
		User=new DistUser();
		Redistributor=new DistRedistributor();
		RedistributorSale=new DistRedistributorSale();
		custofflineData=new CustOfflineData();
	}
	public Distributor(JSONObject jsonObject)
	{
		try
		{
			Customer=jsonObject.isNull("Customer")?null:new DistCustomer(jsonObject.getJSONObject("Customer"));
			User=jsonObject.isNull("User")?null:new DistUser(jsonObject.getJSONObject("User"));
			Redistributor=jsonObject.isNull("Redistributor")?null:new DistRedistributor(jsonObject.getJSONObject("Redistributor"));
			RedistributorSale=jsonObject.isNull("RedistributorSale")?null:new DistRedistributorSale(jsonObject.getJSONObject("RedistributorSale"));
			sno=jsonObject.isNull("sno")?0:jsonObject.getInt("sno");
			
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	public Distributor(JSONObject jsonObject,int i)
	{
		try
		{
			Customer=jsonObject.isNull("Customer")?null:new DistCustomer(jsonObject.getJSONObject("Customer"));
			User=jsonObject.isNull("User")?null:new DistUser(jsonObject.getJSONObject("User"));
			Redistributor=jsonObject.isNull("Redistributor")?null:new DistRedistributor(jsonObject.getJSONObject("Redistributor"));
			RedistributorSale=jsonObject.isNull("RedistributorSale")?null:new DistRedistributorSale(jsonObject.getJSONObject("RedistributorSale"));
			sno=jsonObject.isNull("sno")?0:jsonObject.getInt("sno");
			
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	public Distributor(JSONObject jsonObject,int dbCustomerId,String jsonData,String isOfflineAdded,String offlineJson)
	{
		try
		{
			Customer=jsonObject.isNull("Customer")?null:new DistCustomer(jsonObject.getJSONObject("Customer"));
			User=jsonObject.isNull("User")?null:new DistUser(jsonObject.getJSONObject("User"));
			Redistributor=jsonObject.isNull("Redistributor")?null:new DistRedistributor(jsonObject.getJSONObject("Redistributor"));
			RedistributorSale=jsonObject.isNull("RedistributorSale")?null:new DistRedistributorSale(jsonObject.getJSONObject("RedistributorSale"));
			sno=jsonObject.isNull("sno")?0:jsonObject.getInt("sno");
			custofflineData=new CustOfflineData(dbCustomerId,jsonData,isOfflineAdded,offlineJson);
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	public Distributor(Parcel in)
 	{
		Customer=in.readParcelable(DistCustomer.class.getClassLoader());
		User=in.readParcelable(DistUser.class.getClassLoader());
		Redistributor=in.readParcelable(DistRedistributor.class.getClassLoader());
		RedistributorSale=in.readParcelable(DistRedistributorSale.class.getClassLoader());
		sno=in.readInt();
	}
 	@Override
 	public int describeContents() 
 	{
 		return 0;
 	}
 	@Override
 	public void writeToParcel(Parcel dest, int flags) 
 	{
 		dest.writeParcelable(Customer,flags);
 		dest.writeParcelable(User,flags);
 		dest.writeParcelable(Redistributor,flags);
 		dest.writeParcelable(RedistributorSale,flags);
 		dest.writeInt(sno);
	}
 	public static final Parcelable.Creator<Distributor> CREATOR = new Parcelable.Creator<Distributor>() 
 	{
 		public Distributor createFromParcel(Parcel in) 
 		{
 			return new Distributor(in);
 		}
 	
 		public Distributor[] newArray (int size) 
 		{
 			return new Distributor[size];
 		}
 	};
 	
	public int getSno() {
		return sno;
	}
	public void setSno(int sno) {
		this.sno = sno;
	}
	public DistCustomer getCustomer() {
		return Customer;
	}
	public void setCustomer(DistCustomer customer) {
		Customer = customer;
	}
	public DistUser getUser() {
		return User;
	}
	public void setUser(DistUser user) {
		User = user;
	}
	public DistRedistributor getRedistributor() {
		return Redistributor;
	}
	public void setRedistributor(DistRedistributor redistributor) {
		Redistributor = redistributor;
	}
	public DistRedistributorSale getRedistributorSale() {
		return RedistributorSale;
	}
	public void setRedistributorSale(DistRedistributorSale redistributorSale) {
		RedistributorSale = redistributorSale;
	}
	public CustOfflineData getCustOffline(){
		return custofflineData;
	}
	public void setCustOffline(CustOfflineData offline){
		custofflineData=offline;
	}
	
	
//	public String createJson(AQuery aq, boolean isForAddCustomer)
//	{
//		SharedPreferences prefs = AppManager.getInstance().getPrefs(aq.getContext());
//		String token = prefs.getString("token", null);
//		if(isForAddCustomer)
//		{
//			String json="{" +
//					"\"token\":\""+token+"\"," +
//					"\"first_name\":\""+getCustomer().getFirst_name()+"\"," +
//					"\"last_name\":\""+getCustomer().getLast_name()+"\"," +
//					"\"email\":\""+getCustomer().getEmail()+"\"," +
//					"\"address\":\""+getCustomer().getAddress()+"\"," +
//					"\"city\":\""+getCustomer().getCity()+"\"," +
//					"\"state_id\":\""+getCustomer().getState_id()+"\"," +
//					"\"latitude\":\""+getCustomer().getLatitude()+"\"," +
//					"\"longitude\":\""+getCustomer().getLongitude()+"\"," +
//					"\"zipcode\":\""+getCustomer().getZipcode()+"\"," +
//					"\"phone\":\""+getCustomer().getPhone()+"\"," +
//					"\"region_id\":\""+getCustomer().getRegion_id()+"\"," +
//					"\"depot_id\":\""+getCustomer().getDepot_id()+"\"," +
//					"\"lg_area_id\":\""+getCustomer().getLg_area_id()+"\"," +
//					"\"description\":\""+getCustomer().getDescription()+"\"," +
//					"\"view_details\":\""+getCustomer().getView_details()+"\"" +
//					"}";
//			return json;
//		}
//		else
//		{
//			String json="{" +
//					"\"token\":\""+token+"\"," +
//					"\"id\":\""+getCustomer().getId()+"\"," +
//					"\"oldFile_id\":\""+getCustomer().getFile_id()+"\"," +
//					"\"first_name\":\""+getCustomer().getFirst_name()+"\"," +
//					"\"last_name\":\""+getCustomer().getLast_name()+"\"," +
//					"\"email\":\""+getCustomer().getEmail()+"\"," +
//					"\"address\":\""+getCustomer().getAddress()+"\"," +
//					"\"city\":\""+getCustomer().getCity()+"\"," +
//					"\"state_id\":\""+getCustomer().getState_id()+"\"," +
//					"\"latitude\":\""+getCustomer().getLatitude()+"\"," +
//					"\"longitude\":\""+getCustomer().getLongitude()+"\"," +
//					"\"zipcode\":\""+getCustomer().getZipcode()+"\"," +
//					"\"phone\":\""+getCustomer().getPhone()+"\"," +
//					"\"region_id\":\""+getCustomer().getRegion_id()+"\"," +
//					"\"depot_id\":\""+getCustomer().getDepot_id()+"\"," +
//					"\"lg_area_id\":\""+getCustomer().getLg_area_id()+"\"," +
//					"\"description\":\""+getCustomer().getDescription()+"\"," +
//					"\"view_details\":\""+getCustomer().getView_details()+"\"" +
//					"}";
//			return json;
//		}
//		
//		
//	}
 	
 	
}
