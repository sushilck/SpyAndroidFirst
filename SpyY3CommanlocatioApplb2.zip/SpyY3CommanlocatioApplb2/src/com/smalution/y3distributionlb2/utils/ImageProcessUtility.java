package com.smalution.y3distributionlb2.utils;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Log;
import android.view.Display;

public class ImageProcessUtility 
{
	public static Bitmap decodeImageFileByDeviceHeightWidth(Activity activity, String imageFilePath)
	{
		try
		{
			Display currentDisplay = activity.getWindowManager().getDefaultDisplay();
			int dw = currentDisplay.getWidth();
			int dh = currentDisplay.getHeight();
			// Load up the image's dimensions not the image itself
			BitmapFactory.Options bmpFactoryOptions = new BitmapFactory.Options();
			bmpFactoryOptions.inJustDecodeBounds = true;
			Bitmap bmp = BitmapFactory.decodeFile(imageFilePath, bmpFactoryOptions);
			int heightRatio = (int)Math.ceil(bmpFactoryOptions.outHeight/(float)dh);
			int widthRatio = (int)Math.ceil(bmpFactoryOptions.outWidth/(float)dw);
			Log.v("HEIGHTRATIO",""+heightRatio);
			Log.v("WIDTHRATIO",""+widthRatio);
			// If both of the ratios are greater than 1,
			// one of the sides of the image is greater than the screen
			if (heightRatio > 1 && widthRatio > 1)
			{
				if (heightRatio > widthRatio)
				{
					// Height ratio is larger, scale according to it
					bmpFactoryOptions.inSampleSize = heightRatio;
				}
				else
				{
					// Width ratio is larger, scale according to it
					bmpFactoryOptions.inSampleSize = widthRatio;
				}
			}
			// Decode it for real
			bmpFactoryOptions.inJustDecodeBounds = false;
			bmp = BitmapFactory.decodeFile(imageFilePath, bmpFactoryOptions);
			return bmp;
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return null;
	}
}
