package com.smalution.y3distributionlb2.utils;

import com.smalution.y3distributionlb2.database.MySQLiteHelper;

import android.database.Cursor;

public class StuffData {
	
	public String getCustomerJson(Cursor cursor,String jsonType){
		String customerJsonData = null;String curlyBraseOpen = "{";
		String curlyBraseClose="}";
		String openQuotation  ="\"";
		String closeQuotation ="\"";
		try{
		
		
		if("Customer".equals(jsonType)){
			//*************

		String assignTo=null;
		
		if("".equals(cursor.getString(cursor.getColumnIndex(MySQLiteHelper.ASSIGNTO))))
		{
			assignTo=null;
			System.out.println("IF TRUE");
		}else{
			assignTo=cursor.getString(cursor.getColumnIndex(MySQLiteHelper.ASSIGNTO));
		}
				
		
		customerJsonData=curlyBraseOpen+openQuotation+"data"+closeQuotation+":["+curlyBraseOpen+openQuotation+"assignTo"+closeQuotation+":"+assignTo+","+openQuotation+
		"User"+closeQuotation+":"+curlyBraseOpen+openQuotation+"last_name"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.LAST_NAME))+closeQuotation+","+openQuotation+"id"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.USER_ID))+closeQuotation+","+openQuotation+"first_name"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.FIRST_NAME))+closeQuotation+curlyBraseClose
		+","+openQuotation+"Customer"+closeQuotation+":"+"{"+openQuotation+"view_details"+closeQuotation+":"+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.VIEW_DETAILS))+
		","+openQuotation+"phone"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.PHONE))+closeQuotation+","
		+openQuotation+"status"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.STATUS))+closeQuotation+","
		+openQuotation+"depot_id"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.DEPOT_ID))+closeQuotation+","
		+openQuotation+"zipcode"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.ZIPCODE))+closeQuotation+","
		+openQuotation+"region_id"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.REGION_ID))+closeQuotation+","
		+openQuotation+"city"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CITY))+closeQuotation+","
		+openQuotation+"amount"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.AMOUNT))+closeQuotation+","
		+openQuotation+"id"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CUSTOMER_ID))+closeQuotation+","
		+openQuotation+"state_id"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.STATE_ID))+closeQuotation+","
		+openQuotation+"first_name"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.FIRST_NAME))+closeQuotation+","
		+openQuotation+"address"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.ADDRESS))+closeQuotation+","
		+openQuotation+"email"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.EMAIL_ID))+closeQuotation+","
		+openQuotation+"route_id"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.ROUTE_ID))+closeQuotation+","
		+openQuotation+"description"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.DESCRIPTION))+closeQuotation+","
		+openQuotation+"last_name"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.LAST_NAME))+closeQuotation+","
		+openQuotation+"image_path"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.IMAGE_PATH))+closeQuotation+","
		+openQuotation+"user_id"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.USER_ID))+closeQuotation+","
		+openQuotation+"route_id"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.ROUTE_ID))+closeQuotation+","
		+openQuotation+"created"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CREATED_DATE))+closeQuotation+","		
		+openQuotation+"modified"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.SYNCHRONIZATION))+closeQuotation+","
		+openQuotation+"longitude"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.LONGITUDE))+closeQuotation+","
		+openQuotation+"latitude"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.LONGITUDE))+closeQuotation+","
		+openQuotation+"lg_area_id"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.LGAREA_ID))+closeQuotation
		+curlyBraseClose+","+openQuotation+"Depot"+closeQuotation+":"+curlyBraseOpen
		+openQuotation+"id"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.DEPOT_ID))+closeQuotation+","
		+openQuotation+"title"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.DEPOT))+closeQuotation+curlyBraseClose
		+
		","+openQuotation+"LgArea"+closeQuotation+":"+curlyBraseOpen
		+openQuotation+"id"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.LGAREA_ID))+closeQuotation+","
		+openQuotation+"name"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.LGAREA))+closeQuotation+curlyBraseClose
		+
		","+openQuotation+"sno"+closeQuotation+":"+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.SNO))+","
		
		+openQuotation+"Region"+closeQuotation+":"+curlyBraseOpen
		+openQuotation+"id"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.REGION_ID))+closeQuotation+","
		+openQuotation+"title"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.REGION))+closeQuotation+curlyBraseClose		
		+
		","+openQuotation+"State"+closeQuotation+":"+curlyBraseOpen
		+openQuotation+"state"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.STATE))+closeQuotation+","
		+openQuotation+"id"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.STATE_ID))+closeQuotation+curlyBraseClose
		+"}]}"
		;
		 }
else if("Incentive".equals(jsonType)){
			
			customerJsonData=	 curlyBraseOpen+openQuotation+"data"+closeQuotation+":["+curlyBraseOpen+openQuotation+"Incentive"+closeQuotation+":"+curlyBraseOpen+
				     openQuotation+"id"+closeQuotation+":"+openQuotation+ cursor.getString(cursor.getColumnIndex(MySQLiteHelper.INCENTIVE_ID))+closeQuotation+
				   ","+  openQuotation+"brand_id"+closeQuotation+":"+openQuotation+ cursor.getString(cursor.getColumnIndex(MySQLiteHelper.INCENTIVE_BRAND_ID))+closeQuotation+
				 ","+openQuotation+"user_id"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.INCENTIVE_USER_ID))+closeQuotation+
				 ","+openQuotation+"customer_id"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.INCENTIVE_CUSTOMER_ID))+closeQuotation+
				 
				 ","+openQuotation+"depot_id"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.INCENTIVE_DEPOT_ID))+closeQuotation+
				 ","+openQuotation+"incentive_date"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.INCENTIVE_INCENTIVE_DATE)) +closeQuotation+
				 ","+openQuotation+"incentive_type"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.INCENTIVE_INCENTIVE_TYPE))+closeQuotation+
				 
				 ","+openQuotation+"unit"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.INCENTIVE_UNIT))+closeQuotation+
				 ","+openQuotation+"cal_qty"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.INCENTIVE_CAL_QNT))+closeQuotation+
				 ","+openQuotation+"quantity"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.INCENTIVE_QUANTITY))+closeQuotation+
				 
				 ","+openQuotation+"created"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.INCENTIVE_CREATED))+closeQuotation+
				 ","+openQuotation+"modified"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.INCENTIVE_MODIFIED))+closeQuotation+"}"+","+
				 openQuotation+"User"+closeQuotation+":"+"{"+
				 
				 openQuotation+"first_name"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.INCENTIVE_FIRST_NAME))+closeQuotation+
				 ","+openQuotation+"last_name"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.INCENTIVE_LAST_NAME))+closeQuotation+"}"+","+
				
				 openQuotation+"Brand"+closeQuotation+":"+"{"+
				      openQuotation+"id"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.INCENTIVE_BRAND_BRAND_ID)) +closeQuotation+
				 ","+ openQuotation+"name"+closeQuotation+":"+openQuotation+ cursor.getString(cursor.getColumnIndex(MySQLiteHelper.INCENTIVE_BRAND_NAME ))+closeQuotation+
				 ","+openQuotation+"description"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.INCENTIVE_BRAND_DESCRIPTION))+closeQuotation+
				 ","+ openQuotation+"user_id"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.INCENTIVE_BRAND_USER_ID))+closeQuotation+
				 ","+ openQuotation+"case_price"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.INCENTIVE_CASE_PRICE	))+closeQuotation+
				 ","+ openQuotation+"roll_price"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.INCENTIVE_ROLL_PRICE))+closeQuotation+
				 ","+openQuotation+"pack_price"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.INCENTIVE_PACK_PRICE))+closeQuotation+
				 ","+openQuotation+"2pack_price"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.INCENTIVE_2PACK_PRICE))+closeQuotation+
				 ","+openQuotation+"case_roll"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.INCENTIVE_CASE_ROLL))+closeQuotation+
				 ","+openQuotation+"roll_pack"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.INCENTIVE_ROLL_PACK))+closeQuotation+
				 ","+openQuotation+"pack_sticks"+closeQuotation+":"+openQuotation+ cursor.getString(cursor.getColumnIndex(MySQLiteHelper.INCENTIVE_PACK_STICKS))+closeQuotation+
				 ","+openQuotation+"2pack_pack"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.INCENTIVE_2ND_PACK_PACK))+closeQuotation+
				 ","+openQuotation+"status"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.INCENTIVE_STATUS))+closeQuotation+
				
				 ","+openQuotation+"rd_case_price"+closeQuotation+":"+openQuotation+ cursor.getString(cursor.getColumnIndex(MySQLiteHelper.INCENTIVE_RD_CASE_PRICE))+closeQuotation+
				 ","+openQuotation+"rd_roll_price"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.INCENTIVE_RD_ROLL_PRICE))+closeQuotation+
				 
				 
				 ","+openQuotation+"rd_pack_price"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.INCENTIVE_RD_PACK_PRICE))+closeQuotation+
				 ","+openQuotation+"rd_2pack_price"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.INCENTIVE_RD_2ND_PACK_PRICE))+closeQuotation+
				 ","+openQuotation+"created"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.INCENTIVE_BRAND_CREATED))+closeQuotation+
				 ","+openQuotation+"modified"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.INCENTIVE_BRAND_MODIFIED))+closeQuotation+"}"+","+
				 openQuotation+"Depot"+closeQuotation+":"+"{"+
				 openQuotation+"id"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.INCENTIVE_DEPOTID))+closeQuotation+
				 ","
				 +openQuotation+"title"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.INCENTIVE_DEPOT_NAME))+closeQuotation+
				 ","
				 +openQuotation+"region_id"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.INCENTIVE_DEPOT_REGION_ID))+closeQuotation+"}"+","+
			
			    openQuotation+"Customer"+closeQuotation+":"+"{"+
				openQuotation+"id"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.INCENTIVECUSTOMER_ID))+closeQuotation+
				","
				+openQuotation+"first_name"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.INCENTIVE_CUSTOMER_FIRST_NAME))+closeQuotation+
				","
				+openQuotation+"last_name"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.INCENTIVE_CUSTOMER_LAST_NAME))+closeQuotation+"}"+","+
				openQuotation+"sno"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.INCENTIVE_SNO))+closeQuotation+"}"+"]}";
		
		
		}
		
	else if("Payment".equals(jsonType)){
		//[{"Payment":{"id":"52","title":"","user_id":"1","payment_mode":"Other","bank_id":"1","depot_id":"3","brand_id":"1","distributor_id":"3",
		//"amount":"23","payment_ref":"Asdf ","transaction_id":"null","payment_date":"2014-02-23","notes":"adsADASD","created":"2014-02-22 21:32:33",
		//"modified":"2014-02-22 21:32:33"},"User":{"first_name":"System","last_name":"Admin"},"Bank":{"id":"1","name":"Access Bank"},"sno":1}
		
		
		customerJsonData=	 curlyBraseOpen+openQuotation+"data"+closeQuotation+":["+curlyBraseOpen+openQuotation+"Payment"+closeQuotation+":"+curlyBraseOpen+
			     openQuotation+"id"+closeQuotation+":"+openQuotation+ cursor.getString(cursor.getColumnIndex(MySQLiteHelper.PAYMENT_ID))+closeQuotation+
			 ","+openQuotation+"title"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.PAYMENT_TITLE))+closeQuotation+
			 ","+openQuotation+"payment_mode"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.PAYMENT_PAYMENT_MODE))+closeQuotation+
			 ","+openQuotation+"bank_id"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.PAYMENT_BANK_ID))+closeQuotation+
			 ","+openQuotation+"depot_id"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.PAYMENT_DEPOT_ID))+closeQuotation+
			 ","+openQuotation+"brand_id"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.PAYMENT_BRAND_ID))+closeQuotation+
			 ","+openQuotation+"distributor_id"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.PAYMENT_DISTRIBUTOR_ID))+closeQuotation+
			 ","+openQuotation+"amount"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.PAYMENT_AMOUNT))+closeQuotation+
			 ","+openQuotation+"payment_ref"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.PAYMENT_PAYMENT_REF))+closeQuotation+
			 ","+openQuotation+"transaction_id"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.PAYMENT_TRANSACTION_ID))+closeQuotation+
			 ","+openQuotation+"payment_date"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.PAYMENT_PAYMENT_DATE))+closeQuotation+
			 ","+openQuotation+"notes"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.PAYMENT_NOTES))+closeQuotation+
			 ","+openQuotation+"created"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.PAYMENT_CREATED))+closeQuotation+
			 ","+openQuotation+"modified"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.PAYMENT_MODIFIED))+closeQuotation+"}"+","+
			 
			 openQuotation+"User"+closeQuotation+":"+"{"+
			 openQuotation+"first_name"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.PAYMENT_USER_FIRST_NAME))+closeQuotation+
			 ","+openQuotation+"last_name"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.PAYMENT_USER_LAST_NAME))+closeQuotation+"}"+","+
			 
			 openQuotation+"Bank"+closeQuotation+":"+"{"+
			 openQuotation+"id"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.PAYMENT_BANK_BANK_ID))+closeQuotation+
			 ","+openQuotation+"name"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.PAYMENT_BANK_NAME))+closeQuotation+"}"+","+
			 openQuotation+"sno"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.PAYMENT_SNO))+closeQuotation+"}"+"]}";
		
		}
		
	else if("Expence".equals(jsonType)){
		
		
		//[{"Expense":{"id":"57","title":"","depot_id":"3","brand_id":"1","user_id":"1",
		//"exp_amount":"36.00","exp_date":"2014-02-23","payment_mode":"","expense_ref":"Aggdafga ",
		//"description":"fgsdgdf ","exp_type_id":"1","created":"2014-02-22 22:00:00",
		//"modified":"2014-02-22 22:00:00"},"User":{"first_name":"System","last_name":"Admin"},/
		//"ExpType":{"id":"1","name":"Office Furniture","category_id":"1"},"sno":1},
		
		customerJsonData=	 curlyBraseOpen+openQuotation+"data"+closeQuotation+":["+curlyBraseOpen+openQuotation+"Expense"+closeQuotation+":"+curlyBraseOpen+
			     openQuotation+"id"+closeQuotation+":"+openQuotation+ cursor.getString(cursor.getColumnIndex(MySQLiteHelper.EXPENSE_ID))+closeQuotation+
			 ","+openQuotation+"title"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.EXPENSE_TITLE))+closeQuotation+
			 ","+openQuotation+"depot_id"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.EXPENSE_DEPOT_ID))+closeQuotation+
			 ","+openQuotation+"brand_id"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.EXPENSE_BRAND_ID))+closeQuotation+
			 ","+openQuotation+"user_id"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.EXPENSE_USER_ID))+closeQuotation+
			
			 ","+openQuotation+"exp_amount"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.EXPENSE_EXP_AMOUNT))+closeQuotation+	
			
			 ","+openQuotation+"exp_date"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.EXPENSE_EXP_DATA))+closeQuotation+	
			 ","+openQuotation+"payment_mode"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.EXPENSE_PAYMENT_MODE))+closeQuotation+	
			 ","+openQuotation+"expense_ref"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.EXPENSE_REF))+closeQuotation+	
			 ","+openQuotation+"description"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.EXPENSE_DESCRIPTION))+closeQuotation+
			 
			 
			 ","+openQuotation+"exp_type_id"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.EXPENSE_TYPE_ID))+closeQuotation+
			 
			 ","+openQuotation+"created"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.EXPENSE_CREATE))+closeQuotation+
			 ","+openQuotation+"modified"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.EXPENSE_MODIFIED))+closeQuotation+"}"+","+
			
			 openQuotation+"User"+closeQuotation+":"+"{"+
			 openQuotation+"first_name"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.EXPENSE_USER_FIRST_NAME))+closeQuotation+
			 ","+openQuotation+"last_name"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.EXPENSE_USER_LAST_NAME))+closeQuotation+"}"+","+
			 
		
 				   openQuotation+"ExpType"+closeQuotation+":"+"{"+
 					openQuotation+"id"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.EXPENSE_EXPTYPE_ID))+closeQuotation+
 					","+openQuotation+"name"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.EXPENSE_NAME))+closeQuotation+
 					
 					","+openQuotation+"category_id"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.EXPENSE_CATEGORY_ID))+closeQuotation+"}"+","+
 					openQuotation+"sno"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.EXPENSE_SNO))+closeQuotation+"}"+"]}";
		
		
		
	}
		
	else if("Compaign".equals(jsonType)){
		
		
		
		
		 customerJsonData=curlyBraseOpen+openQuotation+"data"+closeQuotation+":"+curlyBraseOpen+openQuotation+"assignTo"+closeQuotation+":"+curlyBraseOpen+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.USER_ID))+
					closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.FIRST_NAME))+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.LAST_NAME))+closeQuotation+curlyBraseClose+","+openQuotation+
					"User"+closeQuotation+":"+curlyBraseOpen+openQuotation+"last_name"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.LAST_NAME))+closeQuotation+","+openQuotation+"id"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.USER_ID))+closeQuotation+","+openQuotation+"first_name"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.FIRST_NAME))+closeQuotation+curlyBraseClose
					+","+openQuotation+"Customer"+closeQuotation+":"+"{"+openQuotation+"view_details"+closeQuotation+":"+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.VIEW_DETAILS))+
					","+openQuotation+"phone"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.PHONE))+closeQuotation+","
					+openQuotation+"status"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.STATUS))+closeQuotation+","
					+openQuotation+"depot_id"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.DEPOT_ID))+closeQuotation+","
					+openQuotation+"zipcode"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.ZIPCODE))+closeQuotation+","
					+openQuotation+"region_id"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.REGION_ID))+closeQuotation+","
					+openQuotation+"city"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CITY))+closeQuotation+","
					+openQuotation+"amount"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.AMOUNT))+closeQuotation+","
					+openQuotation+"id"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CUSTOMER_ID))+closeQuotation+","
					+openQuotation+"status_id"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.STATE_ID))+closeQuotation+","
					+openQuotation+"first_name"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.FIRST_NAME))+closeQuotation+","
					+openQuotation+"address"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.ADDRESS))+closeQuotation+","
					+openQuotation+"email"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.EMAIL_ID))+closeQuotation+","
					+openQuotation+"description"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.DESCRIPTION))+closeQuotation+","
					+openQuotation+"last_name"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.LAST_NAME))+closeQuotation+","
					+openQuotation+"image_path"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.IMAGE_PATH))+closeQuotation+","
					+openQuotation+"user_id"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.USER_ID))+closeQuotation+","
					+openQuotation+"longitude"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.LONGITUDE))+closeQuotation+","
					+openQuotation+"latitude"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.LONGITUDE))+closeQuotation+","
					+openQuotation+"lg_area_id"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.LGAREA_ID))+closeQuotation
					+curlyBraseClose+","+openQuotation+"Depot"+closeQuotation+":"+curlyBraseOpen
					+openQuotation+"id"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.DEPOT_ID))+closeQuotation+","
					+openQuotation+"title"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.DEPOT))+closeQuotation+curlyBraseClose
					+
					","+openQuotation+"LgArea"+closeQuotation+":"+curlyBraseOpen
					+openQuotation+"id"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.LGAREA_ID))+closeQuotation+","
					+openQuotation+"name"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.LGAREA))+closeQuotation+curlyBraseClose
					+
					","+openQuotation+"sno"+closeQuotation+":"+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.SNO))+","
					
					+openQuotation+"Region"+closeQuotation+":"+curlyBraseOpen
					+openQuotation+"id"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.REGION_ID))+closeQuotation+","
					+openQuotation+"title"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.REGION))+closeQuotation+curlyBraseClose		
					+
					","+openQuotation+"State"+closeQuotation+":"+curlyBraseOpen
					+openQuotation+"state"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.STATE))+closeQuotation+","
					+openQuotation+"name"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.STATE_ID))+closeQuotation+curlyBraseClose
					+"}}"
					;
	}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		 else{	
			 
			 customerJsonData=	 curlyBraseOpen+openQuotation+"data"+closeQuotation+":["+curlyBraseOpen+openQuotation+"CustomerVisit"+closeQuotation+":"+curlyBraseOpen+
					     openQuotation+"id"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CUSTOMER_VISIT_ID))+closeQuotation+
					 ","+openQuotation+"user_id"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CUSTOMER_VISIT_USERID))+closeQuotation+
					 ","+openQuotation+"customer_id"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CUSTOMER_VISIT_CUSTOMERID))+closeQuotation+
					 ","+openQuotation+"visiting_date"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CUSTOMER_VISIT_VISITING_DATE))+closeQuotation+
					 ","+openQuotation+"comment"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CUSTOMER_VISIT_COMMENT))+closeQuotation+
					 ","+openQuotation+"depot_id"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CUSTOMER_VISIT_DEPOTID))+closeQuotation+
					 ","+openQuotation+"lg_area_id"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CUSTOMER_VISIT_LGAREAIF))+closeQuotation+
			 
					 ","+openQuotation+"created"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CREATED_DATE))+closeQuotation+
					 
					 ","+openQuotation+"modified"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CUSTOMER_VISIT_MODIFIED))+closeQuotation+
					 ","+openQuotation+"latitude"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CUSTOMER_VISIT_CVLATITUDE))+closeQuotation+
					 ","+openQuotation+"longitude"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CUSTOMER_VISIT_CVLONGITUDE))+closeQuotation+"}"+","
					 +openQuotation+"User"+closeQuotation+":"+curlyBraseOpen
						+openQuotation+"first_name"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CUSTOMER_VISIT_USERFIRSTNAME))+closeQuotation+
					","+openQuotation+"last_name"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CUSTOMER_VISIT_USERLASTNAME))+closeQuotation+curlyBraseClose+
				","+openQuotation+"Customer"+closeQuotation+":"+"{"+openQuotation+"first_name"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CUSTOMER_VISIT_CUSTOMERFIRSTNAME))+closeQuotation+
				","+  openQuotation+"last_name"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CUSTOMER_VISIT_CUSTOMERLASTNAME))+closeQuotation+"}"+","
				+
				openQuotation+"Depot"+closeQuotation+":"+"{"+openQuotation+"id"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CUSTOMER_VISIT_DEPOTID))+closeQuotation+
				","+  openQuotation+"name"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CUSTOMER_VISIT_STATE_STATE_NAME))+closeQuotation+
				"}"+","
				+
				openQuotation+"State"+closeQuotation+":"+"{"+openQuotation+"id"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CUSTOMER_VISIT_STATE_STATE_ID))+closeQuotation+
				","+  openQuotation+"title"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CUSTOMER_VISIT_DEPOTTITLE))+closeQuotation+","+
				openQuotation+"region_id"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CUSTOMER_VISIT_LGAREAID))+closeQuotation+"}"+","
				
				+
				openQuotation+"LgArea"+closeQuotation+":"+"{"+openQuotation+"id"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CUSTOMER_VISIT_LGAREAID))+closeQuotation+","
				+openQuotation+"name"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CUSTOMER_VISIT_LGAREANAME))+closeQuotation+","
				+openQuotation+"state_id"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CUSTOMER_VISIT_STATEID))+closeQuotation+"},"+
				openQuotation+"sno"+closeQuotation+":"+openQuotation+cursor.getString(cursor.getColumnIndex(MySQLiteHelper.CUSTOMER_VISIT_SNO))+closeQuotation+"}"+"]}";
		 }
		
		
		}
		catch(Exception e){
			e.printStackTrace();
			//"State":{"id":null,"state":null,"country_id":null}
		}
		
		
		
		
		return customerJsonData;
	}

}
