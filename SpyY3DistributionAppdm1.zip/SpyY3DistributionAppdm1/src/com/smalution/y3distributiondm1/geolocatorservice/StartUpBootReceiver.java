package com.smalution.y3distributiondm1.geolocatorservice;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

public class StartUpBootReceiver  extends BroadcastReceiver 
{
    @Override
    public void onReceive(Context context, Intent intent) 
    {
        if (Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) 
        {
            Log.d("startuptest", "StartUpBootReceiver BOOT_COMPLETED");
            Intent intent1 = new Intent(context, GPSTrackerService.class);
            context.startService(intent1);
            
            Intent intent2 = new Intent(context, deviceLog.class);
            context.startService(intent2);            
            
        }
    }
}