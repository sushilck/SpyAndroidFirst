package com.smalution.y3distributionzb1.entities.settings;


import java.util.ArrayList;

import org.json.JSONArray;

import com.smalution.y3distributionzb1.entities.customer.CustDepot;
import com.smalution.y3distributionzb1.entities.customer.CustRegion;
import com.smalution.y3distributionzb1.utils.Constants;

public class ActiveCompaignManager 
{
	ArrayList<ActiveCompaigns> compaignList;
	public ActiveCompaignManager(){}
	public ActiveCompaignManager(JSONArray jsonArray)
	{
		try
		{
			compaignList =new ArrayList<ActiveCompaigns>();
			for(int i=0;i<jsonArray.length();i++)
			{
				compaignList.add(new ActiveCompaigns(jsonArray.getJSONObject(i)));
			}
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	public ArrayList<ActiveCompaigns> getQualifyingCompaign(String depotId, String regionId)
	{
		ArrayList<ActiveCompaigns> qualifyingCompaignList=new ArrayList<ActiveCompaigns>();
		for(ActiveCompaigns activeCompaigns:getCompaignList())
		{
			boolean isExistInDepotFlag=false;
			for(ACDepot aCDepot:activeCompaigns.getDepot())
			{
				if(aCDepot.getId().equals(depotId))
				{
					isExistInDepotFlag=true;
					break;
				}
			}
			if(isExistInDepotFlag)
			{
				boolean isExistInRegionFlag=false;
				for(ACRegion aCRegion:activeCompaigns.getRegion())
				{
					if(aCRegion.getId().equals(regionId))
					{
						isExistInRegionFlag=true;
						break;
					}
				}
				if(isExistInDepotFlag && isExistInRegionFlag)
				{
					qualifyingCompaignList.add(activeCompaigns);
				}
			}
		}
		return qualifyingCompaignList;
	}
	public ArrayList<ActiveCompaigns> getCompaignList() {
		return compaignList;
	}
	public void setCompaignList(ArrayList<ActiveCompaigns> compaignList) {
		this.compaignList = compaignList;
	}
	
}
