package com.smalution.y3distributionzb1.entities.settings;

import java.util.ArrayList;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONObject;

public class Regions 
{
	ArrayList<SelectionButtonItem> regions;
	String regionNames[];
	public Regions(){}
	public Regions(JSONArray jsonArray)
	{
		try
		{
			regions=new ArrayList<SelectionButtonItem>();
			regionNames=new String[jsonArray.length()];
			if(jsonArray!=null)
			{
				for(int i=0;i<jsonArray.length();i++)
				{
					JSONObject jsonObject = jsonArray.getJSONObject(i);
					String id=jsonObject.isNull("id")?"":jsonObject.getString("id");
					String value=jsonObject.isNull("value")?"":jsonObject.getString("value");
					SelectionButtonItem itm=new SelectionButtonItem(id,"",value);
					regions.add(itm);
					regionNames[i]=itm.getTitle();
				}
			}
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	public String getDepotNameById(String id)
	{
		for(SelectionButtonItem itm:regions)
		{
			if(itm.getId().equals(id))
				return itm.getTitle();
		}
		return null;
	}
	public SelectionButtonItem getItem(int position)
	{
		return regions.get(position);
	} 
	public String[] getRegionNames() {
		return regionNames;
	}
	public void setRegionNames(String[] regionNames) {
		this.regionNames = regionNames;
	}
}
