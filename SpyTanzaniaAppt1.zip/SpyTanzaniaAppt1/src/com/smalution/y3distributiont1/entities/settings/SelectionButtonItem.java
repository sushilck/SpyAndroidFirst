package com.smalution.y3distributiont1.entities.settings;

public class SelectionButtonItem implements Comparable<SelectionButtonItem>
{
	String id;
	String objectId;
	String title;
	String objectValue1;
	String objectValue2;
	public SelectionButtonItem(String id, String objectId, String title)
	{
		this.id=id;
		this.objectId=objectId;
		this.title=title;
	}
	public SelectionButtonItem(String id, String objectId, String title, String objValue1, String objValue2)
	{
		this.id=id;
		this.objectId=objectId;
		this.title=title;
		this.objectValue1=objValue1;
		this.objectValue2=objValue2;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getObjectId() {
		return objectId;
	}
	public void setObjectId(String objectId) {
		this.objectId = objectId;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	@Override
	public int compareTo(SelectionButtonItem otherItem) 
	{
		int res = String.CASE_INSENSITIVE_ORDER.compare(this.title, otherItem.title);
		return (res != 0) ? res : this.title.compareTo(otherItem.title);
	}
	
	public void setObjectValue1(String val1){
		this.objectValue1 = val1;
	}
	
	public String getObjectValue1(){
		return this.objectValue1;
	}
	
	public void setObjectValue2(String val2){
		this.objectValue1 = val2;
	}
	
	public String getObjectValue2(){
		return this.objectValue2;
	}
}
