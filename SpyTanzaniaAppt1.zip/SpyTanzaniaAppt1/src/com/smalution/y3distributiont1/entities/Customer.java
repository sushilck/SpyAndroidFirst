package com.smalution.y3distributiont1.entities;

import android.os.Parcel;
import android.os.Parcelable;

public class Customer implements Parcelable
{
	private String serialNo;
	private String photo;
	private String firstName;
	private String lastName;
	private String email;
	private String addedBy;
	private String state;
	private String lga;
	private String region;
	private String depot;
	private String created;
	private String address;
	private String contact;
	
	public Customer(){}
	
	public Customer(Parcel in)
 	{
		serialNo = in.readString();
		photo = in.readString();
		firstName = in.readString();
		lastName = in.readString();
		email = in.readString();
		addedBy = in.readString();
		state = in.readString();
		lga = in.readString();
		region = in.readString();
		depot = in.readString();
		created = in.readString();
		address = in.readString();
		contact = in.readString();
	}
 	@Override
 	public int describeContents() 
 	{
 		return 0;
 	}
 	@Override
 	public void writeToParcel(Parcel dest, int flags) 
 	{
 		dest.writeString(serialNo);
 		dest.writeString(photo);
 		dest.writeString(firstName);
 		dest.writeString(lastName);
 		dest.writeString(email);
 		dest.writeString(addedBy);
 		dest.writeString(state);
 		dest.writeString(lga);
 		dest.writeString(region);
 		dest.writeString(depot);
 		dest.writeString(created);
 		dest.writeString(address);
 		dest.writeString(contact);
	}
 	

	public static final Parcelable.Creator<Customer> CREATOR = new Parcelable.Creator<Customer>() 
 	{
 		public Customer createFromParcel(Parcel in) 
 		{
 			return new Customer(in);
 		}
 	
 		public Customer[] newArray (int size) 
 		{
 			return new Customer[size];
 		}
 	};

	public String getSerialNo() {
		return serialNo;
	}

	public void setSerialNo(String serialNo) {
		this.serialNo = serialNo;
	}

	public String getPhoto() {
		return photo;
	}

	public void setPhoto(String photo) {
		this.photo = photo;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getAddedBy() {
		return addedBy;
	}

	public void setAddedBy(String addedBy) {
		this.addedBy = addedBy;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getLga() {
		return lga;
	}

	public void setLga(String lga) {
		this.lga = lga;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public String getDepot() {
		return depot;
	}

	public void setDepot(String depot) {
		this.depot = depot;
	}

	public String getCreated() {
		return created;
	}

	public void setCreated(String created) {
		this.created = created;
	}
	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}
	
	public String getContact() {
		return contact;
	}

	public void setContact(String contact) {
		this.contact = contact;
	}
 	
}
