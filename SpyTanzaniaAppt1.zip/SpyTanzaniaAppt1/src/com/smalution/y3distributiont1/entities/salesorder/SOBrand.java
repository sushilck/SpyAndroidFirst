package com.smalution.y3distributiont1.entities.salesorder;

import org.json.JSONObject;

import android.os.Parcel;
import android.os.Parcelable;

public class SOBrand implements Parcelable
{
	private String pack_price;
    private String rd_2pack_price;
    private String pack_sticks;
    private String rd_roll_price;
    private String pack2_pack;
    private String status;
    private String case_price;
    private String rd_case_price;
    private String modified;
    private String roll_pack;
    private String roll_price;
    private String id;
    private String pack2_price;
    private String created;
    private String rd_pack_price;
    private String description;
    private String name;
    private String case_roll;
    private String user_id;
    
	public SOBrand(){}
	public SOBrand(JSONObject jsonObect)
	{
		try
		{
			pack_price=jsonObect.isNull("pack_price")?"":jsonObect.getString("pack_price");
		    rd_2pack_price=jsonObect.isNull("rd_2pack_price")?"":jsonObect.getString("rd_2pack_price");
		    pack_sticks=jsonObect.isNull("pack_sticks")?"":jsonObect.getString("pack_sticks");
		    rd_roll_price=jsonObect.isNull("rd_roll_price")?"":jsonObect.getString("rd_roll_price");
		    pack2_pack=jsonObect.isNull("2pack_pack")?"":jsonObect.getString("2pack_pack");
		    status=jsonObect.isNull("status")?"":jsonObect.getString("status");
		    case_price=jsonObect.isNull("case_price")?"":jsonObect.getString("case_price");
		    rd_case_price=jsonObect.isNull("rd_case_price")?"":jsonObect.getString("rd_case_price");
		    modified=jsonObect.isNull("modified")?"":jsonObect.getString("modified");
		    roll_pack=jsonObect.isNull("roll_pack")?"":jsonObect.getString("roll_pack");
		    roll_price=jsonObect.isNull("roll_price")?"":jsonObect.getString("roll_price");
		    id=jsonObect.isNull("id")?"":jsonObect.getString("id");
		    pack2_price=jsonObect.isNull("2pack_price")?"":jsonObect.getString("2pack_price");
		    created=jsonObect.isNull("created")?"":jsonObect.getString("created");
		    rd_pack_price=jsonObect.isNull("rd_pack_price")?"":jsonObect.getString("rd_pack_price");
		    description=jsonObect.isNull("description")?"":jsonObect.getString("description");
		    name=jsonObect.isNull("name")?"":jsonObect.getString("name");
		    case_roll=jsonObect.isNull("case_roll")?"":jsonObect.getString("case_roll");
		    user_id=jsonObect.isNull("user_id")?"":jsonObect.getString("user_id");
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	public SOBrand(Parcel in)
 	{
		pack_price = in.readString();
	    rd_2pack_price = in.readString();
	    pack_sticks = in.readString();
	    rd_roll_price = in.readString();
	    pack2_pack = in.readString();
	    status = in.readString();
	    case_price = in.readString();
	    rd_case_price = in.readString();
	    modified = in.readString();
	    roll_pack = in.readString();
	    roll_price = in.readString();
	    id = in.readString();
	    pack2_price = in.readString();
	    created = in.readString();
	    rd_pack_price = in.readString();
	    description = in.readString();
	    name = in.readString();
	    case_roll = in.readString();
	    user_id = in.readString();
	}
 	@Override
 	public int describeContents() 
 	{
 		return 0;
 	}
 	@Override
 	public void writeToParcel(Parcel dest, int flags) 
 	{
 		dest.writeString(pack_price);
 	    dest.writeString(rd_2pack_price);
 	    dest.writeString(pack_sticks);
 	    dest.writeString(rd_roll_price);
 	    dest.writeString(pack2_pack);
 	    dest.writeString(status);
 	    dest.writeString(case_price);
 	    dest.writeString(rd_case_price);
 	    dest.writeString(modified);
 	    dest.writeString(roll_pack);
 	    dest.writeString(roll_price);
 	    dest.writeString(id);
 	    dest.writeString(pack2_price);
 	    dest.writeString(created);
 	    dest.writeString(rd_pack_price);
 	    dest.writeString(description);
 	    dest.writeString(name);
 	    dest.writeString(case_roll);
 	    dest.writeString(user_id);
 	}
 	public static final Parcelable.Creator<SOBrand> CREATOR = new Parcelable.Creator<SOBrand>() 
 	{
 		public SOBrand createFromParcel(Parcel in) 
 		{
 			return new SOBrand(in);
 		}
 	
 		public SOBrand[] newArray (int size) 
 		{
 			return new SOBrand[size];
 		}
 	};

	public String getPack_price() {
		return pack_price;
	}
	public void setPack_price(String pack_price) {
		this.pack_price = pack_price;
	}
	public String getRd_2pack_price() {
		return rd_2pack_price;
	}
	public void setRd_2pack_price(String rd_2pack_price) {
		this.rd_2pack_price = rd_2pack_price;
	}
	public String getPack_sticks() {
		return pack_sticks;
	}
	public void setPack_sticks(String pack_sticks) {
		this.pack_sticks = pack_sticks;
	}
	public String getRd_roll_price() {
		return rd_roll_price;
	}
	public void setRd_roll_price(String rd_roll_price) {
		this.rd_roll_price = rd_roll_price;
	}
	public String getPack2_pack() {
		return pack2_pack;
	}
	public void setPack2_pack(String pack2_pack) {
		this.pack2_pack = pack2_pack;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getCase_price() {
		return case_price;
	}
	public void setCase_price(String case_price) {
		this.case_price = case_price;
	}
	public String getRd_case_price() {
		return rd_case_price;
	}
	public void setRd_case_price(String rd_case_price) {
		this.rd_case_price = rd_case_price;
	}
	public String getModified() {
		return modified;
	}
	public void setModified(String modified) {
		this.modified = modified;
	}
	public String getRoll_pack() {
		return roll_pack;
	}
	public void setRoll_pack(String roll_pack) {
		this.roll_pack = roll_pack;
	}
	public String getRoll_price() {
		return roll_price;
	}
	public void setRoll_price(String roll_price) {
		this.roll_price = roll_price;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPack2_price() {
		return pack2_price;
	}
	public void setPack2_price(String pack2_price) {
		this.pack2_price = pack2_price;
	}
	public String getCreated() {
		return created;
	}
	public void setCreated(String created) {
		this.created = created;
	}
	public String getRd_pack_price() {
		return rd_pack_price;
	}
	public void setRd_pack_price(String rd_pack_price) {
		this.rd_pack_price = rd_pack_price;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCase_roll() {
		return case_roll;
	}
	public void setCase_roll(String case_roll) {
		this.case_roll = case_roll;
	}
	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	
}
