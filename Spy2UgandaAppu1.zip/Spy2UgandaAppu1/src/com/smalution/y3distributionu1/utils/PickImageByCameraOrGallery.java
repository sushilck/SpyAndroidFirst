package com.smalution.y3distributionu1.utils;

import java.io.File;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.v4.app.Fragment;
import android.widget.ArrayAdapter;
import android.widget.ImageView;

public class PickImageByCameraOrGallery 
{
	Fragment fragment;
	private Uri mImageCaptureUri;
	private static final int PICK_FROM_CAMERA = 1;
    private static final int PICK_FROM_FILE = 2;
    public PickImageByCameraOrGallery(Fragment fragment)
    {
    	this.fragment=fragment;
    }
    public void pickImage()
    {
    	final String [] items = new String [] {"From Camera", "From SD Card"};
        ArrayAdapter<String> adapter  = new ArrayAdapter<String> (fragment.getActivity(), android.R.layout.select_dialog_item,items);
        AlertDialog.Builder builder     = new AlertDialog.Builder(fragment.getActivity());
 
        builder.setTitle("Select Image");
        builder.setAdapter( adapter, new DialogInterface.OnClickListener() 
        {
            public void onClick( DialogInterface dialog, int item ) 
            {
            	if (item == 0) 
            	{
                    Intent intent    = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
                    File file        = new File(Environment.getExternalStorageDirectory(),
                                       "tmp_avatar_" + String.valueOf(System.currentTimeMillis()) + ".jpg");
                    mImageCaptureUri = Uri.fromFile(file);
                    try 
                    {
                        intent.putExtra(android.provider.MediaStore.EXTRA_OUTPUT, mImageCaptureUri);
                        intent.putExtra("return-data", true);
                        fragment.startActivityForResult(intent, PICK_FROM_CAMERA);
                    } 
                    catch (Exception e) 
                    {
                        e.printStackTrace();
                    }
                    dialog.cancel();
                } 
            	else 
                {
                    Intent intent = new Intent();
                    intent.setType("image/*");
                    intent.setAction(Intent.ACTION_GET_CONTENT);
                    fragment.startActivityForResult(Intent.createChooser(intent, "Complete action using"), PICK_FROM_FILE);
                }
            }
        });
        final AlertDialog dialog = builder.create();
        dialog.show();
    }
    public void onActivityResult(int requestCode, int resultCode, Intent intent, ImageView mImageView)
    {
    	if (resultCode != Activity.RESULT_OK) 
    		return;
    	
    	Bitmap bitmap   = null;
        String path     = "";
        if (requestCode == PICK_FROM_FILE) 
        {
            mImageCaptureUri = intent.getData();
            path = getRealPathFromURI(mImageCaptureUri); //from Gallery
            if (path == null)
                path = mImageCaptureUri.getPath(); //from File Manager
        } 
        else 
        {
            path    = mImageCaptureUri.getPath();
        }
        if (path != null)
        {
        	//bitmap  = BitmapFactory.decodeFile(path);
        	try
        	{
        		Bitmap thumbnail = MediaStore.Images.Media.getBitmap(fragment.getActivity().getContentResolver(), mImageCaptureUri);
        		mImageView.setImageBitmap(thumbnail);
        	}
        	catch(Exception ex)
        	{
        		ex.printStackTrace();
        	}
        	
//        	bitmap  = ImageProcessUtility.decodeImageFileByDeviceHeightWidth(fragment.getActivity(), path);
        	
        	mImageView.setTag(path);
        }
    }
    public String getRealPathFromURI(Uri contentUri) 
    {
        String [] proj      = {MediaStore.Images.Media.DATA};
        Cursor cursor       = fragment.getActivity().managedQuery( contentUri, proj, null, null,null);
        if (cursor == null) 
        {
        	return null;
        }
        int column_index    = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
        cursor.moveToFirst();
        return cursor.getString(column_index);
    }
}
