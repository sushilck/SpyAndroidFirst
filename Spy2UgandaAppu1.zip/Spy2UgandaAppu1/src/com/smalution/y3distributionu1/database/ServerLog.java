package com.smalution.y3distributionu1.database;

import android.os.Parcel;
import android.os.Parcelable;

public class ServerLog implements Parcelable
{
	private long _id;
	private String action;
	private String json;
	private String image;
	private String status;
	private String serverlog;
	private String serverlogdetail;
	
public ServerLog(){}
	
	public ServerLog(Parcel in)
 	{
		_id = in.readLong();
		action = in.readString();
		json = in.readString();
		image = in.readString();
		status = in.readString();
		serverlog = in.readString();
		serverlogdetail = in.readString();
	}
 	@Override
 	public int describeContents() 
 	{
 		return 0;
 	}
 	@Override
 	public void writeToParcel(Parcel dest, int flags) 
 	{
 		dest.writeLong(_id);
 		dest.writeString(action);
 		dest.writeString(json);
 		dest.writeString(image);
 		dest.writeString(status);
 		dest.writeString(serverlog);
 		dest.writeString(serverlogdetail);
	}
 	public static final Parcelable.Creator<ServerLog> CREATOR = new Parcelable.Creator<ServerLog>() 
 	{
 		public ServerLog createFromParcel(Parcel in) 
 		{
 			return new ServerLog(in);
 		}
 		public ServerLog[] newArray (int size) 
 		{
 			return new ServerLog[size];
 		}
 	};
	
 	public long get_id() {
		return _id;
	}
	public void set_id(long _id) {
		this._id = _id;
	}
	public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}
	public String getJson() {
		return json;
	}
	public void setJson(String json) {
		this.json = json;
	}
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getServerlog() {
		return serverlog;
	}
	public void setServerlog(String serverlog) {
		this.serverlog = serverlog;
	}
	public String getServerlogdetail() {
		return serverlogdetail;
	}
	public void setServerlogdetail(String serverlogdetail) {
		this.serverlogdetail = serverlogdetail;
	}
	
	
}
