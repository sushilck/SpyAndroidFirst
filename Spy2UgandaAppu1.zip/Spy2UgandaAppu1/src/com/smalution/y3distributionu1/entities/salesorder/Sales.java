package com.smalution.y3distributionu1.entities.salesorder;




import java.util.ArrayList;

import org.json.JSONObject;

import com.smalution.y3distributionu1.entities.customer.CustOfflineData;

import android.os.Parcel;
import android.os.Parcelable;

public class Sales implements Parcelable
{
	SOCustomer Customer;
	SOUser User;
	SODepot Depot;
	SOBrand Brand;
	SOSale Sale;
	
	public Sales()
	{
		Customer=new SOCustomer();
		User=new SOUser();
		Depot=new SODepot();
		Brand=new SOBrand();
		Sale=new SOSale();
		
	}
	public Sales(JSONObject jsonObject)
	{
		try
		{
			Customer=jsonObject.isNull("Customer")?null:new SOCustomer(jsonObject.getJSONObject("Customer"));
			User=jsonObject.isNull("User")?null:new SOUser(jsonObject.getJSONObject("User"));
			Depot=jsonObject.isNull("Depot")?null:new SODepot(jsonObject.getJSONObject("Depot"));
			Brand=jsonObject.isNull("Brand")?null:new SOBrand(jsonObject.getJSONObject("Brand"));
			Sale=jsonObject.isNull("Sale")?null:new SOSale(jsonObject.getJSONObject("Sale"));
			
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}

	public Sales(JSONObject jsonObject,String json)
	{
		try
		{
			//Customer=jsonObject.isNull("Customer")?null:new SOCustomer(jsonObject.getJSONObject("Customer"));
			//User=jsonObject.isNull("User")?null:new SOUser(jsonObject.getJSONObject("User"));
			//Depot=jsonObject.isNull("Depot")?null:new SODepot(jsonObject.getJSONObject("Depot"));
			//Brand=jsonObject.isNull("Brand")?null:new SOBrand(jsonObject.getJSONObject("Brand"));
			//{"depot_id":"3","brand_id":"4","order_id":"216","unit_price":"500.000","modified":"2014-03-18 16:34:21","id":"372","amount":"4500.000","unit":"2Pack","created":"2014-03-18 16:34:21","user_id":"97","quantity":"9.000","customer_id":"214","cal_qty":"0.000","sale_date":"2014-03-18"}
			Brand=jsonObject.isNull("Brand")?null:new SOBrand(jsonObject.getJSONObject("Brand"));
			Sale=new SOSale(jsonObject);
			
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	public Sales(JSONObject jsonObject,int dbCustomerId)
	{
		try
		{
			Customer=jsonObject.isNull("Customer")?null:new SOCustomer(jsonObject.getJSONObject("Customer"));
			User=jsonObject.isNull("User")?null:new SOUser(jsonObject.getJSONObject("User"));
			Depot=jsonObject.isNull("Depot")?null:new SODepot(jsonObject.getJSONObject("Depot"));
			Brand=jsonObject.isNull("Brand")?null:new SOBrand(jsonObject.getJSONObject("Brand"));
			Sale=jsonObject.isNull("Sale")?null:new SOSale(jsonObject.getJSONObject("Sale"));
			
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	public Sales(Parcel in)
 	{
		Customer=in.readParcelable(SOCustomer.class.getClassLoader());
		User=in.readParcelable(SOUser.class.getClassLoader());
		Depot=in.readParcelable(SODepot.class.getClassLoader());
		Brand=in.readParcelable(SOBrand.class.getClassLoader());
		Sale=in.readParcelable(SOSale.class.getClassLoader());
	}
 	@Override
 	public int describeContents() 
 	{
 		return 0;
 	}
 	@Override
 	public void writeToParcel(Parcel dest, int flags) 
 	{
 		dest.writeParcelable(Customer,flags);
 		dest.writeParcelable(User,flags);
 		dest.writeParcelable(Depot,flags);
 		dest.writeParcelable(Brand,flags);
 		dest.writeParcelable(Sale,flags);
	}
 	public static final Parcelable.Creator<Sales> CREATOR = new Parcelable.Creator<Sales>() 
 	{
 		public Sales createFromParcel(Parcel in) 
 		{
 			return new Sales(in);
 		}
 	
 		public Sales[] newArray (int size) 
 		{
 			return new Sales[size];
 		}
 	};
	public SOCustomer getCustomer() {
		return Customer;
	}
	public void setCustomer(SOCustomer customer) {
		Customer = customer;
	}
	public SOUser getUser() {
		return User;
	}
	public void setUser(SOUser user) {
		User = user;
	}
	public SODepot getDepot() {
		return Depot;
	}
	public void setDepot(SODepot depot) {
		Depot = depot;
	}
	public SOBrand getBrand() {
		return Brand;
	}
	public void setBrand(SOBrand brand) {
		Brand = brand;
	}
	public SOSale getSale() {
		return Sale;
	}
	public void setSale(SOSale sale) {
		Sale = sale;
	}
	
	
	
	
//	public String createJson(AQuery aq, boolean isForAddCustomer)
//	{
//		SharedPreferences prefs = AppManager.getInstance().getPrefs(aq.getContext());
//		String token = prefs.getString("token", null);
//		if(isForAddCustomer)
//		{
//			String json="{" +
//					"\"token\":\""+token+"\"," +
//					"\"first_name\":\""+getCustomer().getFirst_name()+"\"," +
//					"\"last_name\":\""+getCustomer().getLast_name()+"\"," +
//					"\"email\":\""+getCustomer().getEmail()+"\"," +
//					"\"address\":\""+getCustomer().getAddress()+"\"," +
//					"\"city\":\""+getCustomer().getCity()+"\"," +
//					"\"state_id\":\""+getCustomer().getState_id()+"\"," +
//					"\"latitude\":\""+getCustomer().getLatitude()+"\"," +
//					"\"longitude\":\""+getCustomer().getLongitude()+"\"," +
//					"\"zipcode\":\""+getCustomer().getZipcode()+"\"," +
//					"\"phone\":\""+getCustomer().getPhone()+"\"," +
//					"\"region_id\":\""+getCustomer().getRegion_id()+"\"," +
//					"\"depot_id\":\""+getCustomer().getDepot_id()+"\"," +
//					"\"lg_area_id\":\""+getCustomer().getLg_area_id()+"\"," +
//					"\"description\":\""+getCustomer().getDescription()+"\"," +
//					"\"view_details\":\""+getCustomer().getView_details()+"\"" +
//					"}";
//			return json;
//		}
//		else
//		{
//			String json="{" +
//					"\"token\":\""+token+"\"," +
//					"\"id\":\""+getCustomer().getId()+"\"," +
//					"\"oldFile_id\":\""+getCustomer().getFile_id()+"\"," +
//					"\"first_name\":\""+getCustomer().getFirst_name()+"\"," +
//					"\"last_name\":\""+getCustomer().getLast_name()+"\"," +
//					"\"email\":\""+getCustomer().getEmail()+"\"," +
//					"\"address\":\""+getCustomer().getAddress()+"\"," +
//					"\"city\":\""+getCustomer().getCity()+"\"," +
//					"\"state_id\":\""+getCustomer().getState_id()+"\"," +
//					"\"latitude\":\""+getCustomer().getLatitude()+"\"," +
//					"\"longitude\":\""+getCustomer().getLongitude()+"\"," +
//					"\"zipcode\":\""+getCustomer().getZipcode()+"\"," +
//					"\"phone\":\""+getCustomer().getPhone()+"\"," +
//					"\"region_id\":\""+getCustomer().getRegion_id()+"\"," +
//					"\"depot_id\":\""+getCustomer().getDepot_id()+"\"," +
//					"\"lg_area_id\":\""+getCustomer().getLg_area_id()+"\"," +
//					"\"description\":\""+getCustomer().getDescription()+"\"," +
//					"\"view_details\":\""+getCustomer().getView_details()+"\"" +
//					"}";
//			return json;
//		}
//		
//		
//	}
 	
 	
}
