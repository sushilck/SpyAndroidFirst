package com.smalution.y3distributionu1.entities.customer;

import org.json.JSONObject;

import android.os.Parcel;
import android.os.Parcelable;

public class CustRegion implements Parcelable
{
	private String id;
	private String title;
	public CustRegion(){}
	public CustRegion(JSONObject jsonObect)
	{
		try
		{
			id=jsonObect.isNull("id")?"":jsonObect.getString("id");
			title=jsonObect.isNull("title")?"":jsonObect.getString("title");
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	
	public CustRegion(Parcel in)
 	{
		id = in.readString();
		title = in.readString();
	}
 	@Override
 	public int describeContents() 
 	{
 		return 0;
 	}
 	@Override
 	public void writeToParcel(Parcel dest, int flags) 
 	{
 		dest.writeString(id);
 		dest.writeString(title);
	}
 	public static final Parcelable.Creator<CustRegion> CREATOR = new Parcelable.Creator<CustRegion>() 
 	{
 		public CustRegion createFromParcel(Parcel in) 
 		{
 			return new CustRegion(in);
 		}
 	
 		public CustRegion[] newArray (int size) 
 		{
 			return new CustRegion[size];
 		}
 	};
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
}
