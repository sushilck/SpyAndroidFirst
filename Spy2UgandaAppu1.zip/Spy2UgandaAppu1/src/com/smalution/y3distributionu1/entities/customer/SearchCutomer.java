package com.smalution.y3distributionu1.entities.customer;

import java.io.IOException;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.protocol.BasicHttpContext;
import org.apache.http.protocol.HttpContext;
import org.apache.http.util.EntityUtils;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Handler;
import android.os.Message;

import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.smalution.y3distributionu1.AppManager;
import com.smalution.y3distributionu1.R;
import com.smalution.y3distributionu1.database.Y3QueryDataSource;
import com.smalution.y3distributionu1.entities.settings.Customers;
import com.smalution.y3distributionu1.entities.settings.SelectionButtonItem;
import com.smalution.y3distributionu1.utils.Constants;

public class SearchCutomer {
	protected static String[] arr = null;
	public static ProgressDialog progressDialog;
	static Customers customers;
	static Context act_context;
	public static String errorCode = "0";
	public static String errorMessage="";
	public static void showAutosearchAlertDialog(final Context context,
			final Handler uiHandler, final int viewId) {
			act_context =  context;
			
			final AlertDialog.Builder customerSearch = new AlertDialog.Builder(context);
			
			customerSearch.setTitle("Customer Search");
						
			LayoutInflater inflater = LayoutInflater.from(context);
			View dialogview = inflater.inflate(R.layout.customersearch, null);
			final EditText input = (EditText) dialogview.findViewById(R.id.keyword);
			final ListView lv = (ListView) dialogview.findViewById(R.id.customerResult);
			
			//Find total available customer
			Y3QueryDataSource y3QueryDataSource = new Y3QueryDataSource(context);
			y3QueryDataSource.open();			
			int totalCustomer = y3QueryDataSource.totalCustomer();
			System.out.println(totalCustomer);
			TextView textView = (TextView) dialogview.findViewById(R.id.acCount);
			textView.setText(String.valueOf(totalCustomer));
			
			y3QueryDataSource.close();	
			
			OnItemClickListener itemClickListener = new OnItemClickListener() {
	            @Override
	            public void onItemClick(AdapterView<?> arg0, View arg1, int position, long id) {
	                //Toast.makeText(context, "You selected :" + position+ "Lond ID :"+id, Toast.LENGTH_SHORT).show();
	             }
	        };
	 
	        // Setting the item click listener for listView
	        lv.setOnItemClickListener(itemClickListener);
	        lv.setChoiceMode(ListView.CHOICE_MODE_SINGLE);
			
			input.addTextChangedListener(new TextWatcher() {
				public  void  afterTextChanged(Editable s) { 
				} 
				public  void  beforeTextChanged(CharSequence s, int  start, int  count, int  after) { 
				} 
				public  void  onTextChanged(CharSequence s, int  start, int  before, int  count) { 
				
					Y3QueryDataSource y3QueryDataSource = new Y3QueryDataSource(context);
					y3QueryDataSource.open();
					
					customers = y3QueryDataSource.searchCustomer((String) s.toString());				
					y3QueryDataSource.close();	
					
					if (customers != null){
						arr = customers.getCustomerNamesArr();
						
						ArrayAdapter<String> adapter = new ArrayAdapter<String>(context, android.R.layout.select_dialog_singlechoice, 
								arr);
						adapter.notifyDataSetChanged();
						lv.setAdapter(adapter);
					
					}
				} 
			});
			
			
			
			customerSearch.setNeutralButton(context.getString(R.string.load_more_customer), new DialogInterface.OnClickListener() {
				
				@Override
				public void onClick(DialogInterface dialog, int which) {
					// TODO Auto-generated method stub
					//getMoreCustomers.execute(null)
					/*
					final Handler handler = new Handler();
					mRunnable = new Runnable() {
						public void run() {							
							
						}
					};
					handler.postDelayed(mRunnable, 100);
					*/
					if (AppManager.isOnline(context)) {
						new getMoreCustomers().execute();
			        } else {
			        	Toast.makeText(context, context.getString(R.string.network_not_available) , Toast.LENGTH_LONG).show();
						return;
			        }
						
					
				}
				
				class getMoreCustomers extends AsyncTask<Void, Void, Void> {
					

					/*
					 * Function name: onPreExecute Parameters: Void params Return: void
					 */
					protected void onPreExecute() {

						// TODO Auto-generated method stub
						super.onPreExecute();
						
						progressDialog = new ProgressDialog(act_context);
				        progressDialog.setMessage(act_context.getString(R.string.wait_progress));
				        progressDialog.setCancelable(false);
				        progressDialog.setIndeterminate(true);
				        progressDialog.show();
				        progressDialog.setOnKeyListener(new DialogInterface.OnKeyListener() 
				        {
				            @Override
				            public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) 
				            {
				                return false;
				            }
				        });
					}

					
					@Override
					protected Void doInBackground(Void... params) {
						// TODO Auto-generated method stub
				
				        //Get min and max customerId
				    	Y3QueryDataSource y3QueryDataSource = new Y3QueryDataSource(act_context);
						y3QueryDataSource.open();
						JSONObject minMaxId = (JSONObject) y3QueryDataSource.minMaxCutomerId();				
						y3QueryDataSource.close();
						SharedPreferences myPrefs = act_context.getSharedPreferences("BGGeoCollector", act_context.MODE_PRIVATE);
						String token = myPrefs.getString("token", null);
						//System.out.println(minMaxId.toString());
				       // mDb = mDbManager.getReadableDatabase();
						JSONObject postJson = new JSONObject();
						try {
							postJson.putOpt("token", token);
							postJson.putOpt("customerIds", minMaxId);
						} catch (JSONException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
						
						
						if(minMaxId != null){
							
							try
							{
								HttpClient httpclient = new DefaultHttpClient();
								HttpContext httpContext = new BasicHttpContext();
								HttpPost httppost = new HttpPost(AppManager.getInstance().URL_GET_MORE_CUSTOMER);
								httppost.setHeader("jsonString", postJson.toString());
								httppost.getParams().setParameter("jsonString", postJson);
								
								StringEntity se = new StringEntity("jsonString="+ postJson.toString());
								httppost.addHeader("content-type",	"application/x-www-form-urlencoded");
								httppost.setEntity(se);
								//System.out.println("POSTURL : " + AppManager.getInstance().URL_GET_MORE_CUSTOMER);
								//System.out.println("josn data : " + postJson.toString());
								
								HttpResponse response = httpclient.execute(httppost,httpContext);
								
								if (response.getStatusLine().getStatusCode() == 200) {
									HttpEntity entity = response.getEntity();
									String json = EntityUtils.toString(entity);
																		
									try {
										JSONObject result = new JSONObject(json);										
										errorCode = result.isNull("error") ? "0" : result.getString("error");										
										if (errorCode.equals("2")){
											errorMessage = result.isNull("message") ? "": result.getString("message");						
											
										}else{
											JSONObject dataJSONObject = result.getJSONObject("data");
											String customers = dataJSONObject.isNull(Constants.PREFKEY_CUSTOMERS) ? "[]"
													: dataJSONObject.getJSONArray(Constants.PREFKEY_CUSTOMERS).toString();
											
											y3QueryDataSource.open();
											y3QueryDataSource.updateCustomerList(customers, false);				
											y3QueryDataSource.close();
										}
										
									} catch (JSONException e) {
										// TODO Auto-generated catch block
										e.printStackTrace();
									}
									//Log.e("response::", "" + json);
									progressDialog.dismiss();
								}
							
							} catch (ClientProtocolException e) {
								// TODO Auto-generated catch block
							} catch (IOException e) {
								// // TODO Auto-generated catch block
							}				
							
						}
						
						return null;
					}
					
					@Override
					protected void onPostExecute(Void result) {
						// TODO Auto-generated method stub
						super.onPostExecute(result);
						//progressDialog.dismiss();
						if(errorMessage != "" ){
							Toast.makeText(act_context, errorMessage, Toast.LENGTH_LONG).show();
						}
					}
				}
			});
			customerSearch.setPositiveButton(context.getString(R.string.OK), new DialogInterface.OnClickListener() {
				public void onClick(DialogInterface dialog, int whichButton) {
					
					if (lv.getCheckedItemCount() > 0){
						int selectedPosition = lv.getCheckedItemPosition();
						SelectionButtonItem customer = customers.getItem(selectedPosition);
						
						Message msg = new Message();
						msg.arg1 = viewId;
						msg.arg2 = Integer.parseInt(customer.getId());
						msg.obj = customer;
						uiHandler.sendMessage(msg);
						dialog.dismiss();
					}else{
						Toast.makeText(context, context.getString(R.string.search_key_customer_mess), Toast.LENGTH_SHORT).show();
						return;
					}
				}
			   });
			customerSearch.setView(dialogview);
			customerSearch.create();
			customerSearch.show();
		
	}
	
	
	
}





