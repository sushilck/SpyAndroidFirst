package com.smalution.y3distributionu1.entities.settings;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.json.JSONArray;
import org.json.JSONObject;

public class ExpenseTypeList 
{
	ArrayList<SelectionButtonItem> expenseType;
	String[] name;
	public ExpenseTypeList(){}
	public ExpenseTypeList(JSONArray jsonArray)
	{
		try
		{
			expenseType=new ArrayList<SelectionButtonItem>();
			name=new String[jsonArray.length()];
			for(int i=0;i<jsonArray.length();i++)
			{
				JSONObject jsonObject = jsonArray.getJSONObject(i); 
				String id=jsonObject.isNull("id")?"":jsonObject.getString("id");
				String value=jsonObject.isNull("value")?"":jsonObject.getString("value");
				SelectionButtonItem itm=new SelectionButtonItem(id, "", value);
				
				expenseType.add(itm);
				name[i]=itm.getTitle();
			}
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	public String getExpenseTypeNameById(String id)
	{
		for(SelectionButtonItem itm:expenseType)
		{
			if(itm.getId().equals(id))
				return itm.getTitle();
		}
		return null;
	}
	public SelectionButtonItem getItem(int position)
	{
		return expenseType.get(position);
	}
	public String[] getName() {
		return name;
	}
	public void setName(String[] name) {
		this.name = name;
	}
	
}
