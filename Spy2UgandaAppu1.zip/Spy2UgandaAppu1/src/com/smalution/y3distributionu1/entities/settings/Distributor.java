package com.smalution.y3distributionu1.entities.settings;

import org.json.JSONObject;

public class Distributor 
{
	private String id="";
	private String title="";
	private String state_id="";
	public Distributor(){}
	public Distributor(JSONObject jsonObect)
	{
		try
		{
			id=jsonObect.isNull("id")?"":jsonObect.getString("id");
			title=jsonObect.isNull("title")?"":jsonObect.getString("title");
			state_id=jsonObect.isNull("state_id")?"":jsonObect.getString("state_id");
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getState_id() {
		return state_id;
	}
	public void setState_id(String state_id) {
		this.state_id = state_id;
	}
	
}
