package com.smalution.y3distributionu1.entities.customervisits;


import org.json.JSONObject;

import com.androidquery.AQuery;
import com.smalution.y3distributionu1.AppManager;

import android.content.SharedPreferences;
import android.os.Parcel;
import android.os.Parcelable;

public class CustVisitCustomerVisit implements Parcelable
{

	private String id;
	private String created;
	private String depot_id;
	private String visiting_date;
	private String longitude;
	private String user_id;
	private String latitude;
	private String comment;
	private String lg_area_id;
	private String customer_id;
	private String modified;
	private String state_id;
	
	public CustVisitCustomerVisit(){}
	public CustVisitCustomerVisit(JSONObject jsonObect)
	{
		try
		{
			id=jsonObect.isNull("id")?"":jsonObect.getString("id");
			created=jsonObect.isNull("created")?"":jsonObect.getString("created");
			depot_id=jsonObect.isNull("depot_id")?"":jsonObect.getString("depot_id");
			visiting_date=jsonObect.isNull("visiting_date")?"":jsonObect.getString("visiting_date");
			longitude=jsonObect.isNull("longitude")?"":jsonObect.getString("longitude");
			user_id=jsonObect.isNull("user_id")?"":jsonObect.getString("user_id");
			latitude=jsonObect.isNull("latitude")?"":jsonObect.getString("latitude");
			comment=jsonObect.isNull("comment")?"":jsonObect.getString("comment");
			lg_area_id=jsonObect.isNull("lg_area_id")?"":jsonObect.getString("lg_area_id");
			customer_id=jsonObect.isNull("customer_id")?"":jsonObect.getString("customer_id");
			modified=jsonObect.isNull("modified")?"":jsonObect.getString("modified");
			state_id=jsonObect.isNull("state_id")?"":jsonObect.getString("state_id");
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	
	public CustVisitCustomerVisit(Parcel in)
 	{
		id = in.readString();
		created = in.readString();
		depot_id = in.readString();
		visiting_date = in.readString();
		longitude = in.readString();
		user_id = in.readString();
		latitude = in.readString();
		comment = in.readString();
		lg_area_id = in.readString();
		customer_id = in.readString();
		modified = in.readString();
		state_id=in.readString();
	}
 	@Override
 	public int describeContents() 
 	{
 		return 0;
 	}
 	@Override
 	public void writeToParcel(Parcel dest, int flags) 
 	{
 		dest.writeString(id);
 		dest.writeString(created);
 		dest.writeString(depot_id);
 		dest.writeString(visiting_date);
 		dest.writeString(longitude);
 		dest.writeString(user_id);
 		dest.writeString(latitude);
 		dest.writeString(comment);
 		dest.writeString(lg_area_id);
 		dest.writeString(customer_id);
 		dest.writeString(modified);
 		dest.writeString(state_id);
	}
 	public static final Parcelable.Creator<CustVisitCustomerVisit> CREATOR = new Parcelable.Creator<CustVisitCustomerVisit>() 
 	{
 		public CustVisitCustomerVisit createFromParcel(Parcel in) 
 		{
 			return new CustVisitCustomerVisit(in);
 		}
 	
 		public CustVisitCustomerVisit[] newArray (int size) 
 		{
 			return new CustVisitCustomerVisit[size];
 		}
 	};

	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getCreated() {
		return created;
	}
	public void setCreated(String created) {
		this.created = created;
	}
	public String getDepot_id() {
		return depot_id;
	}
	public void setDepot_id(String depot_id) {
		this.depot_id = depot_id;
	}
	public String getVisiting_date() {
		return visiting_date;
	}
	public void setVisiting_date(String visiting_date) {
		this.visiting_date = visiting_date;
	}
	public String getLongitude() {
		return longitude;
	}
	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}
	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	public String getLatitude() {
		return latitude;
	}
	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	public String getLg_area_id() {
		return lg_area_id;
	}
	public void setLg_area_id(String lg_area_id) {
		this.lg_area_id = lg_area_id;
	}
	public String getCustomer_id() {
		return customer_id;
	}
	public void setCustomer_id(String customer_id) {
		this.customer_id = customer_id;
	}
	public String getModified() {
		return modified;
	}
	public void setModified(String modified) {
		this.modified = modified;
	}
	public String getState_id() {
		return state_id;
	}
	public void setState_id(String state_id) {
		this.state_id = state_id;
	}
	
}
