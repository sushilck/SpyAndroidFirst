package com.smalution.y3distributiontg1.entities.settings;

import org.json.JSONObject;

public class ACDepot 
{
	private String id;
	private String title;
	private String description;
	private String email;
	private String phone;
	private String fax;
	private String address;
	private String city;
	private String zipcode;
	private String state_id;
	private String country_id;
	private String create_by;
	private String region_id;
	private String opening_stocks;
	private String opening_data;
	private String created;
	private String modified;
	public ACDepot(){}
	public ACDepot(JSONObject jsonObect)
	{
		try
		{
			id=jsonObect.isNull("id")?"":jsonObect.getString("id");
			title=jsonObect.isNull("title")?"":jsonObect.getString("title");
			description=jsonObect.isNull("description")?"":jsonObect.getString("description");
			email=jsonObect.isNull("email")?"":jsonObect.getString("email");
			phone=jsonObect.isNull("phone")?"":jsonObect.getString("phone");
			fax=jsonObect.isNull("fax")?"":jsonObect.getString("fax");
			address=jsonObect.isNull("address")?"":jsonObect.getString("address");
			city=jsonObect.isNull("city")?"":jsonObect.getString("city");
			zipcode=jsonObect.isNull("zipcode")?"":jsonObect.getString("zipcode");
			state_id=jsonObect.isNull("state_id")?"":jsonObect.getString("state_id");
			country_id=jsonObect.isNull("country_id")?"":jsonObect.getString("country_id");
			create_by=jsonObect.isNull("create_by")?"":jsonObect.getString("create_by");
			region_id=jsonObect.isNull("region_id")?"":jsonObect.getString("region_id");
			opening_stocks=jsonObect.isNull("opening_stocks")?"":jsonObect.getString("opening_stocks");
			opening_data=jsonObect.isNull("opening_data")?"":jsonObect.getString("opening_data");
			created=jsonObect.isNull("created")?"":jsonObect.getString("created");
			modified=jsonObect.isNull("modified")?"":jsonObect.getString("modified");
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getFax() {
		return fax;
	}
	public void setFax(String fax) {
		this.fax = fax;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getZipcode() {
		return zipcode;
	}
	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}
	public String getState_id() {
		return state_id;
	}
	public void setState_id(String state_id) {
		this.state_id = state_id;
	}
	public String getCountry_id() {
		return country_id;
	}
	public void setCountry_id(String country_id) {
		this.country_id = country_id;
	}
	public String getCreate_by() {
		return create_by;
	}
	public void setCreate_by(String create_by) {
		this.create_by = create_by;
	}
	public String getRegion_id() {
		return region_id;
	}
	public void setRegion_id(String region_id) {
		this.region_id = region_id;
	}
	public String getOpening_stocks() {
		return opening_stocks;
	}
	public void setOpening_stocks(String opening_stocks) {
		this.opening_stocks = opening_stocks;
	}
	public String getOpening_data() {
		return opening_data;
	}
	public void setOpening_data(String opening_data) {
		this.opening_data = opening_data;
	}
	public String getCreated() {
		return created;
	}
	public void setCreated(String created) {
		this.created = created;
	}
	public String getModified() {
		return modified;
	}
	public void setModified(String modified) {
		this.modified = modified;
	}
	
}
