package com.smalution.y3distributiontg1.entities.distributor;

import org.json.JSONObject;

import android.os.Parcel;
import android.os.Parcelable;

public class RedistributorSaleItem implements Parcelable
{
	private String redistributor_sale_id;
    private String depot_id;
    private String redistributor_id;
    private String brand_id;
    private String unit_price;
    private String modified;
    private String amount;
    private String id;
    private String unit;
    private String created;
    private String quantity;
    private String user_id;
    private String sale_date;
    private String cal_qty;
    private String customer_id;
    
	public RedistributorSaleItem(){}
	public RedistributorSaleItem(JSONObject jsonObect)
	{
		try
		{
			redistributor_sale_id=jsonObect.isNull("redistributor_sale_id")?"":jsonObect.getString("redistributor_sale_id");
		    depot_id=jsonObect.isNull("depot_id")?"":jsonObect.getString("depot_id");
		    redistributor_id=jsonObect.isNull("redistributor_id")?"":jsonObect.getString("redistributor_id");
		    brand_id=jsonObect.isNull("brand_id")?"":jsonObect.getString("brand_id");
		    unit_price=jsonObect.isNull("unit_price")?"":jsonObect.getString("unit_price");
		    modified=jsonObect.isNull("modified")?"":jsonObect.getString("modified");
		    amount=jsonObect.isNull("amount")?"":jsonObect.getString("amount");
		    id=jsonObect.isNull("id")?"":jsonObect.getString("id");
		    unit=jsonObect.isNull("unit")?"":jsonObect.getString("unit");
		    created=jsonObect.isNull("created")?"":jsonObect.getString("created");
		    quantity=jsonObect.isNull("quantity")?"":jsonObect.getString("quantity");
		    user_id=jsonObect.isNull("user_id")?"":jsonObect.getString("user_id");
		    sale_date=jsonObect.isNull("sale_date")?"":jsonObect.getString("sale_date");
		    cal_qty=jsonObect.isNull("cal_qty")?"":jsonObect.getString("cal_qty");
		    customer_id=jsonObect.isNull("customer_id")?"":jsonObect.getString("customer_id");
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	public RedistributorSaleItem(Parcel in)
 	{
		redistributor_sale_id = in.readString();
	    depot_id = in.readString();
	    redistributor_id = in.readString();
	    brand_id = in.readString();
	    unit_price = in.readString();
	    modified = in.readString();
	    amount = in.readString();
	    id = in.readString();
	    unit = in.readString();
	    created = in.readString();
	    quantity = in.readString();
	    user_id = in.readString();
	    sale_date = in.readString();
	    cal_qty = in.readString();
	    customer_id = in.readString();
	}
 	@Override
 	public int describeContents() 
 	{
 		return 0;
 	}
 	@Override
 	public void writeToParcel(Parcel dest, int flags) 
 	{
 		dest.writeString(redistributor_sale_id);
 	    dest.writeString(depot_id);
 	    dest.writeString(redistributor_id);
 	    dest.writeString(brand_id);
 	    dest.writeString(unit_price);
 	    dest.writeString(modified);
 	    dest.writeString(amount);
 	    dest.writeString(id);
 	    dest.writeString(unit);
 	    dest.writeString(created);
 	    dest.writeString(quantity);
 	    dest.writeString(user_id);
 	    dest.writeString(sale_date);
 	    dest.writeString(cal_qty);
 	    dest.writeString(customer_id);
 	}
 	public static final Parcelable.Creator<RedistributorSaleItem> CREATOR = new Parcelable.Creator<RedistributorSaleItem>() 
 	{
 		public RedistributorSaleItem createFromParcel(Parcel in) 
 		{
 			return new RedistributorSaleItem(in);
 		}
 	
 		public RedistributorSaleItem[] newArray (int size) 
 		{
 			return new RedistributorSaleItem[size];
 		}
 	};

	public String getRedistributor_sale_id() {
		return redistributor_sale_id;
	}
	public void setRedistributor_sale_id(String redistributor_sale_id) {
		this.redistributor_sale_id = redistributor_sale_id;
	}
	public String getDepot_id() {
		return depot_id;
	}
	public void setDepot_id(String depot_id) {
		this.depot_id = depot_id;
	}
	public String getRedistributor_id() {
		return redistributor_id;
	}
	public void setRedistributor_id(String redistributor_id) {
		this.redistributor_id = redistributor_id;
	}
	public String getBrand_id() {
		return brand_id;
	}
	public void setBrand_id(String brand_id) {
		this.brand_id = brand_id;
	}
	public String getUnit_price() {
		return unit_price;
	}
	public void setUnit_price(String unit_price) {
		this.unit_price = unit_price;
	}
	public String getModified() {
		return modified;
	}
	public void setModified(String modified) {
		this.modified = modified;
	}
	public String getAmount() {
		return amount;
	}
	public void setAmount(String amount) {
		this.amount = amount;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getUnit() {
		return unit;
	}
	public void setUnit(String unit) {
		this.unit = unit;
	}
	public String getCreated() {
		return created;
	}
	public void setCreated(String created) {
		this.created = created;
	}
	public String getQuantity() {
		return quantity;
	}
	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}
	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	public String getSale_date() {
		return sale_date;
	}
	public void setSale_date(String sale_date) {
		this.sale_date = sale_date;
	}
	public String getCal_qty() {
		return cal_qty;
	}
	public void setCal_qty(String cal_qty) {
		this.cal_qty = cal_qty;
	}
	public String getCustomer_id() {
		return customer_id;
	}
	public void setCustomer_id(String customer_id) {
		this.customer_id = customer_id;
	}
	
}
