package com.smalution.y3distributionbu1.entities;

import org.json.JSONObject;

import android.os.Parcel;
import android.os.Parcelable;

public class Stock implements Parcelable{
	private String stockId;
	private String source;
	private String dispatchDate;
	private String recievedDate;
	public Stock(){}
	
	public Stock (JSONObject jsonStrin){
		
	}
	@Override
	public int describeContents() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void writeToParcel(Parcel dest, int flags) {
		// TODO Auto-generated method stub
		
	}

	
	public String getStockId() {
		return stockId;
	}

	
	public void setStockId(String stockId) {
		this.stockId = stockId;
	}


	public String getSource() {
		return source;
	}


	public void setSource(String source) {
		this.source = source;
	}

	public String getDispatchDate() {
		return dispatchDate;
	}

	public void setDispatchDate(String dispatchDate) {
		this.dispatchDate = dispatchDate;
	}

	public String getRecievedDate() {
		return recievedDate;
	}

	public void setRecievedDate(String recievedDate) {
		this.recievedDate = recievedDate;
	}

}
