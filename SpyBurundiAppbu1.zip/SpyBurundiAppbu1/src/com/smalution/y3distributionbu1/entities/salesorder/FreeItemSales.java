package com.smalution.y3distributionbu1.entities.salesorder;

import org.json.JSONObject;

import android.os.Parcel;
import android.os.Parcelable;

public class FreeItemSales implements Parcelable
{
	FISBrand Brand;
	FISItem FreeItem;
	
	public FreeItemSales()
	{
		Brand=new FISBrand();
		FreeItem=new FISItem();
	}
	public FreeItemSales(JSONObject jsonObject)
	{
		try
		{ 
			Brand=jsonObject.isNull("Brand")?null:new FISBrand(jsonObject.getJSONObject("Brand"));
			FreeItem=jsonObject.isNull("FreeItem")?null:new FISItem(jsonObject.getJSONObject("FreeItem"));
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	public FreeItemSales(JSONObject jsonObject,String json)
	{
		try
		{ 
			Brand=jsonObject.isNull("Brand")?null:new FISBrand(jsonObject.getJSONObject("Brand"));
			FreeItem=new FISItem(jsonObject);
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	
	public FreeItemSales(Parcel in)
 	{
		Brand=in.readParcelable(FISBrand.class.getClassLoader());
		FreeItem=in.readParcelable(FISItem.class.getClassLoader());
	}
 	@Override
 	public int describeContents() 
 	{
 		return 0;
 	}
 	@Override
 	public void writeToParcel(Parcel dest, int flags) 
 	{
 		dest.writeParcelable(Brand,flags);
 		dest.writeParcelable(FreeItem,flags);
	}
 	public static final Parcelable.Creator<FreeItemSales> CREATOR = new Parcelable.Creator<FreeItemSales>() 
 	{
 		public FreeItemSales createFromParcel(Parcel in) 
 		{
 			return new FreeItemSales(in);
 		}
 	
 		public FreeItemSales[] newArray (int size) 
 		{
 			return new FreeItemSales[size];
 		}
 	};

	public FISBrand getBrand() {
		return Brand;
	}
	public void setBrand(FISBrand brand) {
		Brand = brand;
	}
	public FISItem getFreeItem() {
		return FreeItem;
	}
	public void setFreeItem(FISItem freeItem) {
		FreeItem = freeItem;
	}
 	
}
