package com.smalution.y3distributionbu1.fragments.customer;

import com.smalution.y3distributionbu1.AppManager;
import com.smalution.y3distributionbu1.R;
import com.smalution.y3distributionbu1.SendDataToServerAsyncTask;
import com.smalution.y3distributionbu1.database.MySQLiteHelper;
import com.smalution.y3distributionbu1.database.Y3QueryDataSource;
import com.smalution.y3distributionbu1.entities.customer.Customer;
import com.smalution.y3distributionbu1.entities.settings.Depots;
import com.smalution.y3distributionbu1.entities.settings.Lgas;
import com.smalution.y3distributionbu1.entities.settings.Regions;
import com.smalution.y3distributionbu1.entities.settings.Routes;
import com.smalution.y3distributionbu1.entities.settings.States;
import com.smalution.y3distributionbu1.entities.settings.Users;
import com.smalution.y3distributionbu1.fragments.SuperFragment;
import com.smalution.y3distributionbu1.utils.AppConstant;
import com.smalution.y3distributionbu1.utils.PickImageByCameraOrGallery;

import java.util.ArrayList;

import org.json.JSONException;
import org.json.JSONObject;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.location.Location;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Toast;

import com.androidquery.AQuery;
import com.androidquery.callback.AjaxStatus;
import com.androidquery.callback.LocationAjaxCallback;

public class CustomerEditFragment extends SuperFragment 
{
	boolean[] selectedAssignToOptions;
	Customer customer;
	View rootView;
	AQuery aq; 
	PickImageByCameraOrGallery PickImageByCameraOrGalleryObj;
	public static final int FLAG_SELECT_STATE=101;
	public static final int FLAG_SELECT_LGA=102;
	public static final int FLAG_SELECT_REGION=103;
	public static final int FLAG_SELECT_DEPOT=104;
	public static final int FLAG_SELECT_ASSIGNTO=105;
	public static final int FLAG_SELECT_ROUTE=106;
	UIHandler uiHandler;
	String state_id;
	String region_id;
	String depot_id;
	String lga_id="0";
	int userGrade =0;
	String route_id = "0";
	private String jsonAssignOption;
	public class UIHandler extends Handler 
	{ 
        public void handleMessage(Message msg) 
        { 
        	switch(msg.arg1)
        	{
        		case FLAG_SELECT_STATE:
        		{
        			String selectedValue=(String)msg.obj;
        			aq.id(R.id.buttonState).text(selectedValue);
        			States states = AppManager.getInstance().getStates(aq);
        			if(states!=null)
        			{
        				state_id=states.getItem(msg.arg2).getId();
        				aq.id(R.id.buttonLGA).text(getString(R.string.select_lga));
        				customer.getCustomer().setState_id(states.getItem(msg.arg2).getId());
        			}
        			break;
				}
        		case FLAG_SELECT_LGA:
        		{
        			String selectedValue=(String)msg.obj;
        			aq.id(R.id.buttonLGA).text(selectedValue);
        			Lgas lgas = AppManager.getInstance().getLgas(aq,state_id);
        			if(lgas!=null)
        			{
        				lga_id=lgas.getItem(msg.arg2).getId();
        				customer.getCustomer().setLg_area_id(lgas.getItem(msg.arg2).getId());
        			}
        			break;
        		}
        		case FLAG_SELECT_REGION:
        		{
        			String selectedValue=(String)msg.obj;
        			aq.id(R.id.buttonRegion).text(selectedValue);
        			Regions regions = AppManager.getInstance().getRegions(aq);
        			if(regions !=null)
        			{
        				region_id=regions.getItem(msg.arg2).getId();
        				customer.getCustomer().setRegion_id(regions.getItem(msg.arg2).getId());
        				aq.id(R.id.buttonDepot).text(getString(R.string.select_depot));
        			}
        			aq.id(R.id.buttonRoute).text(getString(R.string.select_route));
        			break;
        		}
        		case FLAG_SELECT_DEPOT:
	    		{
	    			String selectedValue=(String)msg.obj;
        			aq.id(R.id.buttonDepot).text(selectedValue);
        			Depots depots=AppManager.getInstance().getDepots(aq,region_id);
	    			if(depots!=null)
	    			{
	    				depot_id = depots.getItem(msg.arg2).getId();
	    				customer.getCustomer().setDepot_id(depot_id);
	    			}
	    			aq.id(R.id.buttonRoute).text(getString(R.string.select_route));
	    			break;
	    		}
        		case FLAG_SELECT_ROUTE:
	    		{
	    			String selectedValue=(String)msg.obj;
	    			aq.id(R.id.buttonRoute).text(selectedValue);
	    			Routes routes=AppManager.getInstance().getRoutes(aq,region_id, depot_id);
	    			if(routes!=null)
	    			{
	    				
	    				route_id=routes.getItem(msg.arg2).getId();
	    			}
	    			break;
	    		}
        		case FLAG_SELECT_ASSIGNTO:
	    		{
	    			Object[] data=(Object[])msg.obj;
	    			selectedAssignToOptions = (boolean[])data[0];
                    ArrayList<String> selectedValues=(ArrayList<String>)data[1];
	    			Log.d("MTK", ""+selectedValues.size());
	    			String json = (String)data[2];
	    			customer.setToAssignOptionSelectedJSON(json);
	    			break;
	    		}
        	}
        }
    };
	public void setUIArguments(final Bundle args) 
	{
	    getActivity().runOnUiThread(new Runnable() 
	    {
	        public void run() 
	        {
	        	customer = args.getParcelable("CUSTOMER");
	        }
	    });
	}
	
	@Override
	public void onCreate(Bundle savedInstanceState) 
	{
		super.onCreate(savedInstanceState);
		customer = getArguments().getParcelable("CUSTOMER");
	}
	@Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,Bundle savedInstanceState) 
	{
        rootView = inflater.inflate(R.layout.customer_edit_fragment, container, false);
        uiHandler=new UIHandler();
        aq=new AQuery(rootView);
        initUI();
        return rootView;
    }
	@Override
	public void onActivityResult(int requestCode, int resultCode, Intent data) 
	{
		super.onActivityResult(requestCode, resultCode, data);
		PickImageByCameraOrGalleryObj.onActivityResult(requestCode, resultCode, data, aq.id(R.id.imageViewPhoto).getImageView());
	}
	private void initUI() 
	{
		addLatLong();
		String[]  AssignToOptions = AppManager.getInstance().getUsers(aq).getNamesArr();
		if(AssignToOptions!=null)
		{
			String json="";
			selectedAssignToOptions=new boolean[AssignToOptions.length]; 
			for(int i=0;i<AssignToOptions.length;i++)
			{
				for(String preAssignName:customer.getAssignToList())
				{
					if(AssignToOptions[i].equals(preAssignName))
					{
						selectedAssignToOptions[i]=true;
					}
				}
			}
		}
		
		final SharedPreferences prefs = getActivity().getSharedPreferences("BGGeoCollector", getActivity().MODE_PRIVATE);
		userGrade = prefs.getInt("grade", 0);
		String userObject = prefs.getString("user_object", null);
		try {
			JSONObject user_object = new JSONObject(userObject);
			state_id = user_object.getString("state_id");
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
				
		if (userGrade > 2){
			aq.id(R.id.tableRowRegion).gone();
			aq.id(R.id.tableRowState).gone();
			region_id=customer.getRegion().getId();
			if(region_id == "0" || region_id == null)
				region_id = prefs.getString("region_id", null);
		}else{
			region_id=customer.getRegion().getId();
		}
		
		if (userGrade > 3){
			aq.id(R.id.tableRowDepot).gone();
			depot_id =customer.getDepot().getId();
			if(depot_id == "0" || depot_id == null)
				depot_id = prefs.getString("depot_id", null);
		}else{
			depot_id =customer.getDepot().getId();
		}
		
		aq.id(R.id.editTextFirstName).text(customer.getCustomer().getFirst_name());
		aq.id(R.id.editTextLastName).text(customer.getCustomer().getLast_name());
		//aq.id(R.id.editTextEmail).text(customer.getCustomer().getEmail());
		aq.id(R.id.editTextPhone).text(customer.getCustomer().getPhone());
		aq.id(R.id.editTextAddress).text(customer.getCustomer().getAddress());
		aq.id(R.id.editTextCity).text(customer.getCustomer().getCity());
		//aq.id(R.id.editTextZipcode).text(customer.getCustomer().getZipcode());
		state_id=customer.getCustomer().getState_id();
		state_id=customer.getState().getId();
		region_id=customer.getRegion().getId();
		route_id=customer.getCustomer().getRoute_id();
		//
		if(route_id != "0" && route_id != null){
			Routes routes=AppManager.getInstance().getRoutes(aq,region_id, depot_id);
		
			if(routes != null){
				String defRoute = routes.getRouteNameById(route_id);
				if(defRoute != null)
					aq.id(R.id.buttonRoute).text(defRoute); 
			}
		}
		//System.out.println("&&&&"+region_id);
		aq.id(R.id.buttonState).text(customer.getState().getState());
		aq.id(R.id.editTextLatitude).text(customer.getCustomer().getLatitude());
		aq.id(R.id.editTextLongitude).text(customer.getCustomer().getLongitude());
		aq.id(R.id.buttonLGA).text(customer.getLgArea().getName());
		aq.id(R.id.buttonRegion).text(customer.getRegion().getTitle());
		aq.id(R.id.buttonDepot).text(customer.getDepot().getTitle());
		aq.id(R.id.editTextDescription).text(customer.getCustomer().getDescription());
		//aq.id(R.id.buttonAssignTo).text(customer.getToAssignOptionSelectedJSON());
		aq.id(R.id.checkBoxIsDisplayCustDetail).checked(customer.getCustomer().getView_details());
		if(customer.getCustomer().getImage_path()!=null && customer.getCustomer().getImage_path().length()>0)
		{
			aq.id(R.id.imageViewPhoto).image(customer.getCustomer().getImage_path(), true, true, aq.id(R.id.imageViewPhoto).getImageView().getWidth(), 0);
		}
		PickImageByCameraOrGalleryObj=new PickImageByCameraOrGallery(CustomerEditFragment.this);
		aq.id(R.id.buttonSelectPhoto).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				PickImageByCameraOrGalleryObj.pickImage();
			}
		});
//		
//		buttonSelectPhoto
		
//		
		aq.id(R.id.buttonState).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				boolean flag=false;
				States states = AppManager.getInstance().getStates(aq);
				if(states!=null)
				{
					String[] arr=states.getStatesNameArr();
					if(arr.length>0)
					{
						AppManager.getInstance().showSelectionAlertDialog(getActivity(), uiHandler, FLAG_SELECT_STATE, arr);
						flag=true;
					}
				}
				if(!flag)
				{
					Toast.makeText(getActivity(), getString(R.string.state_req_mess), Toast.LENGTH_SHORT).show();
				}
			}
		});
		aq.id(R.id.buttonLGA).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				boolean flag=false;
				Lgas lgas = AppManager.getInstance().getLgas(aq,state_id);
				if(lgas!=null)
				{
					String[] arr=lgas.getLgaNamesArr();
					if(arr.length>0)
					{
						AppManager.getInstance().showSelectionAlertDialog(getActivity(), uiHandler, FLAG_SELECT_LGA, arr);
						flag=true;
					}
				}
				if(!flag)
				{
					Toast.makeText(getActivity(), R.string.lga_req_mess, Toast.LENGTH_SHORT).show();
				}
			}
		});
		aq.id(R.id.buttonRegion).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				boolean flag=false;
				Regions regions = AppManager.getInstance().getRegions(aq);
				if(regions!=null)
				{
					String arr[]=regions.getRegionNames();
					if(arr.length>0)
					{
						AppManager.getInstance().showSelectionAlertDialog(getActivity(), uiHandler, FLAG_SELECT_REGION, arr);
						flag=true;
					}
				}
				if(!flag)
				{
					Toast.makeText(getActivity(), getString(R.string.region_req_mess), Toast.LENGTH_SHORT).show();
				}
			}
		});
		aq.id(R.id.buttonDepot).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				boolean flag=false;
				Depots depots=AppManager.getInstance().getDepots(aq,region_id);
				if(depots!=null)
				{
					String[] arr=depots.getTitleArr();
					if(arr.length>0)
					{
						AppManager.getInstance().showSelectionAlertDialog(getActivity(), uiHandler, FLAG_SELECT_DEPOT, arr);
						flag=true;
					}
				}
				if(!flag)
				{
					Toast.makeText(getActivity(), getString(R.string.depot_req_mess), Toast.LENGTH_SHORT).show();
				}
			}
		});
		aq.id(R.id.buttonRoute).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				boolean flag=false;
				Routes routes=AppManager.getInstance().getRoutes(aq,region_id,depot_id);
				//System.out.println(region_id+"=="+depot_id);
				
				if(routes!=null)
				{
					String[] arr=routes.getTitleArr();
					if(arr.length>0)
					{
						AppManager.getInstance().showSelectionAlertDialog(getActivity(), uiHandler, FLAG_SELECT_ROUTE, arr);
						flag=true;
					}
				}
				if(!flag)
				{
					Toast.makeText(getActivity(), getString(R.string.empty_route_mess), Toast.LENGTH_SHORT).show();
				}
			}
		});
		aq.id(R.id.buttonAssignTo).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				boolean flag=false;
				Users users = AppManager.getInstance().getUsers(aq);
				if(users!=null)
				{
					String[]  AssignToOptions = users.getNamesArr();
					if(AssignToOptions!=null && AssignToOptions.length>0)
					{
						AppManager.getInstance().showMultiSelectionAlertDialog(getActivity(), uiHandler, FLAG_SELECT_ASSIGNTO, AssignToOptions, selectedAssignToOptions,users);
						flag=true;
					}
				}
				if(!flag)
				{
					Toast.makeText(getActivity(), getString(R.string.assign_req_mess), Toast.LENGTH_SHORT).show();
				}
			}
		});
		
		aq.id(R.id.buttonSave).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				updateCustomer();
			}
		});
	}
	private boolean isValidated()
	{
		if(aq.id(R.id.editTextFirstName).getEditText().getText().toString().length()>0)
		{
			if(aq.id(R.id.editTextLastName).getEditText().getText().toString().length()>0)
			{
				/*if(aq.id(R.id.editTextEmail).getEditText().getText().toString().length()>0)
				{
					if(!AppManager.getInstance().isValidEmailId(aq.id(R.id.editTextEmail).getEditText().getText().toString()))
					{
						Toast.makeText(getActivity(), getString(R.string.please_enter_email_id), Toast.LENGTH_SHORT).show();
						return false;
					}
				}*/
				if(aq.id(R.id.editTextPhone).getEditText().getText().toString().length()>0
						&& AppManager.getInstance().isValidNumber(aq.id(R.id.editTextPhone).getEditText().getText().toString()) && !aq.id(R.id.editTextPhone).getEditText().getText().toString().equals("0") )
				{
					if(aq.id(R.id.editTextAddress).getEditText().getText().toString().length()>0)
					{
						if(aq.id(R.id.editTextCity).getEditText().getText().toString().length()>0)
						{
							/*if(aq.id(R.id.editTextZipcode).getEditText().getText().toString().length()>0)
							{
								if(!AppManager.getInstance().isValidNumber(aq.id(R.id.editTextZipcode).getEditText().getText().toString()))
								{
									Toast.makeText(getActivity(), getString(R.string.valid_zipcode), Toast.LENGTH_SHORT).show();
									return false;
								}
							}*/
							if( (aq.id(R.id.buttonState).getButton().getText().toString().length()>0 &&
									!aq.id(R.id.buttonState).getButton().getText().toString().startsWith(getString(R.string.select)) ) || userGrade > 2)
							{
								if(aq.id(R.id.editTextLatitude).getEditText().getText().toString().length()>0
										&& AppManager.getInstance().isValidNumber(aq.id(R.id.editTextLatitude).getEditText().getText().toString()))
								{
									if(aq.id(R.id.editTextLongitude).getEditText().getText().toString().length()>0
											&& AppManager.getInstance().isValidNumber(aq.id(R.id.editTextLongitude).getEditText().getText().toString()))
									{
										if(aq.id(R.id.buttonLGA).getButton().getText().toString().length()>0 &&
												!aq.id(R.id.buttonLGA).getButton().getText().toString().startsWith(getString(R.string.select)))
										{
											if((aq.id(R.id.buttonRegion).getButton().getText().toString().length()>0 &&
													!aq.id(R.id.buttonRegion).getButton().getText().toString().startsWith(getString(R.string.select)) ) || userGrade > 2)
											{
												if((aq.id(R.id.buttonDepot).getButton().getText().toString().length()>0 &&
														!aq.id(R.id.buttonDepot).getButton().getText().toString().startsWith(getString(R.string.select)) ) || userGrade > 3)
												{
													if((aq.id(R.id.buttonRoute).getButton().getText().toString().length()>0 &&
															!aq.id(R.id.buttonRoute).getButton().getText().toString().startsWith(getString(R.string.select))) )
													{
														return true;
													}
													else
													{
														Toast.makeText(getActivity(), getString(R.string.pls_select_route), Toast.LENGTH_SHORT).show();
													}
												}
												else
												{
													Toast.makeText(getActivity(), getString(R.string.pls_select_depot), Toast.LENGTH_SHORT).show();
												}
											}
											else
											{
												Toast.makeText(getActivity(), getString(R.string.pls_select_region), Toast.LENGTH_SHORT).show();
											}
										}
										else
										{
											Toast.makeText(getActivity(), getString(R.string.select_lga), Toast.LENGTH_SHORT).show();
										}
									}
									else
									{
										Toast.makeText(getActivity(), getString(R.string.pls_enter_longitude), Toast.LENGTH_SHORT).show();
									}
								}
								else
								{
									Toast.makeText(getActivity(), getString(R.string.pls_enter_latitude), Toast.LENGTH_SHORT).show();
								}
							}
							else
							{
								Toast.makeText(getActivity(), getString(R.string.pls_select_state), Toast.LENGTH_SHORT).show();
							}
							
						}
						else
						{
							Toast.makeText(getActivity(), getString(R.string.please_enter_city), Toast.LENGTH_SHORT).show();
						}
					}
					else
					{
						Toast.makeText(getActivity(), getString(R.string.please_enter_address), Toast.LENGTH_SHORT).show();
					}
				}
				else
				{
					Toast.makeText(getActivity(), getString(R.string.please_enter_phn_number), Toast.LENGTH_SHORT).show();
				}
				
			}
			else
			{
				Toast.makeText(getActivity(), getString(R.string.please_enter_lname), Toast.LENGTH_SHORT).show();
			}
		}
		else
		{
			Toast.makeText(getActivity(), getString(R.string.please_enter_lname), Toast.LENGTH_SHORT).show();
		}
		return false;
	}
	private void updateCustomer()
	{
		if(!isValidated())
			return;
		customer.getCustomer().setFirst_name(aq.id(R.id.editTextFirstName).getEditText().getText().toString());
		customer.getCustomer().setLast_name(aq.id(R.id.editTextLastName).getEditText().getText().toString());
		//customer.getCustomer().setEmail(aq.id(R.id.editTextEmail).getEditText().getText().toString());
		customer.getCustomer().setPhone(aq.id(R.id.editTextPhone).getEditText().getText().toString());
		customer.getCustomer().setAddress(aq.id(R.id.editTextAddress).getEditText().getText().toString());
		customer.getCustomer().setCity(aq.id(R.id.editTextCity).getEditText().getText().toString());
		//customer.getCustomer().setZipcode(aq.id(R.id.editTextZipcode).getEditText().getText().toString());		
		customer.getState().setId(customer.getCustomer().getState_id());
		customer.getState().setState(aq.id(R.id.buttonState).getButton().getText().toString());
		customer.getCustomer().setLatitude(aq.id(R.id.editTextLatitude).getEditText().getText().toString());
		customer.getCustomer().setLongitude(aq.id(R.id.editTextLongitude).getEditText().getText().toString());		
		customer.getLgArea().setId(lga_id);
		customer.getCustomer().setLg_area_id(lga_id);
		customer.getCustomer().setRoute_id(route_id);
		//customer.getLgArea().setId(customer.getCustomer().getLg_area_id());
		customer.getLgArea().setName(aq.id(R.id.buttonLGA).getButton().getText().toString());		
		customer.getRegion().setId(customer.getCustomer().getRegion_id());
		customer.getRegion().setTitle(aq.id(R.id.buttonRegion).getButton().getText().toString());
		customer.getDepot().setId(customer.getCustomer().getDepot_id());
		customer.getDepot().setTitle(aq.id(R.id.buttonDepot).getButton().getText().toString());
		customer.getCustomer().setDescription(aq.id(R.id.editTextDescription).getEditText().getText().toString());
		customer.getCustomer().setView_details(aq.id(R.id.checkBoxIsDisplayCustDetail).getCheckBox().isChecked());
		String jsonString = customer.createJson(aq,false);
		Log.d("MTK", "edit customer="+jsonString);
		String selectedImagePath=null;
		
		if(aq.id(R.id.imageViewPhoto).getImageView().getTag()!=null)
		{
			selectedImagePath = aq.id(R.id.imageViewPhoto).getImageView().getTag().toString();
			customer.getCustomer().setImage_path(selectedImagePath);
			Log.d("MTK", "user selected image path:"+selectedImagePath);
		}
		if(AppManager.isOnline(getActivity())){
	    new SendDataToServerAsyncTask<Customer>(
	    		getActivity(), 
	    		jsonString,selectedImagePath, 
	    		AppManager.getInstance().URL_UPDATE_CUSTOMER,
	    		getString(R.string.customer_added),
	    		true,
	    		null,
	    		null,
	    		-1,AppConstant.CUSTOMER_EDIT_OPCODE).execute();
	    
		}
		else{
			// this is for offline update.....
			Y3QueryDataSource datasource=new Y3QueryDataSource(getActivity());
			datasource.open();
			//Cursor cursor=datasource.getCustomerIsadded(customer.getCustomer().getId());
			//String cva=cursor.getString(cursor.getColumnIndex(MySQLiteHelper.ISOFFLINEEDITED));
			
			datasource.updateCustomerData(customer,customer.getCustomer().getId());	
			showEditDialog();
			 //Toast.makeText(getActivity(), "Customer updated successfully.", Toast.LENGTH_SHORT).show();
		    // getActivity().getSupportFragmentManager().popBackStack();
			//getActivity().finish();
			
			
			
		}
	}
	private void showEditDialog(){	
		AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
				getActivity());
		alertDialogBuilder.setTitle(getString(R.string.confirm));
		alertDialogBuilder
				.setMessage(getString(R.string.customer_updated))
				.setCancelable(false)
				.setPositiveButton(
						getString(R.string.OK),
						new DialogInterface.OnClickListener() {
							public void onClick(
									DialogInterface dialog,
									int id) {
								
								getActivity().getSupportFragmentManager().popBackStack();
								dialog.cancel();
							}
						});
			
		AlertDialog alertDialog = alertDialogBuilder
				.create();
		alertDialog.show();
	}
	private void addLatLong()
	{
		try
		{
			LocationAjaxCallback lac=new LocationAjaxCallback();
			lac.weakHandler(this, "locationCB");
			lac.async(getActivity());
		}
		catch(NumberFormatException ex)
		{
			ex.printStackTrace();
		}
	}
	public void locationCB(String url, Location loc, AjaxStatus status)
	{
		aq.id(R.id.editTextLatitude).text(""+loc.getLatitude());
		aq.id(R.id.editTextLongitude).text(""+loc.getLongitude());
	}
}
