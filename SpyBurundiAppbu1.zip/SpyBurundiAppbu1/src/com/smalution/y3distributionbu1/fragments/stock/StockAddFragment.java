package com.smalution.y3distributionbu1.fragments.stock;

import java.util.Calendar;
import java.util.Hashtable;

import org.json.JSONException;
import org.json.JSONObject;

import com.androidquery.AQuery;
import com.smalution.y3distributionbu1.AppManager;
import com.smalution.y3distributionbu1.R;
import com.smalution.y3distributionbu1.Utils;
import com.smalution.y3distributionbu1.R.id;
import com.smalution.y3distributionbu1.entities.settings.Brands;
import com.smalution.y3distributionbu1.entities.settings.Depots;
import com.smalution.y3distributionbu1.entities.settings.Distributors;
import com.smalution.y3distributionbu1.fragments.SuperFragment;
import com.smalution.y3distributionbu1.utils.AppConstant;
import com.smalution.y3distributionbu1.utils.DatePickerFragment;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.app.DatePickerDialog.OnDateSetListener;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.DatePicker;
import android.widget.Toast;

public class StockAddFragment extends SuperFragment {
	
	View rootView;
	AQuery aq; 
	UIHandler uiHandler;
	public int date_sel_option = 1;
	
	public static final int FLAG_SELECT_BRAND=101;
	public static final int FLAG_SELECT_SOURCE_TYPE=102;
	public static final int FLAG_SELECT_SOURCE=103;
	
	public String jsonStr;
	public String brand_id="0";
	public String target_entity=null;
	public String target_entity_id = "0";
	//public String[] source_type = {"Warehouse", "Depot", "Distributor"};
	public String[] source_type = {"Depot", "Distributor"};	
	public class UIHandler extends Handler 
	{ 
        public void handleMessage(Message msg) 
        { 
        	switch(msg.arg1){
	        	case FLAG_SELECT_BRAND:
	        	{
	        		String selectedValue = (String)msg.obj;
	    			aq.id(R.id.buttonBrand).text(selectedValue);
	    			Brands brands = AppManager.getInstance().getBrands(aq);
	    			if(brands!=null)
	    			{    				
	    				brand_id=brands.getItem(msg.arg2).getId();
	    			}
	        		break;
	        	}
	        	case FLAG_SELECT_SOURCE_TYPE:
	        	{
	        		String selectedDestType=(String)msg.obj;        	
	        		aq.id(R.id.buttonDestType).text(selectedDestType);
	        		target_entity = selectedDestType;
	        		aq.id(id.textViewDest).text(target_entity);
	        		aq.id(id.tableRowDest).visible();
	        		aq.id(R.id.buttonDestination).text(getString(R.string.please_select));
	        		target_entity_id = "0";
	        		break;
	        	}
	        	case FLAG_SELECT_SOURCE:
	        	{
	        		String selectedDestType=(String)msg.obj;        	
	        		aq.id(R.id.buttonDestination).text(selectedDestType);
	        		if(target_entity.equals("Depot") ){							
						Depots depots=AppManager.getInstance().getDepots(aq);
						if(depots!=null){
							target_entity_id = depots.getItem(msg.arg2).getId();
						}
	        		}else if(target_entity.equals("Distributor") ){						
						Distributors distributors= AppManager.getInstance().getDistributor(aq);	    
						if(distributors!=null){
							target_entity_id = distributors.getItem(msg.arg2).getId();
						}
	        		}
	        		break;
	        	}
        		
        	}
        	
        }
	};
	
	@Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,Bundle savedInstanceState) 
	{
        rootView = inflater.inflate(R.layout.stock_update_fragment, container, false);       
        aq = new AQuery(rootView);
        uiHandler=new UIHandler();
        initUI();
        return rootView;
    }
	
	private void initUI() 
	{
		aq.id(R.id.buttonBrand).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				boolean flag=false;
				Brands brands = AppManager.getInstance().getBrands(aq);
				
				if(brands!=null)
				{
					String[] arr=brands.getBrandsNames();
					if(arr.length>0)
					{
						AppManager.getInstance().showSelectionAlertDialog(getActivity(), uiHandler, FLAG_SELECT_BRAND, arr);
						flag=true;
					}
				}
				if(!flag)
				{
					Toast.makeText(getActivity(), getString(R.string.brand_required_mess), Toast.LENGTH_SHORT).show();
				}
				
			}
			
		});		
		aq.id(R.id.buttonDestType).clicked(new OnClickListener(){
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				AppManager.getInstance().showSelectionAlertDialog(getActivity(), uiHandler, FLAG_SELECT_SOURCE_TYPE, source_type);
			}
			
		});
		
		aq.id(R.id.buttonDestination).clicked(new OnClickListener(){

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				String[] listArr = null;
				///
				if(target_entity == null){
					Toast.makeText(getActivity(), getString(R.string.select_dest_type), Toast.LENGTH_SHORT).show();
				}else{
					if(target_entity.equals("Depot") ){							
						Depots depots=AppManager.getInstance().getDepots(aq);
						if(depots!=null)
						{
							listArr = depots.getTitleArr();
							
						}else {
							Toast.makeText(getActivity(), getString(R.string.depot_req_mess), Toast.LENGTH_SHORT).show();
						}
						
					} else if(target_entity.equals("Distributor") ){
						
						Distributors distributors= AppManager.getInstance().getDistributor(aq);
						if(distributors!=null){
							listArr = distributors.getNameArray();
						}else{
							Toast.makeText(getActivity(), getString(R.string.distributor_required_mess), Toast.LENGTH_SHORT).show();
						}
						
					} else if(target_entity.equals("Warehouse") ){
						
					}
					
					
					if(listArr.length>0)
					{
						AppManager.getInstance().showSelectionAlertDialog(getActivity(), uiHandler, FLAG_SELECT_SOURCE, listArr);
						
					}
						
				}
				
			}
			
		});
		
		aq.id(R.id.editTextDispatchDate).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				date_sel_option = 1;
				showDatePicker();
			}
		});
		
		aq.id(R.id.editTextReceivedDate).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				date_sel_option = 2;
				showDatePicker();
			}
		});
		
		aq.id(R.id.buttonSave).clicked(new OnClickListener() 
		{

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				if(validateInput())
				{
					postStockData();
				}
			}
			
		});
	}
	
	private void showDatePicker() 
	{
		  DatePickerFragment date = new DatePickerFragment();
		  Calendar calender = Calendar.getInstance();
		  Bundle args = new Bundle();
		  args.putInt("year", calender.get(Calendar.YEAR));
		  args.putInt("month", calender.get(Calendar.MONTH));
		  args.putInt("day", calender.get(Calendar.DAY_OF_MONTH));
		  date.setArguments(args);
		  date.setCallBack(ondate);
		  date.show(getActivity().getSupportFragmentManager(), getString(R.string.date_picker));
	}
	OnDateSetListener ondate = new OnDateSetListener() 
	{
		@Override
		public void onDateSet(DatePicker view, int year, int monthOfYear,int dayOfMonth) 
		{
			String dateStr=String.valueOf(year) + "-" + String.valueOf(monthOfYear+1)+ "-" + String.valueOf(dayOfMonth);
			if(date_sel_option == 1){
				aq.id(R.id.editTextDispatchDate).text(dateStr);
			}
			if(date_sel_option== 2){
				aq.id(R.id.editTextReceivedDate).text(dateStr);
			}
		}
	};
	
	public boolean validateInput(){
		String brand = aq.id(R.id.buttonBrand).getText().toString();
		String qty = aq.id(R.id.editTextQuantity).getText().toString();
		String dispDate = aq.id(R.id.editTextDispatchDate).getText().toString();
		String destType = aq.id(R.id.buttonDestType).getText().toString();
		String dest = aq.id(R.id.buttonDestination).getText().toString();
		String receivedDate = aq.id(R.id.editTextReceivedDate).getText().toString();
		
		if (brand ==null || brand.length() <= 0){
			Toast.makeText(getActivity(), getString(R.string.select_brand), Toast.LENGTH_SHORT).show();
			return false;
		} else if(qty == null || qty.length()<=0 || !AppManager.getInstance().isValidNumber(qty) ){
			Toast.makeText(getActivity(), getString(R.string.valid_qty_mess), Toast.LENGTH_SHORT).show();
			return false;
		} else if(dispDate == null || dispDate.length() <=0 ){
			Toast.makeText(getActivity(), getString(R.string.enter_disp_date), Toast.LENGTH_SHORT).show();
			return false;
		} else if(destType == null || destType.length() <= 0) {
			Toast.makeText(getActivity(), getString(R.string.select_dest_type) , Toast.LENGTH_SHORT).show();
			return false;
		} else if(dest == null || dest.length() <= 0) {	
			Toast.makeText(getActivity(), getString(R.string.please_select)+" "+destType, Toast.LENGTH_SHORT).show();
			return false;			
		} else if(receivedDate == null || receivedDate.length() <= 0) {
			Toast.makeText(getActivity(), getString(R.string.enter_rec_date), Toast.LENGTH_SHORT).show();
			return false;
		} else {
			return true;
		}
	}
	
	public void postStockData(){
		String qty = aq.id(R.id.editTextQuantity).getText().toString();
		String dispDate = aq.id(R.id.editTextDispatchDate).getText().toString();
		String receivedDate = aq.id(R.id.editTextReceivedDate).getText().toString();
		SharedPreferences prefs = AppManager.getInstance().getPrefs(getActivity());
		String token = prefs.getString("token", null);
		 jsonStr =	"{" 
				 	+"\"token\":\""+token+"\","
				 	+"\"request_id\":\""+ AppConstant.ANDROIDDEVICEID + AppConstant.getRequestId()+ "\","
		    		+"\"brand_id\":\""+brand_id+"\"," 
		    		+"\"qty\":\""+qty+"\"," +		    		
		    		"\"dest_entity\":\""+target_entity+"\"," +
		    		"\"dest_entity_id\":\""+target_entity_id+"\"," +
		    		"\"disp_date\":\""+dispDate+"\"," +						    		
		    		"\"rec_date\":\""+receivedDate+"\"}";						    		
		new AddStockAsync().execute();   							    		
	}
	
	
	private class AddStockAsync extends AsyncTask<Void, Void, String> {


		ProgressDialog progressDialog;

		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			progressDialog = new ProgressDialog(getActivity());
			progressDialog.setMessage(getString(R.string.wait_progress));
			progressDialog.setCancelable(false);
			progressDialog.setIndeterminate(true);
			progressDialog.show();
			progressDialog
					.setOnKeyListener(new DialogInterface.OnKeyListener() {
						@Override
						public boolean onKey(DialogInterface dialog,
								int keyCode, KeyEvent event) {
							return false;
						}
					});
		}


		protected String doInBackground(Void... params) {
			if (AppManager.getInstance().isOnline(aq.getContext())) {
				//return AppManager.getInstance().getCustomerList(aq, pageCount);
				Hashtable<String,String> params1=new Hashtable<String,String>();
				params1.put("jsonString", jsonStr);			
				String response = Utils.post(getActivity(), AppManager.getInstance().URL_UPDATE_STOCK, params1, null);
				System.out.println("Stock add Response: "+response);
				return response;
			}
			return null;
		}

		protected void onPostExecute(String response) {
			
			progressDialog.dismiss();
			
			try {
				if(response!=null){
				int errorCode=new JSONObject(response).getInt("error");				
				if(errorCode==0){
					 System.out.println("Added");
					 showSaveDialog();
				}
				else{
					System.out.println("something wrong");
					
				}
				}
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}	
		
	}

	private void showSaveDialog(){	
		AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
				getActivity());
		alertDialogBuilder.setTitle(getString(R.string.confirm));
		alertDialogBuilder
				.setMessage(getString(R.string.stock_added))
				.setCancelable(false)
				.setPositiveButton(
						getString(R.string.OK),
						new DialogInterface.OnClickListener() {
							public void onClick(
									DialogInterface dialog,
									int id) {
								
								//getActivity().getSupportFragmentManager().popBackStack();
								
								FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
								FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
								Fragment fragment = fragmentManager.findFragmentByTag("StockDisplayFragment");
								Bundle bundle = new Bundle();
								bundle.putString("opt", "stockOut");
								if (fragment == null) {
									fragment = new StockDisplayFragment();
									fragment.setArguments(bundle);
									fragmentTransaction.addToBackStack("StockDisplayFragment");
								} else {
									((StockDisplayFragment) fragment).setUIArguments(bundle);
								}
								
								fragmentTransaction.replace(R.id.frame_container, fragment,"StockDisplayFragment");
								fragmentTransaction.addToBackStack(null);
								fragmentTransaction.commit();
								
								
								dialog.cancel();
							}
						});
			
		AlertDialog alertDialog = alertDialogBuilder
				.create();
		alertDialog.show();
	}

	public void setUIArguments(Bundle bundle) {
		// TODO Auto-generated method stub
		
	}
	
}
