package com.smalution.y3distributionbu1.fragments.distributorsalesorder;

import com.smalution.y3distributionbu1.AppManager;
import com.smalution.y3distributionbu1.R;
import com.smalution.y3distributionbu1.Utils;
import com.smalution.y3distributionbu1.database.Y3QueryDataSource;
import com.smalution.y3distributionbu1.entities.customer.Customer;
import com.smalution.y3distributionbu1.entities.distributor.Distributor;
import com.smalution.y3distributionbu1.fragments.SuperFragment;
import com.smalution.y3distributionbu1.quickaction.ActionItem;
import com.smalution.y3distributionbu1.quickaction.QuickAction;

import java.io.File;
import java.util.ArrayList;
import java.util.Hashtable;

import org.json.JSONObject;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.database.DataSetObserver;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.androidquery.AQuery;


public class DistributorSalesOrderDisplayFragment extends SuperFragment 
{
	ListView customerList;
	ArrayAdapter<Distributor> adapter;
	ArrayList<Distributor> customerArrayList=new ArrayList<Distributor>();
	View rootView;
	AQuery aq; 
	int pageCount=0;
	View foolterLoadMoreView;
	AQuery aqf;
	private boolean isAddToDataBase;
	private int deleteIdForSqlite;
	@Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,Bundle savedInstanceState) 
	{
        rootView = inflater.inflate(R.layout.distributor_sales_order_display_fragment, container, false);
        aq=new AQuery(rootView);
        pageCount=0;
        customerArrayList.clear();
        intiApplication();
        return rootView;
    }
	private void intiApplication(){
		initUI(true);
		if (AppManager.isOnline(getActivity())) 
        {
			//new DeletesalesrfromServer().execute();
			new SalesOrderListAsyncTask(aq).execute();
			isAddToDataBase = true;
			

		} else {
			customerArrayList.clear();			
			fillLIstView();

		}
	}
	private void initUI(boolean addFooter) 
	{
		aq.id(R.id.buttonRefresh).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				if(AppManager.isOnline(getActivity()))
				{
					pageCount=0;
			        customerArrayList.clear();
			        initUI(false);
			        new SalesOrderListAsyncTask(aq).execute();
				}
				
				
			}
		});
		aq.id(R.id.buttonAddNewDistributorSales).clicked(new OnClickListener() 
		{
			@Override
			public void onClick(View v) 
			{
				FragmentManager fragmentManager=getActivity().getSupportFragmentManager();
				FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
				Fragment fragment = fragmentManager.findFragmentByTag("DistributorSalesOrderAddFragment");
				Bundle bundle=new Bundle();
				if(fragment==null)
				{
					fragment=new DistributorSalesOrderAddFragment();
					fragment.setArguments(bundle);
					fragmentTransaction.addToBackStack("DistributorSalesOrderAddFragment");
				}
				else
				{
					((DistributorSalesOrderAddFragment)fragment).setUIArguments(bundle);
				}
				fragmentTransaction.replace(R.id.frame_container, fragment, "DistributorSalesOrderAddFragment");
				fragmentTransaction.commit();
			}
		});
		adapter = new ArrayAdapter<Distributor>(this.getActivity(), R.layout.distributor_sales_order_display_listitem, customerArrayList)
		{
			public View getView(int position, View convertView, ViewGroup parent) 
	        {
	            if(convertView == null)
	            {
                     convertView = getActivity().getLayoutInflater().inflate(R.layout.distributor_sales_order_display_listitem, parent, false);
	            }
                final Distributor distributor = getItem(position);
                AQuery aql = new AQuery(convertView);
                position=position+1;
                aql.id(R.id.textViewSerialNo).text(""+position);
                aql.id(R.id.textViewCustomer).text(distributor.getCustomer().getFirst_name()+" "+distributor.getCustomer().getLast_name());
                aql.id(R.id.textViewUser).text(distributor.getUser().getFirst_name()+" "+distributor.getUser().getLast_name());
                aql.id(R.id.textViewOrderDate).text(distributor.getRedistributorSale().getSale_date());
                aql.id(R.id.textViewTotal).text(distributor.getRedistributorSale().getTotal());
                final int pos=position;
                aql.id(R.id.quickActionParent).clicked(new OnClickListener() 
                {
					@Override
					public void onClick(View v) 
					{
						showQuickActionPopup(v, distributor,pos);
					}
				});
	            return convertView;
	        }
		};
		if(pageCount==0 && addFooter)
		{
			foolterLoadMoreView=LayoutInflater.from(getActivity()).inflate(R.layout.load_more_list_footer, null);
			aqf=new AQuery(foolterLoadMoreView);
			aqf.id(R.id.buttonLoadMoreListItems).clicked(new OnClickListener() 
			{
				@Override
				public void onClick(View v) 
				{if(AppManager.isOnline(getActivity()))
					
					{
						//customerArrayList.clear();
						new SalesOrderListAsyncTask(aq).execute();
					}
				}
			});
			aq.id(R.id.customerList).getListView().addFooterView(foolterLoadMoreView, null, true);
		}
		aq.id(R.id.customerList).getListView().setTranscriptMode(AbsListView.TRANSCRIPT_MODE_ALWAYS_SCROLL);
		aq.id(R.id.customerList).adapter(adapter);
		adapter.registerDataSetObserver(new DataSetObserver() 
		{
		    @Override
		    public void onChanged() 
		    {
		        super.onChanged();
		        if(pageCount==1)
		        {
		        	aq.id(R.id.customerList).getListView().setSelection(0);
		        }
		        else
		        {
		        	aq.id(R.id.customerList).getListView().setSelection(adapter.getCount() - 1);
		        }  
		    }
		});
	}
	private void showQuickActionPopup(View anchorView, final Distributor distributor,final int position)
	{
		ActionItem viewAction = new ActionItem();
		viewAction.setTitle("View");
		viewAction.setIcon(getResources().getDrawable(R.drawable.icon_view));
		// Upload action item
		ActionItem deleteAction = new ActionItem();
		SharedPreferences prefs = AppManager.getInstance().getPrefs(aq.getContext());
		int grade = prefs.getInt("grade", -1);
		if(grade!=-1 && (grade==1 || grade==3))
		{
		deleteAction.setTitle("Delete");
		deleteAction.setIcon(getResources().getDrawable(R.drawable.icon_delete));
		}

		final QuickAction mQuickAction = new QuickAction(getActivity());

		mQuickAction.addActionItem(viewAction);
		mQuickAction.addActionItem(deleteAction);
		mQuickAction.setOnActionItemClickListener(new QuickAction.OnActionItemClickListener() 
		{
			public void onItemClick(int pos) 
			{
				if (pos == 0) 
				{ 
					FragmentManager fragmentManager=getActivity().getSupportFragmentManager();
					FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
					Fragment fragment = fragmentManager.findFragmentByTag("DistributorSalesOrderViewFragment");
					Bundle bundle=new Bundle();
					bundle.putParcelable("SALESORDER", distributor);
					if(fragment==null)
					{
						fragment=new DistributorSalesOrderViewFragment();
						fragment.setArguments(bundle);
						fragmentTransaction.addToBackStack("DistributorSalesOrderViewFragment");
					}
					else
					{
						((DistributorSalesOrderViewFragment)fragment).setUIArguments(bundle);
					}
					fragmentTransaction.replace(R.id.frame_container, fragment, "DistributorSalesOrderViewFragment");
					fragmentTransaction.commit();
				} 
				else if (pos == 1) 
				{ 
					SharedPreferences prefs = AppManager.getInstance().getPrefs(aq.getContext());
					String token = prefs.getString("token", null);
				   final String jsonString="{\"token\":\""+token+"\",\"rdsale_id\":\""+distributor.getRedistributorSale().getId()+"\"}";
				    
				    
				    if(AppManager.isOnline(getActivity()))
				    {
				    		
				    		AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(getActivity());
				    		alertDialogBuilder.setTitle(getString(R.string.warning));
				    		alertDialogBuilder
				    		.setMessage(getString(R.string.confirm_delete))
				    		.setCancelable(false)
				    		.setPositiveButton(R.string.yes,new DialogInterface.OnClickListener() 
				    		{
				    			public void onClick(DialogInterface dialog,int id) 
				    			{
				    				
				    				new SendDataToServerAsyncTask<Distributor>(
								    		getActivity(), 
								    		jsonString,
								    		null, 
								    		AppManager.getInstance().URL_DELETE_DISTRIBUTOR_SALESORDER, getString(R.string.distributor_sale_deleted),
								    		false,
								    		adapter,
								    		customerArrayList,
								    		position).execute();
								    	
				    			}
				    		})
				    		.setNegativeButton(getString(R.string.no),new DialogInterface.OnClickListener() 
				    		{
				    			public void onClick(DialogInterface dialog,int id) 
				    			{
				    				dialog.cancel();
				    				
				    			}
				    		});
				    		AlertDialog alertDialog = alertDialogBuilder.create();
				    		alertDialog.show();
				    		
				    	
				    }
				    else{
				    	
				    	AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(getActivity());
			    		alertDialogBuilder.setTitle(getString(R.string.warning));
			    		alertDialogBuilder
			    		.setMessage(getString(R.string.confirm_delete))
			    		.setCancelable(false)
			    		.setPositiveButton(getString(R.string.yes),new DialogInterface.OnClickListener() 
			    		{
			    			public void onClick(DialogInterface dialog,int id) 
			    			{
			    				Y3QueryDataSource datasource = new Y3QueryDataSource(getActivity());
								datasource.open();
								try{
								deleteIdForSqlite = distributor.getCustOffline().getCustomerOfflineId();
								}catch(Exception e)
								{
									intiApplication();
								}
								long result = datasource.addY3Query(Y3QueryDataSource.ACTION_DISTRIBUTOR_SALES_DELETE,jsonString,null);	
								if (result != -1) {
									
									
									
									if (datasource.deleteRedistibutorSalesData(deleteIdForSqlite))
									{
										Toast.makeText(getActivity(), getString(R.string.distributor_sale_deleted),Toast.LENGTH_SHORT).show();
										customerArrayList.clear();
										fillLIstView();
									}
								}
								datasource.close();		
			    				
			    			}
			    		})
			    		.setNegativeButton(getString(R.string.no),new DialogInterface.OnClickListener() 
			    		{
			    			public void onClick(DialogInterface dialog,int id) 
			    			{
			    				dialog.cancel();
			    				
			    			}
			    		});
			    		AlertDialog alertDialog = alertDialogBuilder.create();
			    		alertDialog.show();    	
				    	
				    	
				    }
				    
				    
				    
				    
				    
				    
				    
				    
				    
				    
				    
				    
				   // AppManager.getInstance().showDeleteConfDialog(getActivity(),deletor);
				} 
			}
		});
		mQuickAction.show(anchorView);
		mQuickAction.setAnimStyle(QuickAction.ANIM_GROW_FROM_CENTER);
	}
	private class SalesOrderListAsyncTask extends AsyncTask<Void, Void, ArrayList<Distributor>>
	{
		AQuery aq;
		ProgressDialog progressDialog;
		public SalesOrderListAsyncTask(AQuery aq)
		{
			this.aq=aq;
			pageCount=pageCount+1;
		}
		@Override
		protected void onPreExecute() 
		{
			super.onPreExecute();
			if(getActivity()==null){
				progressDialog = new ProgressDialog(aq.getContext());
			}else{
				progressDialog = new ProgressDialog(getActivity());
			}
			
	        progressDialog.setMessage(getString(R.string.wait_progress));
	        progressDialog.setCancelable(false);
	        progressDialog.setIndeterminate(true);
	        progressDialog.show();
	        progressDialog.setOnKeyListener(new DialogInterface.OnKeyListener() 
	        {
	            @Override
	            public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) 
	            {
	                return false;
	            }
	        });
		}
		@Override
		protected ArrayList<Distributor> doInBackground(Void... params) 
		{
			if(AppManager.getInstance().isOnline(aq.getContext()))
			{
				return AppManager.getInstance().getDistributorSalesOrderList(aq, pageCount);
			}
			return null;
		}
		@Override
		protected void onPostExecute(ArrayList<Distributor> result) 
		{
			super.onPostExecute(result);
			if(result!=null && adapter!=null)
			{
				if(result.size()>0)
				{
					customerArrayList.addAll(result);
					adapter.notifyDataSetChanged();
					aqf.id(R.id.buttonLoadMoreListItems).visible();
					if(result.size()<20)
					{
						aqf.id(R.id.buttonLoadMoreListItems).invisible();
					}
				}
				else
				{
					if(pageCount==1 && getActivity() !=null)
					{
						Toast.makeText(aq.getContext(), getString(R.string.no_data), Toast.LENGTH_SHORT).show();
					}
					adapter.notifyDataSetChanged();
					aqf.id(R.id.buttonLoadMoreListItems).invisible();
				}
			}
			else
			{
				Toast.makeText(aq.getContext(), getString(R.string.distributor_empty_sale), Toast.LENGTH_SHORT).show();
			}
			
			progressDialog.dismiss();
		}
	}
	private void fillLIstView() {
		isAddToDataBase = false;
		Y3QueryDataSource datasource = new Y3QueryDataSource(getActivity());
		datasource.open();
		// pageCount = 1;
		customerArrayList.clear();
		ArrayList<Distributor> result = datasource.getAllRedistributorQueries();

		if (result.size() > 0) {
			customerArrayList.addAll(result);

		}
		datasource.close();
		initUI(false);
	}
	private class DeletesalesrfromServer extends	AsyncTask<Void, Void, ArrayList<Customer>> {

		ProgressDialog progressDialog;

		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			progressDialog = new ProgressDialog(getActivity());
			progressDialog.setMessage(getString(R.string.wait_progress));
			progressDialog.setCancelable(false);
			progressDialog.setIndeterminate(true);
			progressDialog.show();
			progressDialog
					.setOnKeyListener(new DialogInterface.OnKeyListener() {
						@Override
						public boolean onKey(DialogInterface dialog,
								int keyCode, KeyEvent event) {
							return false;
						}
					});
		}

		@Override
		protected ArrayList<Customer> doInBackground(Void... params) {
			// this is for added................................
			
			
			

			return null;
		}

		@Override
		protected void onPostExecute(ArrayList<Customer> result) {

			progressDialog.dismiss();
			
		}
		}
	
	
	public class SendDataToServerAsyncTask<T> extends AsyncTask<Void, Void, Integer>
	{
		FragmentActivity context;
		String jsonStr;
		String imagePath;
		String url;
		String successMessage;
		boolean isPopFragment;
		ArrayAdapter<T> adapter;
		ArrayList<T> list;
		int position;
		public SendDataToServerAsyncTask(
				FragmentActivity context, 
				String jsonStr,
				String imagePath, 
				String url,
				String successMessage,
				boolean isPopFragment,
				ArrayAdapter<T> adapter,
				ArrayList<T> list,
				int position)
		{
			this.context=context;
			this.jsonStr=jsonStr;
			this.imagePath=imagePath;
			this.url=url;
			this.successMessage=successMessage;
			this.isPopFragment=isPopFragment;
			this.adapter=adapter;
			this.list=list;
			this.position=position;
		}
		ProgressDialog progressDialog;
		@Override
		protected void onPreExecute() 
		{
			super.onPreExecute();
			progressDialog = new ProgressDialog(context);
	        progressDialog.setMessage(context.getString(R.string.wait_progress));
	        progressDialog.setCancelable(false);
	        progressDialog.setIndeterminate(true);
	        progressDialog.show();
	        progressDialog.setOnKeyListener(new DialogInterface.OnKeyListener() 
	        {
	            @Override
	            public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) 
	            {
	                return false;
	            }
	        });
		}
		@Override
		protected Integer doInBackground(Void... params) 
		{
			try
			{
				if(AppManager.getInstance().isOnline(context))
				{
					Hashtable<String,String> parameters=new Hashtable<String,String>();
					parameters.put("jsonString", jsonStr);
					Hashtable<String,File> fileParams=null;
		    		if(imagePath!=null && imagePath.length()>0 && new File(imagePath).exists())
		    		{
		    			fileParams=new Hashtable<String,File>();
			    		fileParams.put("image", new File(imagePath));
		    		}
				    String response = Utils.post(context, url, parameters, fileParams);
		    		Log.d("MTK", "server response: "+response);
		    		if(response!=null)
		    		{
		    			int error = new JSONObject(response).getInt("error");
		    			if(error==0)
		    			{
		    				return 0;
		    			}
		    			else if(error==3)//invalid token
		    			{
		    				return 3;
		    			}
		    			else
		    			{
		    				return 2;
		    			}
		    		}
				}
				else
				{
					return 1;
				}
			}
			catch(Exception ex)
			{
				ex.printStackTrace();
			}
			return 2;
		}
		@Override
		protected void onPostExecute(Integer result) 
		{
			super.onPostExecute(result);
			if(result==0)
			{
				Toast.makeText(context, successMessage, Toast.LENGTH_SHORT).show();
				if(isPopFragment)
					context.getSupportFragmentManager().popBackStack();
				if(adapter!=null)
				{
					adapter.notifyDataSetChanged();
					position=position-1;
					list.remove(position);
				}
			}
			else if(result==1)//network not available
			{
				Toast.makeText(context, getString(R.string.network_not_available), Toast.LENGTH_SHORT).show();
			}
			else if(result==2)//server error
			{
				Toast.makeText(context, getString(R.string.something_wrong), Toast.LENGTH_SHORT).show();
			}
			else if(result==3)//invalid token
			{
				Toast.makeText(context, getString(R.string.login_expire), Toast.LENGTH_LONG).show();
			}
			progressDialog.dismiss();			
			/*if(result==0){
				initUI(true);
				new SalesOrderListAsyncTask(aq).execute();
			}*/
		}
	}
}
