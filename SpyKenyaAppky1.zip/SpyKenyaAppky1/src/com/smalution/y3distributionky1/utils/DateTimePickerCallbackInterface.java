package com.smalution.y3distributionky1.utils;

public interface DateTimePickerCallbackInterface 
{
	public void onDateTimeSet(int year, int month,int day, int hours, int mins);
}
