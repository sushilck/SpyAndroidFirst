package com.smalution.y3distributionky1.utils;

public class URLs 
{
	public String URL_CUSTOMER_LIST = "http://smalution.net/y3/services/customers.json";
	public String URL_APP_SETTING_DATA = "http://smalution.net/y3/services/getAppSettingsData.json";
//	data['depots']
//	data['regions'] 
//	data['lgas']
//	data['states'] 
//	data['users'] 
//	data['customers']
//	data['brands']
//	data['distributors']
//	data['paymentMode']
//	data['bankList']

}
