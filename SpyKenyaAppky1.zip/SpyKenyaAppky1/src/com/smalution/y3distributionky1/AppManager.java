package com.smalution.y3distributionky1;


import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnMultiChoiceClickListener;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.database.Cursor;
import android.net.ConnectivityManager;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import com.androidquery.AQuery;
import com.androidquery.callback.AjaxCallback;
import com.androidquery.callback.AjaxStatus;
import com.smalution.y3distributionky1.R;
import com.smalution.y3distributionky1.database.Y3QueryDataSource;
import com.smalution.y3distributionky1.entities.customer.Customer;
import com.smalution.y3distributionky1.entities.customervisits.CustomerVisit;
import com.smalution.y3distributionky1.entities.distributor.Distributor;
import com.smalution.y3distributionky1.entities.distributor.DistributorDetail;
import com.smalution.y3distributionky1.entities.expense.Expense;
import com.smalution.y3distributionky1.entities.incentive.IncentiveItem;
import com.smalution.y3distributionky1.entities.payments.Payments;
import com.smalution.y3distributionky1.entities.salesorder.SalesOrder;
import com.smalution.y3distributionky1.entities.salesorder.SalesOrderDetail;
import com.smalution.y3distributionky1.entities.settings.ActiveCompaignManager;
import com.smalution.y3distributionky1.entities.settings.Banks;
import com.smalution.y3distributionky1.entities.settings.Brand;
import com.smalution.y3distributionky1.entities.settings.Brands;
import com.smalution.y3distributionky1.entities.settings.Customers;
import com.smalution.y3distributionky1.entities.settings.Depots;
import com.smalution.y3distributionky1.entities.settings.Distributors;
import com.smalution.y3distributionky1.entities.settings.ExpenseTypeList;
import com.smalution.y3distributionky1.entities.settings.Lgas;
import com.smalution.y3distributionky1.entities.settings.PaymentModes;
import com.smalution.y3distributionky1.entities.settings.Redistributors;
import com.smalution.y3distributionky1.entities.settings.Regions;
import com.smalution.y3distributionky1.entities.settings.Routes;
import com.smalution.y3distributionky1.entities.settings.States;
import com.smalution.y3distributionky1.entities.settings.Users;
import com.smalution.y3distributionky1.utils.AppConstant;
import com.smalution.y3distributionky1.utils.Constants;
import com.smalution.y3distributionky1.utils.StuffData;

public class AppManager {
	//Local path
	//private String URL_BASE_PATH="http://192.168.0.3:8080/mvc/y3/uganda/";	
	//Live url
	private String URL_BASE_PATH = "http://crmdev.smalution.net/kenya/";
	
	private String LOGIN_API = URL_BASE_PATH + "users/service_login";
	public String SEND_LAT_LAONG_API = URL_BASE_PATH
			+ "tracking/addlatlong.json";

	public String URL_APP_SETTING_DATA = URL_BASE_PATH
			+ "services/getAppSettingsData.json";
	public String URL_GET_MORE_CUSTOMER = URL_BASE_PATH
			+ "services/getMoreCustomer.json";
	public String URL_LIST_CUSTOMER = URL_BASE_PATH
			+ "services/customers.json";
	public String URL_UPDATE_CUSTOMER = URL_BASE_PATH
			+ "services/updatecustomer.json";
	public String URL_DETAIL_CUSTOMER = URL_BASE_PATH
			+ "services/getCustomer.json";
	public String URL_DELETE_CUSTOMER = URL_BASE_PATH
			+ "services/deleteCustomer.json";
	public String URL_SETTINGS_LIST_CUSTOMER = URL_BASE_PATH
			+ "services/customersList.json";

	public String URL_LIST_CUSTOMERVISITS = URL_BASE_PATH
			+ "services/getCustomerVisit.json";
	public String URL_UPDATE_CUSTOMERVISITS = URL_BASE_PATH
			+ "services/updatevisit.json";
	public String URL_DELETE_CUSTOMERVISITS = URL_BASE_PATH
			+ "services/deleteCustomerVisit.json";

	public String URL_LIST_SALESORDER = URL_BASE_PATH
			+ "salesapp/saleOrders.json";
	public String URL_UPDATE_SALESORDER = URL_BASE_PATH
			+ "salesapp/addsale.json";
	public String URL_DETAIL_SALESORDER = URL_BASE_PATH
			+ "salesapp/orderview.json";
	public String URL_DELETE_SALESORDER = URL_BASE_PATH
			+ "salesapp/orderdelete.json";

	public String URL_LIST_DISTRIBUTOR_SALESORDER = URL_BASE_PATH
			+ "salesapp/distributorSalesOrders.json";
	public String URL_UPDATE_DISTRIBUTOR_SALESORDER = URL_BASE_PATH
			+ "salesapp/addrdsale.json";
	public String URL_DETAIL_DISTRIBUTOR_SALESORDER = URL_BASE_PATH
			+ "salesapp/rdsaleview.json";
	public String URL_DELETE_DISTRIBUTOR_SALESORDER = URL_BASE_PATH
			+ "salesapp/rdsaledelete.json";

	public String URL_LIST_PAYMENTS = URL_BASE_PATH
			+ "services/getPaymentList.json";
	public String URL_UPDATE_PAYMENTS = URL_BASE_PATH
			+ "services/updatePayment.json";
	public String URL_DETAIL_PAYMENTS = URL_BASE_PATH
			+ "services/getPayment.json";
	public String URL_DELETE_PAYMENTS = URL_BASE_PATH
			+ "services/deletePayment.json";

	public String URL_LIST_EXPENSE = URL_BASE_PATH
			+ "services/getExpenseList.json";
	public String URL_UPDATE_EXPENSE = URL_BASE_PATH
			+ "services/updateExpense.json";
	public String URL_DETAIL_EXPENSE = URL_BASE_PATH
			+ "services/getExpense.json";
	public String URL_DELETE_EXPENSE = URL_BASE_PATH
			+ "services/deleteExpense.json";

	public String URL_LIST_INCENTIVE = URL_BASE_PATH
			+ "salesapp/incentives.json";
	public String URL_UPDATE_INCENTIVE = URL_BASE_PATH
			+ "salesapp/updateIncentive.json";
	public String URL_DETAIL_INCENTIVE = URL_BASE_PATH
			+ "salesapp/getIncentive.json";
	public String URL_DELETE_INCENTIVE = URL_BASE_PATH
			+ "salesapp/deleteIncentive.json";
	public String URL_DEVICELOG_ADD = URL_BASE_PATH
			+ "devicelog/addlogs.json";
	public String URL_SCUIRITY_ALERT = URL_BASE_PATH
			+ "devicelog/secuirity_alert.json";
	public static String units[] = { "Case", "Roll", "Pack", "2Pack" };
	public static String incetiveTypes[] = { "Redemption", "Sampling", "D&D","Customer on Target","Dist.Incentive" };
	private static AppManager appManager;
	private static boolean returnValue;
	private String jsonDepotStr;
	public final String app_sid = "536999193464";
	public AppManager() {
	}

	public static AppManager getInstance() {
		if (appManager == null)
			appManager = new AppManager();
		return appManager;
	}

	public boolean isValidEmailId(String email) {
		return email.matches("[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+");
	}

	public boolean isValidNumber(String number) {
		try {
			Float.parseFloat(number);
			return true;
		} catch (Exception ex) {
		}
		return false;
	}

	public void showDeleteConfDialog(final Activity activity,
			final SendDataToServerAsyncTask<?> deletor) {
		AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
				activity);
		alertDialogBuilder.setTitle(R.string.warning);
		alertDialogBuilder
				.setMessage(R.string.confirm_delete)
				.setCancelable(false)
				.setPositiveButton(R.string.yes,
						new DialogInterface.OnClickListener() {
							public void onClick(DialogInterface dialog, int id) {
								Y3QueryDataSource datasource = new Y3QueryDataSource(activity);
								datasource.open();				
									if("CUSTOMERVISIT".equals(AppConstant.OPTION_MODE))
									{									
									deletor.execute();
									datasource.deleteCustomerVisitingData(AppConstant.DELETE_ID);
									}
									else if("PAYMENT".equals(AppConstant.OPTION_MODE))
									{
										deletor.execute();
										datasource.deletePaymentSingleRow(AppConstant.DELETE_ID);											
									}							
									else if("INCENTIVE".equals(AppConstant.OPTION_MODE))
									{										
										deletor.execute();
										datasource.deleteIncentiveSingleRow(AppConstant.DELETE_ID);										
									}									
									else if("EXPENCE".equals(AppConstant.OPTION_MODE))
									{									
										deletor.execute();
										datasource.deleteExpenceSingleRecord(AppConstant.DELETE_ID);
									}
									datasource.close();									
								}				
							
				})
				.setNegativeButton(R.string.no, new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int id) {
						dialog.cancel();
					}
				});
		AlertDialog alertDialog = alertDialogBuilder.create();
		alertDialog.show();
	}

	public void showSelectionAlertDialog(Context context,
			final Handler uiHandler, final int viewId, final String[] items) {
		new AlertDialog.Builder(context).setSingleChoiceItems(items, 0, null)
				.setPositiveButton(R.string.OK, new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int whichButton) {
						dialog.dismiss();
						int selectedPosition = ((AlertDialog) dialog)
								.getListView().getCheckedItemPosition();
						Message msg = new Message();
						msg.arg1 = viewId;
						msg.arg2 = selectedPosition;
						msg.obj = items[selectedPosition];
						uiHandler.sendMessage(msg);
					}
				}).show();
	}
	
	

	public void showMultiSelectionAlertDialog(Context context,
			final Handler uiHandler, final int viewId, final String[] items,
			final boolean[] selectedData, final Users users) {
		final ArrayList<String> selectedItems = new ArrayList<String>();
		new AlertDialog.Builder(context)
				.setMultiChoiceItems(items, selectedData,
						new OnMultiChoiceClickListener() {
							@Override
							public void onClick(DialogInterface dialog,
									int which, boolean isChecked) {
								if (isChecked) {
									selectedItems.add(items[which]);
								} else {
									selectedItems.remove(items[which]);
								}
								selectedData[which] = isChecked;
							}
						})
				.setPositiveButton(R.string.OK, new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int whichButton) {
						dialog.dismiss();
						if (selectedItems.size() > 0) {
							//int selectedPosition = ((AlertDialog) dialog).getListView().getCheckedItemPosition();
							Message msg = new Message();
							msg.arg1 = viewId;
							Object[] data = new Object[3];
							data[0] = selectedData;
							data[1] = selectedItems;
							if (selectedItems != null
									&& selectedItems.size() > 0) {
								String json = "{";
								for (int i = 0; i < selectedItems.size(); i++) {
									String key = users
											.getUserIdByName(selectedItems
													.get(i));
									json = json + "\"" + key + "\":\""
											+ selectedItems.get(i) + "\"";
									if (i != selectedItems.size() - 1) {
										json = json + ",";
									}
								}
								json = json + "}";
								data[2] = json;
							}
							msg.obj = data;
							uiHandler.sendMessage(msg);
						}
					}
				}).show();
	}

	public JSONObject loginUser(AQuery aq, Map<String, Object> params) {
		Log.d("MTK", "API:" + LOGIN_API);
		Set<Entry<String, Object>> entriesSet = params.entrySet();
		Iterator<Entry<String, Object>> itr = entriesSet.iterator();
		while (itr.hasNext()) {
			@SuppressWarnings("rawtypes")
			Entry entry = itr.next();
			Log.d("MTK", "PARAM:" + entry.getKey() + "=" + entry.getValue());
		}

		AjaxCallback<JSONObject> cb = new AjaxCallback<JSONObject>();
		cb.url(LOGIN_API).params(params).type(JSONObject.class);
		aq.sync(cb);
		JSONObject result = cb.getResult();
		Log.d("MTK", "RESULT:" + result);
		return result;
	}

	public void sendLatLong(AQuery aq, Map<String, Object> params) {
		Log.d("MTK", "API:" + SEND_LAT_LAONG_API);
		Set<Entry<String, Object>> entriesSet = params.entrySet();
		Iterator<Entry<String, Object>> itr = entriesSet.iterator();
		while (itr.hasNext()) {
			@SuppressWarnings("rawtypes")
			Entry entry = itr.next();
			Log.d("MTK", "PARAM:" + entry.getKey() + "=" + entry.getValue());
		}

		aq.ajax(SEND_LAT_LAONG_API, params, JSONObject.class,
				new AjaxCallback<JSONObject>() {
					@Override
					public void callback(String url, JSONObject json,
							AjaxStatus status) {
						Log.d("MTK", "RESULT:" + json);
						// showResult(json);
					}
				});
	}

	public static boolean isOnline(Context context) {
		boolean isConnected = false;
		try {
			ConnectivityManager cm = (ConnectivityManager) context
					.getSystemService(Context.CONNECTIVITY_SERVICE);
			isConnected = cm.getActiveNetworkInfo().isConnected();
		} catch (Exception ex) {
			isConnected = false;
		}
		return isConnected;
	}

	@SuppressWarnings("static-access")
	public SharedPreferences getPrefs(Context context) {
		return context.getSharedPreferences("BGGeoCollector",
				context.MODE_PRIVATE);
	}

	public boolean getAppSettingData(AQuery aq) {
		try {
			SharedPreferences prefs = getPrefs(aq.getContext());
			Log.d("MTK", "API:" + URL_APP_SETTING_DATA);
			Map<String, Object> params = new HashMap<String, Object>();
			final String token = prefs.getString("token", null);
			params.put("token", token);
			printPostParams(params);
			AjaxCallback<JSONObject> cb = new AjaxCallback<JSONObject>();
			cb.url(URL_APP_SETTING_DATA).params(params).type(JSONObject.class);
			aq.sync(cb);
			JSONObject result = cb.getResult();
			//Log.d("MTK", "RESULT Seatting Data:"+result);
			if (result != null) {
				JSONObject dataJSONObject = result.getJSONObject("data");
				Editor edt = prefs.edit();
				String depots = dataJSONObject.isNull(Constants.PREFKEY_DEPOTS) ? "[]"
						: dataJSONObject.getJSONArray(Constants.PREFKEY_DEPOTS)
								.toString();
				edt.putString(Constants.PREFKEY_DEPOTS, depots);
				String regions = dataJSONObject
						.isNull(Constants.PREFKEY_REGIONS) ? "[]"
						: dataJSONObject
								.getJSONArray(Constants.PREFKEY_REGIONS)
								.toString();
				edt.putString(Constants.PREFKEY_REGIONS, regions);
				String lgas = dataJSONObject.isNull(Constants.PREFKEY_LGAS) ? "[]"
						: dataJSONObject.getJSONArray(Constants.PREFKEY_LGAS)
								.toString();
				edt.putString(Constants.PREFKEY_LGAS, lgas);
				String states = dataJSONObject.isNull(Constants.PREFKEY_STATES) ? "[]"
						: dataJSONObject.getJSONArray(Constants.PREFKEY_STATES)
								.toString();
				edt.putString(Constants.PREFKEY_STATES, states);
				String users = dataJSONObject.isNull(Constants.PREFKEY_USERS) ? "[]"
						: dataJSONObject.getJSONArray(Constants.PREFKEY_USERS)
								.toString();
				edt.putString(Constants.PREFKEY_USERS, users);
				
				String routes = dataJSONObject.isNull("routes") ? "[]"
						: dataJSONObject.getJSONArray("routes").toString();
				edt.putString("routes", routes);
				
				String customers = dataJSONObject
						.isNull(Constants.PREFKEY_CUSTOMERS) ? "[]"
						: dataJSONObject.getJSONArray(
								Constants.PREFKEY_CUSTOMERS).toString();
				
				//edt.putString(Constants.PREFKEY_CUSTOMERS, customers);
				
			//Insert Customer list
				Y3QueryDataSource y3QueryDataSource = new Y3QueryDataSource(aq.getContext());
				y3QueryDataSource.open();
				y3QueryDataSource.updateCustomerList(customers, true);				
				y3QueryDataSource.close();	
				
				String brands = dataJSONObject.isNull(Constants.PREFKEY_BRANDS) ? "[]"
						: dataJSONObject.getJSONArray(Constants.PREFKEY_BRANDS)
								.toString();
				edt.putString(Constants.PREFKEY_BRANDS, brands);
				String distributor = dataJSONObject
						.isNull(Constants.PREFKEY_DISTRIBUTOR) ? "[]"
						: dataJSONObject.getJSONArray(
								Constants.PREFKEY_DISTRIBUTOR).toString();
				edt.putString(Constants.PREFKEY_DISTRIBUTOR, distributor);
				String paymentMode = dataJSONObject
						.isNull(Constants.PREFKEY_PAYMENTMODE) ? "{}"
						: dataJSONObject.getJSONObject(
								Constants.PREFKEY_PAYMENTMODE).toString();
				edt.putString(Constants.PREFKEY_PAYMENTMODE, paymentMode);
				String bankList = dataJSONObject
						.isNull(Constants.PREFKEY_BANKLIST) ? "[]"
						: dataJSONObject.getJSONArray(
								Constants.PREFKEY_BANKLIST).toString();
				edt.putString(Constants.PREFKEY_BANKLIST, bankList);
				String activeCompaign = dataJSONObject
						.isNull(Constants.PREFKEY_ACTIVECOMPAIGN) ? "[]"
						: dataJSONObject.getJSONArray(
								Constants.PREFKEY_ACTIVECOMPAIGN).toString();
				edt.putString(Constants.PREFKEY_ACTIVECOMPAIGN, activeCompaign);
				String expenseList = dataJSONObject
						.isNull(Constants.PREFKEY_EXPENSETYPELIST) ? "[]"
						: dataJSONObject.getJSONArray(
								Constants.PREFKEY_EXPENSETYPELIST).toString();
				edt.putString(Constants.PREFKEY_EXPENSETYPELIST, expenseList);
				String redistributorList = dataJSONObject
						.isNull(Constants.PREFKEY_REDISTRIBUTOR) ? "[]"
						: dataJSONObject.getJSONArray(
								Constants.PREFKEY_REDISTRIBUTOR).toString();
				edt.putString(Constants.PREFKEY_REDISTRIBUTOR,
						redistributorList);
				
				String visitDescOpt = dataJSONObject
						.isNull(Constants.PREFKEY_VISITS_DESC_OPTS) ? "[]"
						: dataJSONObject.getJSONArray(Constants.PREFKEY_VISITS_DESC_OPTS).toString();
				edt.putString(Constants.PREFKEY_VISITS_DESC_OPTS,visitDescOpt);
				
				String userTargets = dataJSONObject
						.isNull(Constants.PREFKEY_USERS_TARGETS) ? "{}"
						: dataJSONObject.getJSONObject(Constants.PREFKEY_USERS_TARGETS).toString();
				edt.putString(Constants.PREFKEY_USERS_TARGETS, userTargets);
				
				String units = dataJSONObject
						.isNull(Constants.PREFKEY_UNITS) ? "[]"
						: dataJSONObject.getJSONArray(Constants.PREFKEY_UNITS).toString();
				edt.putString(Constants.PREFKEY_UNITS,units);
				String incentiveType = dataJSONObject
						.isNull("incentiveType") ? "[]"
						: dataJSONObject.getJSONArray("incentiveType").toString();
				edt.putString("incentiveType",incentiveType);
				edt.commit();
				return true;
			} else {
				Log.d("MTK", "Settings data not found. Please relogin.");
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return false;
	}
	public String[] getUnits(AQuery aq){
		
		try {
			String unitArr = getPrefs(aq.getContext()).getString(
					Constants.PREFKEY_UNITS, null);
			if (unitArr != null) {
				JSONArray arr1 = new JSONArray(unitArr);
				String[] unitName = new String[arr1.length()];
				for(int i=0;i<arr1.length();i++)
				{
					unitName[i]= arr1.getString(i);
				}
				return unitName;
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		
		return null;		
	}//incetiveTypes
	public String[] getVisitsComments(AQuery aq){
		
		try {
			String comArr = getPrefs(aq.getContext()).getString(
					Constants.PREFKEY_VISITS_DESC_OPTS, null);
			if (comArr != null) {
				JSONArray arr1 = new JSONArray(comArr);
				String[] comArrName = new String[arr1.length()];
				for(int i=0;i<arr1.length();i++)
				{
					comArrName[i]= arr1.getString(i);
				}
				return comArrName;
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		
		return null;		
	}
	public String[] getIncetiveTypes(AQuery aq){
		
		try {
			String incTpArr = getPrefs(aq.getContext()).getString("incentiveType", null);
			if (incTpArr != null) {
				JSONArray arr1 = new JSONArray(incTpArr);
				String[] incArrName = new String[arr1.length()];
				for(int i=0;i<arr1.length();i++)
				{
					incArrName[i]= arr1.getString(i);
				}
				return incArrName;
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		
		return null;		
	}
	public ExpenseTypeList getExpenseType(AQuery aq) {
		try {
			String expenseTypeStr = getPrefs(aq.getContext()).getString(
					Constants.PREFKEY_EXPENSETYPELIST, null);
			if (expenseTypeStr != null) {
				return new ExpenseTypeList(new JSONArray(expenseTypeStr));
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return null;
	}

	public float getSalesItemBrandPrice(Brand brand, String unit) {
		if (unit.equals("Case")) {
			return Float.parseFloat(brand.getCase_price());
		} else if (unit.equals("Roll")) {
			return Float.parseFloat(brand.getRoll_price());
		} else if (unit.equals("Pack")) {
			return Float.parseFloat(brand.getPack_price());
		} else if (unit.equals("2Pack")) {
			return Float.parseFloat(brand.getPack2_price());
		}
		return 0f;
	}
	public float getSalesItemBrandPriceRd(Brand brand, String unit)	{
		if(unit.equals("Case"))	{
			return Float.parseFloat(brand.getRd_case_price());
		}else if(unit.equals("Roll")){
			return Float.parseFloat(brand.getRd_roll_price());
		}else if(unit.equals("Pack")){
			return Float.parseFloat(brand.getRd_pack_price());
		}
		else if(unit.equals("2Pack")){
			return Float.parseFloat(brand.getRd_2pack_price());
		}
		return 0f;
	}
	
	public ActiveCompaignManager getActiveCompaign(AQuery aq) {
		try {
			String activeCompaignStr = getPrefs(aq.getContext()).getString(
					Constants.PREFKEY_ACTIVECOMPAIGN, null);
			if (activeCompaignStr != null) {
				return new ActiveCompaignManager(new JSONArray(
						activeCompaignStr));
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return null;
	}

	public Depots getDepots(AQuery aq) {
		try {
			String depotsStr = getPrefs(aq.getContext()).getString(Constants.PREFKEY_DEPOTS, null);
			
			
			if (depotsStr != null) {
				return new Depots(new JSONArray(depotsStr));
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return null;
	}
	public Depots getDepots(AQuery aq,String regionId) {
		try {
			
			jsonDepotStr="";
			String depotsStr = getPrefs(aq.getContext()).getString(Constants.PREFKEY_DEPOTS, null);
			JSONArray depotJsonArray=new JSONArray(depotsStr);
			
			for(int i=0;i<depotJsonArray.length();i++)
			{
				JSONObject jsonObject = depotJsonArray.getJSONObject(i).getJSONObject("Depot"); 				
				String region_id=jsonObject.isNull("region_id")?"":jsonObject.getString("region_id");
				if(region_id.equals(regionId)){
					String id=jsonObject.isNull("id")?"":jsonObject.getString("id");
					String title=jsonObject.isNull("title")?"":jsonObject.getString("title");
					//{"Depot":{"region_id":"11","id":"20","title":"ABA"}}
					jsonDepotStr=jsonDepotStr+"{"+"\""+"Depot"+"\""+":"+"{"+"\""+"region_id"+"\""+":"+"\""+region_id+"\""+","+"\""+"id"+"\""+":"+"\""+id+"\""+","+"\""+"title"+"\""+":"+"\""+title+"\""+"}}"+",";
				}
			}
			
			jsonDepotStr=jsonDepotStr.substring(0, jsonDepotStr.length()-1);
			System.out.println(jsonDepotStr);
			jsonDepotStr="["+jsonDepotStr+"]";
			System.out.println(jsonDepotStr);
			
			
			if (depotsStr != null) {
				return new Depots(new JSONArray(jsonDepotStr));
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return null;
	}
	
	public Routes getRoutes(AQuery aq,String regionId, String depotId) {
		String jsonRouteStr="";
		try {			
			String routesStr = getPrefs(aq.getContext()).getString("routes", null);
			//System.out.println(routesStr);
			JSONArray routesJsonArray=new JSONArray(routesStr);
			
			for(int i=0; i< routesJsonArray.length();i++)
			{
				JSONObject jsonObject = routesJsonArray.getJSONObject(i); 				
				String region_id=jsonObject.isNull("region_id")?"":jsonObject.getString("region_id");
				String depot_id=jsonObject.isNull("depot_id")?"":jsonObject.getString("depot_id");
				if(region_id.equals(regionId) && depot_id.equals(depotId)){
					String id=jsonObject.isNull("id")?"":jsonObject.getString("id");
					String title=jsonObject.isNull("title")?"":jsonObject.getString("title");
					//{"Depot":{"region_id":"11","id":"20","title":"ABA"}}
					jsonRouteStr=jsonRouteStr+"{"+"\""+"region_id"+"\""+":"+"\""+region_id+"\""+","+"\""+"id"+"\""+":"+"\""+id+"\""+","+"\""+"title"+"\""+":"+"\""+title+"\""+"}"+",";
					//System.out.println(jsonRouteStr);
				}
			}
			//System.out.println(jsonRouteStr);
			if(jsonRouteStr !="" ){
				jsonRouteStr=jsonRouteStr.substring(0, jsonRouteStr.length()-1);
				jsonRouteStr="["+jsonRouteStr+"]";
			}
			//System.out.println(jsonRouteStr);
			if (routesStr != null) {
				return new Routes(new JSONArray(jsonRouteStr));
			}
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	
	}
	public Regions getRegions(AQuery aq) {
		try {
			String depotsStr = getPrefs(aq.getContext()).getString(
					Constants.PREFKEY_REGIONS, null);
			if (depotsStr != null) {
				return new Regions(new JSONArray(depotsStr));
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return null;
	}

	public Lgas getLgas(AQuery aq,String StateId) {
		try {
			String depotsStr = getPrefs(aq.getContext()).getString(Constants.PREFKEY_LGAS, null);
		
			jsonDepotStr="";
			JSONArray depotJsonArray=new JSONArray(depotsStr);
			for(int i=0;i<depotJsonArray.length();i++)
			{
				JSONObject jsonObject = depotJsonArray.getJSONObject(i).getJSONObject("LgArea"); 				
				String state_id=jsonObject.isNull("state_id")?"":jsonObject.getString("state_id");
				if(StateId.endsWith(state_id)){
					String id=jsonObject.isNull("id")?"":jsonObject.getString("id");
					String name=jsonObject.isNull("name")?"":jsonObject.getString("name");
					jsonDepotStr=jsonDepotStr+"{"+"\""+"LgArea"+"\""+":"+"{"+"\""+"id"+"\""+":"+"\""+id+"\""+","+"\""+"state_id"+"\""+":"+"\""+state_id+"\""+","+"\""+"name"+"\""+":"+"\""+name+"\""+"}}"+",";
				}
			}		
			
			jsonDepotStr=jsonDepotStr.substring(0, jsonDepotStr.length()-1);
			System.out.println(jsonDepotStr);
			jsonDepotStr="["+jsonDepotStr+"]";
			System.out.println(jsonDepotStr);
			
			
			if (depotsStr != null) 
			{
				return new Lgas(new JSONArray(jsonDepotStr));
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return null;
	}
	public Lgas getLgas(AQuery aq) {
		try {
			String depotsStr = getPrefs(aq.getContext()).getString(
					Constants.PREFKEY_LGAS, null);
			if (depotsStr != null) {
				return new Lgas(new JSONArray(depotsStr));
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return null;
	}

	public States getStates(AQuery aq) {
		try {
			String depotsStr = getPrefs(aq.getContext()).getString(
					Constants.PREFKEY_STATES, null);
			if (depotsStr != null) {
				return new States(new JSONArray(depotsStr));
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return null;
	}

	public Users getUsers(AQuery aq) {
		try {
			String depotsStr = getPrefs(aq.getContext()).getString(
					Constants.PREFKEY_USERS, null);
			if (depotsStr != null) {
				return new Users(new JSONArray(depotsStr));
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return null;
	}

	public Customers getCustomers(AQuery aq) {
		try {
			String depotsStr = getPrefs(aq.getContext()).getString(
					Constants.PREFKEY_CUSTOMERS, null);
			if (depotsStr != null) {
				return new Customers(new JSONArray(depotsStr));
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return null;
	}
	public Brands getBrands(AQuery aq, boolean isAll) {
		try {
			String depotsStr = getPrefs(aq.getContext()).getString(
					Constants.PREFKEY_BRANDS, null);
			if (depotsStr != null) {
				return new Brands(new JSONArray(depotsStr), isAll);
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return null;
	}
	public Brands getBrands(AQuery aq) {
		try {
			String depotsStr = getPrefs(aq.getContext()).getString(
					Constants.PREFKEY_BRANDS, null);
			if (depotsStr != null) {
				return new Brands(new JSONArray(depotsStr));
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return null;
	}

	public Distributors getDistributor(AQuery aq) {
		try {
			String depotsStr = getPrefs(aq.getContext()).getString(
					Constants.PREFKEY_DISTRIBUTOR, null);
			if (depotsStr != null) {
				return new Distributors(new JSONArray(depotsStr));
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return null;
	}

	public PaymentModes getPaymentModes(AQuery aq) {
		try {
			String depotsStr = getPrefs(aq.getContext()).getString(
					Constants.PREFKEY_PAYMENTMODE, null);
			if (depotsStr != null) {
				return new PaymentModes(new JSONObject(depotsStr));
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return null;
	}

	public Banks getBanks(AQuery aq) {
		try {
			String depotsStr = getPrefs(aq.getContext()).getString(
					Constants.PREFKEY_BANKLIST, null);
			if (depotsStr != null) {
				return new Banks(new JSONArray(depotsStr));
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return null;
	}

	public Redistributors getRedistributors(AQuery aq) {
		try {
			String redistributorStr = getPrefs(aq.getContext()).getString(
					Constants.PREFKEY_REDISTRIBUTOR, null);
			if (redistributorStr != null) {
				return new Redistributors(new JSONArray(redistributorStr));
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return null;
	}

	public void printPostParams(Map<String, Object> params) {
		Set<Entry<String, Object>> entriesSet = params.entrySet();
		Iterator<Entry<String, Object>> itr = entriesSet.iterator();
		while (itr.hasNext()) {
			Entry entry = itr.next();
			Log.d("MTK", "PARAM:" + entry.getKey() + "=" + entry.getValue());
		}
	}

	// CUSTOMER SECTION
	public ArrayList<Customer> getCustomerList(AQuery aq, int pageNo)
	{
		ArrayList<Customer> list=new ArrayList<Customer>();
		try
		{
			//Y3QueryDataSource dataSource=new Y3QueryDataSource(aq.getContext());
			//dataSource.open();
			SharedPreferences prefs = getPrefs(aq.getContext());
			final String token = prefs.getString("token", null);
			String url=URL_LIST_CUSTOMER+"?token="+token+"&page="+pageNo;
			Log.d("MTK", "URL_LIST_CUSTOMER:"+url);
			InputStream is=fireGetMethodServerRequest(url);
			if(is!=null)
			{
				//customerArrayList.clear();
				if(1==pageNo)
				{
				Y3QueryDataSource y3QueryDataSource = new Y3QueryDataSource(aq.getContext());
				y3QueryDataSource.open();
				y3QueryDataSource.deleteAllCustomerRecordFromDB();
				y3QueryDataSource.close();				
				}
				String jsonStr = getString(is);
				JSONObject jsonObject=new JSONObject(jsonStr);
				jsonObject.toString();
				JSONArray jsonArray=jsonObject.getJSONArray("data");
				for(int i=0;i<jsonArray.length();i++)
				{
				
					Customer customer=	new Customer(jsonArray.getJSONObject(i));
					list.add(customer);
					Y3QueryDataSource datasource = new Y3QueryDataSource(aq.getContext());
					datasource.open();					
					datasource.addCustomerData(customer, "0", "0");
					datasource.close();
		
				}
				}
			
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return list;
		
	}

	public Customer getCustomerDetails(AQuery aq, String customerId) {
		try {
			
			if(AppManager.isOnline(aq.getContext())){
				SharedPreferences prefs = getPrefs(aq.getContext());
				Log.d("MTK", "API:" + URL_DETAIL_CUSTOMER);
				Map<String, Object> params = new HashMap<String, Object>();
				final String token = prefs.getString("token", null);
				params.put("token", token);
				params.put("customer_id", customerId);
				printPostParams(params);
				AjaxCallback<JSONObject> cb = new AjaxCallback<JSONObject>();
				cb.url(URL_DETAIL_CUSTOMER).params(params).type(JSONObject.class);
				aq.sync(cb);
				JSONObject result = cb.getResult();
				
				Log.d("MTK", "RESULT:" + result);
				JSONObject jsonObject = result.isNull("data") ? null : result.getJSONObject("data");
				if (jsonObject == null)
					return null;
				return new Customer(jsonObject);
			}
			else{
				Y3QueryDataSource y3QueryDataSource = new Y3QueryDataSource(aq.getContext());
				y3QueryDataSource.open();
				Cursor cursor=	y3QueryDataSource.getCustomerDataUsingId(customerId);				
				if(cursor != null && cursor.moveToFirst()){
					
					try{						
					StuffData stuffData = new StuffData();
					String customeJson=stuffData.getCustomerJson(cursor,"Compaign");
					JSONObject result = new JSONObject(customeJson);	
					JSONObject jsonObject = result.isNull("data") ? null : result.getJSONObject("data");
					if (jsonObject == null)
						return null;
					return new Customer(jsonObject);
				
					}
					catch(Exception e){
					e.printStackTrace()	;
					}
				}
				y3QueryDataSource.close();
				
			}
		
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return null;
	}

	public ArrayList<CustomerVisit> getCustomerVisitList(AQuery aq,
			int pageCount) {
		ArrayList<CustomerVisit> list = new ArrayList<CustomerVisit>();
		try {
			SharedPreferences prefs = getPrefs(aq.getContext());
			final String token = prefs.getString("token", null);
			String url = URL_LIST_CUSTOMERVISITS + "?token=" + token + "&page="
					+ pageCount;
			Log.d("MTK", "URL_LIST_CUSTOMERVISITS:" + url);
			InputStream is = fireGetMethodServerRequest(url);
			
			if (is != null) {
				if(1==pageCount)
				{
					Y3QueryDataSource y3QueryDataSource = new Y3QueryDataSource(aq.getContext());
					y3QueryDataSource.open();
					y3QueryDataSource.deleteAllCustomerVisitingRecordFromDB();
					y3QueryDataSource.close();			
				}
				
				String jsonStr = getString(is);
				JSONObject jsonObject = new JSONObject(jsonStr);
				JSONArray jsonArray = jsonObject.isNull("data") ? null: jsonObject.getJSONArray("data");
				if (jsonArray != null) {
					for (int i = 0; i < jsonArray.length(); i++) {
					CustomerVisit customerVisit=new CustomerVisit(jsonArray.getJSONObject(i));
					list.add(customerVisit);
						Y3QueryDataSource datasource = new Y3QueryDataSource(aq.getContext());
						datasource.open();					
						datasource.addCustomerVisitingData(customerVisit, "0","0");
						datasource.close();
					}
				}
			}

		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return list;
	}

	public ArrayList<SalesOrder> getSalesOrderList(AQuery aq, int pageNumber) {
		ArrayList<SalesOrder> list = new ArrayList<SalesOrder>();
		try {
			Y3QueryDataSource dataSource = new Y3QueryDataSource(
					aq.getContext());
			//dataSource.open();
			SharedPreferences prefs = getPrefs(aq.getContext());
			final String token = prefs.getString("token", null);
			String url = URL_LIST_SALESORDER + "?token=" + token + "&page="
					+ pageNumber;
			Log.d("MTK", "URL_LIST_SALESORDER:" + url);
			InputStream is = fireGetMethodServerRequest(url);
			if (is != null) {

				// Y3QueryDataSource y3QueryDataSource = new
				// Y3QueryDataSource(aq.getContext());

				String jsonStr = getString(is);
				JSONObject jsonObject = new JSONObject(jsonStr);
				JSONArray jsonArray = jsonObject.isNull("data") ? null: jsonObject.getJSONArray("data");
				if (jsonArray != null) {
					dataSource.open();
					if(pageNumber==1){
					dataSource.deleteAllSalesRecordFromDB();
					}
					for (int i = 0; i < jsonArray.length(); i++) {
						String jsonString = jsonArray.getJSONObject(i).toString();
						//System.out.println(jsonString);
						dataSource.addSalesData(jsonString,jsonString,"0");
						list.add(new SalesOrder(jsonArray.getJSONObject(i)));

					}
					dataSource.close();
				}
				
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return list;
	}

	public ArrayList<Distributor> getDistributorSalesOrderList(AQuery aq,
			int pageCount) {
		ArrayList<Distributor> list = new ArrayList<Distributor>();
		try {
			SharedPreferences prefs = getPrefs(aq.getContext());
			Y3QueryDataSource y3QueryDataSource = new Y3QueryDataSource(aq.getContext());
			final String token = prefs.getString("token", null);
			String url = URL_LIST_DISTRIBUTOR_SALESORDER + "?token=" + token
					+ "&page=" + pageCount;
			Log.d("MTK", "URL_LIST_DISTRIBUTOR_SALESORDER:" + url);
			InputStream is = fireGetMethodServerRequest(url);
			if (is != null) {

				String jsonStr = getString(is);
				JSONObject jsonObject = new JSONObject(jsonStr);
				JSONArray jsonArray = jsonObject.isNull("data") ? null
						: jsonObject.getJSONArray("data");
				if (jsonArray != null) {
					y3QueryDataSource.open();
					if(pageCount==1){
					y3QueryDataSource.deleteAllRedistributorsRecordFromDB();
					}
					for (int i = 0; i < jsonArray.length(); i++) {
						String jsonString = jsonArray.getJSONObject(i).toString();
						System.out.println(jsonString);
						y3QueryDataSource.addRedistributorSaleData(jsonString,"0",null);
						list.add(new Distributor(jsonArray.getJSONObject(i)));
					}
				}
				y3QueryDataSource.close();
			}
		} catch (Exception ex) {

			System.out.println("Exception in Redistributor");
			ex.printStackTrace();
		}
		return list;
	}

	public SalesOrderDetail getSalesOrderDetail(AQuery aq, String orderId) {
		try {
			SharedPreferences prefs = getPrefs(aq.getContext());
			Log.d("MTK", "API:" + URL_DETAIL_SALESORDER);
			Map<String, Object> params = new HashMap<String, Object>();
			final String token = prefs.getString("token", null);
			params.put("token", token);
			params.put("order_id", orderId);
			printPostParams(params);
			AjaxCallback<JSONObject> cb = new AjaxCallback<JSONObject>();
			cb.url(URL_DETAIL_SALESORDER).params(params).type(JSONObject.class);
			aq.sync(cb);
			JSONObject result = cb.getResult();
			Log.d("MTK", "RESULT:" + result);
			JSONObject jsonObject = result.getJSONObject("data");
			SalesOrderDetail salesOrderDetail = new SalesOrderDetail(jsonObject);
			return salesOrderDetail;
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return null;
	}

	public DistributorDetail getDistributorSalesOrderDetail(AQuery aq,
			String rdsale_id) {
		try {
			SharedPreferences prefs = getPrefs(aq.getContext());
			Log.d("MTK", "API:" + URL_DETAIL_DISTRIBUTOR_SALESORDER);
			Map<String, Object> params = new HashMap<String, Object>();
			final String token = prefs.getString("token", null);
			params.put("token", token);
			params.put("rdsale_id", rdsale_id);
			printPostParams(params);
			AjaxCallback<JSONObject> cb = new AjaxCallback<JSONObject>();
			cb.url(URL_DETAIL_DISTRIBUTOR_SALESORDER).params(params)
					.type(JSONObject.class);
			aq.sync(cb);
			JSONObject result = cb.getResult();
			Log.d("MTK", "RESULT:" + result);
			JSONObject jsonObject = result.getJSONObject("data");
			DistributorDetail distributorDetail = new DistributorDetail(
					jsonObject);
			return distributorDetail;
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return null;
	}

	public ArrayList<Payments> getPaymentsList(AQuery aq, int pageNumber) {
		ArrayList<Payments> list = new ArrayList<Payments>();
		try {
			SharedPreferences prefs = getPrefs(aq.getContext());
			final String token = prefs.getString("token", null);
			String url = URL_LIST_PAYMENTS + "?token=" + token + "&page="
					+ pageNumber;
			Log.d("MTK", "URL_LIST_PAYMENTS:" + url);
			InputStream is = fireGetMethodServerRequest(url);
			if (is != null) {
				if(pageNumber==1){
				Y3QueryDataSource y3QueryDataSource = new Y3QueryDataSource(aq.getContext());
				y3QueryDataSource.open();
				y3QueryDataSource.deleteAllPaymentRecordFromDB();
				y3QueryDataSource.close();
				}
				
				
				String jsonStr = getString(is);
				JSONObject jsonObject = new JSONObject(jsonStr);
				JSONArray jsonArray = jsonObject.isNull("data") ? null
						: jsonObject.getJSONArray("data");
				if (jsonArray != null) {
					for (int i = 0; i < jsonArray.length(); i++) {
						Payments payment=new Payments(jsonArray.getJSONObject(i));
						
						list.add(payment);
						
						Y3QueryDataSource datasource = new Y3QueryDataSource(aq.getContext());
						datasource.open();					
						datasource.addPaymentData(payment,"0");
						datasource.close();
						
						
					}
				} else {
					Log.d("MTK",
							"server res:" + jsonObject.getString("message"));
				}
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return list;
	}

	public ArrayList<Expense> getExpenseList(AQuery aq, int pageNumber) {
		ArrayList<Expense> list = new ArrayList<Expense>();
		try {
			SharedPreferences prefs = getPrefs(aq.getContext());
			final String token = prefs.getString("token", null);
			String url = URL_LIST_EXPENSE + "?token=" + token + "&page="
					+ pageNumber;
			Log.d("MTK", "URL_LIST_EXPENSE:" + url);
			InputStream is = fireGetMethodServerRequest(url);
			if (is != null) {
				
				if(pageNumber==1){
				Y3QueryDataSource y3QueryDataSource = new Y3QueryDataSource(aq.getContext());
				y3QueryDataSource.open();
				y3QueryDataSource.deleteAllExpenceRecordFromDB();
				y3QueryDataSource.close();
				}
				
				
				
				String jsonStr = getString(is);
				JSONObject jsonObject = new JSONObject(jsonStr);
				JSONArray jsonArray = jsonObject.isNull("data") ? null
						: jsonObject.getJSONArray("data");
				if (jsonArray != null) {
					for (int i = 0; i < jsonArray.length(); i++) {
						Expense expence=new Expense(jsonArray.getJSONObject(i));
						list.add(expence);
						
						
						Y3QueryDataSource datasource = new Y3QueryDataSource(aq.getContext());
						datasource.open();					
						datasource.addExpenceData(expence,"0");
						datasource.close();
						
						
						
					}
				} else {
					Log.d("MTK",
							"server res:" + jsonObject.getString("message"));
				}
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return list;
	}

	public ArrayList<IncentiveItem> getIncentiveList(AQuery aq, int pageNumber) {
		ArrayList<IncentiveItem> list = new ArrayList<IncentiveItem>();
		try {
			SharedPreferences prefs = getPrefs(aq.getContext());
			final String token = prefs.getString("token", null);
			String url = URL_LIST_INCENTIVE + "?token=" + token + "&page="
					+ pageNumber;
			Log.d("MTK", "URL_LIST_INCENTIVE:" + url);
			InputStream is = fireGetMethodServerRequest(url);
			if (is != null) {
				if(pageNumber==1){
				Y3QueryDataSource y3QueryDataSource = new Y3QueryDataSource(aq.getContext());
				y3QueryDataSource.open();
				y3QueryDataSource.deleteAllIncentiveRecordFromDB();
				y3QueryDataSource.close();	
				}
				
				String jsonStr = getString(is);
				JSONObject jsonObject = new JSONObject(jsonStr);
				JSONArray jsonArray = jsonObject.isNull("data") ? null
						: jsonObject.getJSONArray("data");
				if (jsonArray != null) {
					for (int i = 0; i < jsonArray.length(); i++) {
						IncentiveItem incentive=new IncentiveItem(jsonArray.getJSONObject(i));
						list.add(incentive);
						
						
						Y3QueryDataSource datasource = new Y3QueryDataSource(aq.getContext());
						datasource.open();					
						datasource.addIncentiveData(incentive,"0","");
						datasource.close();
					}
				} else {
					Log.d("MTK",
							"server res:" + jsonObject.getString("message"));
				}
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return list;
	}

	private InputStream fireGetMethodServerRequest(String completeUrl) {
		try {
			int CONNECTION_TIMEOUT = 30 * 1000; // 30sec
			int SOCKET_TIMEOUT = 30 * 1000; // 30sec
			HttpParams httpParameters = new BasicHttpParams();
			HttpConnectionParams.setConnectionTimeout(httpParameters,
					CONNECTION_TIMEOUT);
			HttpConnectionParams.setSoTimeout(httpParameters, SOCKET_TIMEOUT);
			DefaultHttpClient httpClient = new DefaultHttpClient(httpParameters);
			HttpGet httpget = new HttpGet(completeUrl);
			// httpget.setHeader("Content-Type", "text/html; charset=utf-8");
			HttpResponse response = httpClient.execute(httpget);
			HttpEntity entity = response.getEntity();
			if (entity != null) {
				HttpEntity httpEntity = response.getEntity();
				return httpEntity.getContent();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	private String getString(InputStream inputStream) {
		try {
			BufferedReader br = new BufferedReader(new InputStreamReader(
					inputStream));
			StringBuilder sb = new StringBuilder();
			String line;
			while ((line = br.readLine()) != null) {
				sb.append(line);
			}
			return sb.toString();
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return null;
	}

	public boolean showDeleteConfDialogWith(Activity activity) {
		// final boolean returnValue=false;
		AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
				activity);
		alertDialogBuilder.setTitle(R.string.warning);
		alertDialogBuilder
				.setMessage(R.string.confirm_delete)
				.setCancelable(false)
				.setPositiveButton(R.string.yes,
						new DialogInterface.OnClickListener() {
							public void onClick(DialogInterface dialog, int id) {
								returnValue = true;
							}
						})
				.setNegativeButton(R.string.no, new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int id) {
						dialog.cancel();
						returnValue = false;
					}
				});
		AlertDialog alertDialog = alertDialogBuilder.create();
		alertDialog.show();
		return returnValue;
	}

}
