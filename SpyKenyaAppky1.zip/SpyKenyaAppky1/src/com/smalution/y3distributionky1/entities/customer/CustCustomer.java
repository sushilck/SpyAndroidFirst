package com.smalution.y3distributionky1.entities.customer;


import org.json.JSONObject;

import com.smalution.y3distributionky1.entities.Expense;

import android.os.Parcel;
import android.os.Parcelable;

public class CustCustomer implements Parcelable
{
	private boolean view_details;
	private String phone;
	private String status;
	private String depot_id;
	private String zipcode;
	private String region_id;
	private String route_id;
	private String modified;
	private String city;
	private String amount;
	private String id;
	private String state_id;
	private String first_name;
	private String created;
	private String address;
	private String email;
	private String description;
	private String file_id;
	private String last_name;
	private String image_path;
	private String user_id;
	private String longitude;
	private String latitude;
	private String lg_area_id;
	private String created_date;
	private String synchronization_date;
	public CustCustomer(){}
	public CustCustomer(JSONObject jsonObect)
	{
		try
		{
			
			phone=jsonObect.isNull("phone")?"":jsonObect.getString("phone");
			status=jsonObect.isNull("status")?"":jsonObect.getString("status");
			depot_id=jsonObect.isNull("depot_id")?"":jsonObect.getString("depot_id");
			zipcode=jsonObect.isNull("zipcode")?"":jsonObect.getString("zipcode");
			region_id=jsonObect.isNull("region_id")?"":jsonObect.getString("region_id");
			modified=jsonObect.isNull("modified")?"":jsonObect.getString("modified");
			city=jsonObect.isNull("city")?"":jsonObect.getString("city");
			amount=jsonObect.isNull("amount")?"":jsonObect.getString("amount");
			id=jsonObect.isNull("id")?"":jsonObect.getString("id");
			state_id=jsonObect.isNull("state_id")?"":jsonObect.getString("state_id");
			first_name=jsonObect.isNull("first_name")?"":jsonObect.getString("first_name");
			created=jsonObect.isNull("created")?"":jsonObect.getString("created");
			address=jsonObect.isNull("address")?"":jsonObect.getString("address");
			email=jsonObect.isNull("email")?"":jsonObect.getString("email");
			description=jsonObect.isNull("description")?"":jsonObect.getString("description");
			file_id=jsonObect.isNull("file_id")?"":jsonObect.getString("file_id");
			last_name=jsonObect.isNull("last_name")?"":jsonObect.getString("last_name");
			image_path=jsonObect.isNull("image_path")?"":jsonObect.getString("image_path");
			user_id=jsonObect.isNull("user_id")?"":jsonObect.getString("user_id");
			longitude=jsonObect.isNull("longitude")?"":jsonObect.getString("longitude");
			latitude=jsonObect.isNull("latitude")?"":jsonObect.getString("latitude");
			lg_area_id=jsonObect.isNull("lg_area_id")?"":jsonObect.getString("lg_area_id");	
			route_id=jsonObect.isNull("route_id")?"":jsonObect.getString("route_id");	
			//setSynchronization_date(jsonObect.isNull("synchronization")?"":jsonObect.getString("synchronization"));	
			
			if( 1==jsonObect.getInt("view_details") ){
				view_details=true;
			}else{
				view_details=false;
			}
			//view_details=jsonObect.isNull("view_details")?false:jsonObect.getBoolean("view_details");
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
			System.out.println("Error In custCustomer");
		}
	}
	public CustCustomer(JSONObject jsonObect,int i)
	{
		try
		{
			
			phone=jsonObect.isNull("phone")?"":jsonObect.getString("phone");
			status=jsonObect.isNull("status")?"":jsonObect.getString("status");
			depot_id=jsonObect.isNull("depot_id")?"":jsonObect.getString("depot_id");
			zipcode=jsonObect.isNull("zipcode")?"":jsonObect.getString("zipcode");
			region_id=jsonObect.isNull("region_id")?"":jsonObect.getString("region_id");
			modified=jsonObect.isNull("modified")?"":jsonObect.getString("modified");
			city=jsonObect.isNull("city")?"":jsonObect.getString("city");
			amount=jsonObect.isNull("amount")?"":jsonObect.getString("amount");
			id=jsonObect.isNull("id")?"":jsonObect.getString("id");
			state_id=jsonObect.isNull("state_id")?"":jsonObect.getString("state_id");
			first_name=jsonObect.isNull("first_name")?"":jsonObect.getString("first_name");
			created=jsonObect.isNull("created")?"":jsonObect.getString("created");
			address=jsonObect.isNull("address")?"":jsonObect.getString("address");
			email=jsonObect.isNull("email")?"":jsonObect.getString("email");
			description=jsonObect.isNull("description")?"":jsonObect.getString("description");
			file_id=jsonObect.isNull("file_id")?"":jsonObect.getString("file_id");
			last_name=jsonObect.isNull("last_name")?"":jsonObect.getString("last_name");
			image_path=jsonObect.isNull("image_path")?"":jsonObect.getString("image_path");
			user_id=jsonObect.isNull("user_id")?"":jsonObect.getString("user_id");
			longitude=jsonObect.isNull("longitude")?"":jsonObect.getString("longitude");
			latitude=jsonObect.isNull("latitude")?"":jsonObect.getString("latitude");
			lg_area_id=jsonObect.isNull("lg_area_id")?"":jsonObect.getString("lg_area_id");	
			
			if(1==jsonObect.getInt("view_details")){
				view_details=true;
			}else{
				view_details=false;
			}
			//view_details=jsonObect.isNull("view_details")?false:jsonObect.getBoolean("view_details");
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	public CustCustomer(Parcel in)
 	{
		view_details = in.readByte() != 0;
		phone = in.readString();
		status = in.readString();
		depot_id = in.readString();
		zipcode = in.readString();
		region_id = in.readString();
		modified = in.readString();
		city = in.readString();
		amount = in.readString();
		id = in.readString();
		state_id = in.readString();
		first_name = in.readString();
		created = in.readString();
		address = in.readString();
		email = in.readString();
		description = in.readString();
		file_id = in.readString();
		last_name = in.readString();
		image_path = in.readString();
		user_id = in.readString();
		longitude = in.readString();
		latitude = in.readString();
		lg_area_id = in.readString();
	}
 	@Override
 	public int describeContents() 
 	{
 		return 0;
 	}
 	@Override
 	public void writeToParcel(Parcel dest, int flags) 
 	{
 		dest.writeByte((byte) (view_details ? 1 : 0));
 		dest.writeString(phone);
 		dest.writeString(status);
 		dest.writeString(depot_id);
 		dest.writeString(zipcode);
 		dest.writeString(region_id);
 		dest.writeString(modified);
 		dest.writeString(city);
 		dest.writeString(amount);
 		dest.writeString(id);
 		dest.writeString(state_id);
 		dest.writeString(first_name);
 		dest.writeString(created);
 		dest.writeString(address);
 		dest.writeString(email);
 		dest.writeString(description);
 		dest.writeString(file_id);
 		dest.writeString(last_name);
 		dest.writeString(image_path);
 		dest.writeString(user_id);
 		dest.writeString(longitude);
 		dest.writeString(latitude);
 		dest.writeString(lg_area_id);
 	}
 	public static final Parcelable.Creator<CustCustomer> CREATOR = new Parcelable.Creator<CustCustomer>() 
 	{
 		public CustCustomer createFromParcel(Parcel in) 
 		{
 			return new CustCustomer(in);
 		}
 	
 		public CustCustomer[] newArray (int size) 
 		{
 			return new CustCustomer[size];
 		}
 	};
	
	public boolean getView_details() {
		return view_details;
	}
	public void setView_details(boolean view_details) {
		this.view_details = view_details;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getDepot_id() {
		return depot_id;
	}
	public void setDepot_id(String depot_id) {
		this.depot_id = depot_id;
	}
	public String getZipcode() {
		return zipcode;
	}
	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}
	public String getRegion_id() {
		return region_id;
	}
	public void setRegion_id(String region_id) {
		this.region_id = region_id;
	}
	public String getModified() {
		return modified;
	}
	public void setModified(String modified) {
		this.modified = modified;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getAmount() {
		return amount;
	}
	public void setAmount(String amount) {
		this.amount = amount;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getState_id() {
		return state_id;
	}
	public void setState_id(String state_id) {
		this.state_id = state_id;
	}
	public String getFirst_name() {
		return first_name;
	}
	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}
	public String getCreated() {
		return created;
	}
	public void setCreated(String created) {
		this.created = created;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getFile_id() {
		return file_id;
	}
	public void setFile_id(String file_id) {
		this.file_id = file_id;
	}
	public String getLast_name() {
		return last_name;
	}
	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}
	public String getImage_path() {
		return image_path;
	}
	public void setImage_path(String image_path) {
		this.image_path = image_path;
	}
	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	public String getLongitude() {
		return longitude;
	}
	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}
	public String getLatitude() {
		return latitude;
	}
	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}
	public String getLg_area_id() {
		return lg_area_id;
	}
	public void setLg_area_id(String lg_area_id) {
		this.lg_area_id = lg_area_id;
	}
	public String getCreated_date() {
		return created_date;
	}
	public void setCreated_date(String created_date) {
		this.created_date = created_date;
	}
	public String getSynchronization_date() {
		return synchronization_date;
	}
	public void setSynchronization_date(String synchronization_date) {
		this.synchronization_date = synchronization_date;
	}
	public String getRoute_id() {
		return route_id;
	}
	public void setRoute_id(String route_id) {
		this.route_id = route_id;
	}
	
}
