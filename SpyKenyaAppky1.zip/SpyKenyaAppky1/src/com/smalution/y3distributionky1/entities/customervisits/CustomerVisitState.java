package com.smalution.y3distributionky1.entities.customervisits;



import org.json.JSONObject;

import android.os.Parcel;
import android.os.Parcelable;

public class CustomerVisitState implements Parcelable
{
	private String id;
	private String state;
	public CustomerVisitState(){}
	public CustomerVisitState(JSONObject jsonObect)
	{
		try
		{
			id=jsonObect.isNull("id")?"":jsonObect.getString("id");
			state=jsonObect.isNull("state")?"":jsonObect.getString("state");
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	
	public CustomerVisitState(Parcel in)
 	{
		id = in.readString();
		state = in.readString();
	}
 	@Override
 	public int describeContents() 
 	{
 		return 0;
 	}
 	@Override
 	public void writeToParcel(Parcel dest, int flags) 
 	{
 		dest.writeString(id);
 		dest.writeString(state);
	}
 	public static final Parcelable.Creator<CustomerVisitState> CREATOR = new Parcelable.Creator<CustomerVisitState>() 
 	{
 		public CustomerVisitState createFromParcel(Parcel in) 
 		{
 			return new CustomerVisitState(in);
 		}
 	
 		public CustomerVisitState[] newArray (int size) 
 		{
 			return new CustomerVisitState[size];
 		}
 	};
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	
}

