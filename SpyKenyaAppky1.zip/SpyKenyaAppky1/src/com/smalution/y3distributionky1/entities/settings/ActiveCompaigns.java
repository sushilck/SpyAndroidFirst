package com.smalution.y3distributionky1.entities.settings;

import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONObject;

public class ActiveCompaigns 
{
	ACCompaign Compaign;
	ACBrand Brand;
	ArrayList<ACDepot> Depot;
	ArrayList<ACRegion> Region;
	
	public ActiveCompaigns(){}
	public ActiveCompaigns(JSONObject jsonObject)
	{
		try
		{
			Compaign=jsonObject.isNull("Compaign")?null:new ACCompaign(jsonObject.getJSONObject("Compaign"));
			Brand=jsonObject.isNull("Brand")?null:new ACBrand(jsonObject.getJSONObject("Brand"));
			Depot=jsonObject.isNull("Depot")?null:getACDepotsList(jsonObject.getJSONArray("Depot"));
			Region=jsonObject.isNull("Region")?null:getACRegionList(jsonObject.getJSONArray("Region"));
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	private ArrayList<ACRegion> getACRegionList(JSONArray jsonArray) throws Exception
	{
		ArrayList<ACRegion> list=new ArrayList<ACRegion>();
		for(int i=0;i<jsonArray.length();i++)
		{
			list.add(new ACRegion(jsonArray.getJSONObject(i)));
		}
		return list;
	}
	private ArrayList<ACDepot> getACDepotsList(JSONArray jsonArray) throws Exception
	{
		ArrayList<ACDepot> list=new ArrayList<ACDepot>();
		for(int i=0;i<jsonArray.length();i++)
		{
			list.add(new ACDepot(jsonArray.getJSONObject(i)));
		}
		return list;
	}
	public ACCompaign getCompaign() {
		return Compaign;
	}
	public void setCompaign(ACCompaign compaign) {
		Compaign = compaign;
	}
	public ACBrand getBrand() {
		return Brand;
	}
	public void setBrand(ACBrand brand) {
		Brand = brand;
	}
	public ArrayList<ACDepot> getDepot() {
		return Depot;
	}
	public void setDepot(ArrayList<ACDepot> depot) {
		Depot = depot;
	}
	public ArrayList<ACRegion> getRegion() {
		return Region;
	}
	public void setRegion(ArrayList<ACRegion> region) {
		Region = region;
	}
	
	
}
