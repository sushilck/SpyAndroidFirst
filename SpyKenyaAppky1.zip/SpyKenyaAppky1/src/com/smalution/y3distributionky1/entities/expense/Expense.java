package com.smalution.y3distributionky1.entities.expense;


import org.json.JSONObject;

import android.content.SharedPreferences;
import android.os.Parcel;
import android.os.Parcelable;

import com.androidquery.AQuery;
import com.smalution.y3distributionky1.AppManager;
import com.smalution.y3distributionky1.utils.AppConstant;

public class Expense implements Parcelable
{
	ExpUser User;
	ExpExpense Expense;
	ExpExpType ExpType;
	int sno;
	public Expense()
	{
		 User=new ExpUser();
		 ExpType=new ExpExpType();
		 Expense=new ExpExpense();
		
	}
	public Expense(JSONObject jsonObject)
	{
		try
		{
			User=jsonObject.isNull("User")?null:new ExpUser(jsonObject.getJSONObject("User"));
			Expense=jsonObject.isNull("Expense")?null:new ExpExpense(jsonObject.getJSONObject("Expense"));
			ExpType=jsonObject.isNull("ExpType")?null:new ExpExpType(jsonObject.getJSONObject("ExpType"));
			sno=jsonObject.isNull("sno")?0:jsonObject.getInt("sno");
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	
	public Expense(Parcel in)
 	{
		 User=in.readParcelable(ExpUser.class.getClassLoader());
		Expense=in.readParcelable(ExpExpense.class.getClassLoader());
		ExpType=in.readParcelable(ExpExpType.class.getClassLoader());
		sno=in.readInt();
	}
 	@Override
 	public int describeContents() 
 	{
 		return 0;
 	}
 	@Override
 	public void writeToParcel(Parcel dest, int flags) 
 	{
 		dest.writeParcelable(User,flags);
 		dest.writeParcelable(Expense,flags);
 		dest.writeParcelable(ExpType,flags);
 		dest.writeInt(sno);
 	}
 	public static final Parcelable.Creator<Expense> CREATOR = new Parcelable.Creator<Expense>() 
 	{
 		public Expense createFromParcel(Parcel in) 
 		{
 			return new Expense(in);
 		}
 	
 		public Expense[] newArray (int size) 
 		{
 			return new Expense[size];
 		}
 	};

	

	
	public int getSno() {
		return sno;
	}
	public void setSno(int sno) {
		this.sno = sno;
	}
	public ExpUser getUser() {
		return User;
	}
	public void setUser(ExpUser user) {
		User = user;
	}
	public ExpExpense getExpense() {
		return Expense;
	}
	public void setExpense(ExpExpense expense) {
		Expense = expense;
	}
	public ExpExpType getExpType() {
		return ExpType;
	}
	public void setExpType(ExpExpType expType) {
		ExpType = expType;
	}
	public String createJson(AQuery aq, boolean isForEditCustomer)
	{
		SharedPreferences prefs = AppManager.getInstance().getPrefs(aq.getContext());
		String token = prefs.getString("token", null);
		String json="{" +
			"\"token\":\""+token+"\",";
		if(isForEditCustomer)
		{
			json=json+"\"id\":\""+getExpense().getId()+"\",";
		}
		else
		{
			json=json+"\"request_id\":\""+AppConstant.ANDROIDDEVICEID + AppConstant.getRequestId()+"\"," ;
		}	
		json=json+
			"\"depot_id\":\""+getExpense().getDepot_id()+"\"," +
			"\"brand_id\":\""+getExpense().getBrand_id()+"\"," +
			"\"exp_amount\":\""+getExpense().getExp_amount()+"\"," +
			"\"exp_date\":\""+getExpense().getExp_date()+"\"," +
			"\"created\":\""+AppConstant.getCurrentDateAndTime()+"\"," +
//			"\"payment_mode\":\""+getExpense().getPayment_mode()+"\"," +
			"\"expense_ref\":\""+getExpense().getExpense_ref()+"\"," +
			"\"description\":\""+getExpense().getDescription()+"\"," +
			"\"exp_type_id\":\""+getExpense().getExp_type_id()+"\"" +
			"}";
		return json;
	}
}
